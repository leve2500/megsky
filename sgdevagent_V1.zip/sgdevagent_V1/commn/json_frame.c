#include "json_frame.h"
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include "param_cfg.h"

json_t *load_json(const char *text)
{
    json_t *root = NULL;
    json_error_t error;

    root = json_loads(text, 0, &error);
    if (root) {
        return root;
    } else {
        fprintf(stderr, "json error on line %d: %s\n", error.line, error.text);
        return (json_t *)0;
    }
}

int msg_parse(json_t *root)   //�ж���Ϣ���ͣ������Ƿ���code�ж�������֡����Ӧ��֡
{
    json_t *judge_code = NULL;
    if (NULL == root) {
        printf("\n can not unpack ,root is null");
        return 0;
    }
    judge_code = json_object_get(root, "code");
    if (NULL == judge_code) {
        return TYPE_REQUEST;
    } else {
        return TYPE_REPLY;
    }
}

// //���¶����ַ�����������
// static int memcpy_s(void *s1, int s1_size, void *s2, int s2_size)
// {
//     int n = s2_size;
//     if (s1_size > 0 && s2_size > 0 &&
//         n <= s1_size && n <= s2_size)
//     {
//         memcpy(s1, s2, n);
//         return 0;
//     }
//     else
//     {
//         printf("%s(%d)---fatal error:s1_size=%d,s2_size=%d,n=%d,exit\n" , __FILE__, __LINE__, s1_size, s2_size, n);
//         exit(0);
//     }
// }

// //���ݽ������� jsonתΪdouble
// static int json_into_real(double *double_data, json_t *jdata,const char *key)
// {
//     json_t *all_info = NULL;
//     all_info = json_object_get(jdata, key);
//     if (NULL == all_info || !json_is_real(all_info)){
//         printf("\n key = %s, json_object_get fail",key);
//         return VOS_ERR;
//     }
//     *double_data = json_real_value(all_info);
//     return VOS_OK;
// }

//���ݽ������� jsonתΪ����
int json_into_int8_t(int8_t *idata, json_t *jdata, const char *key)
{
    json_int_t value = 0;
    json_t *all_info = NULL;
    all_info = json_object_get(jdata, key);
    if (!json_is_integer(all_info)) {
        printf("key = %s, json_object_get fail\n", key);
        return VOS_ERR;
    }
    value = json_integer_value(all_info);

    *idata = (int8_t)value;
    printf("int8idata=%d\n", *idata);
    return VOS_OK;
}

int json_into_uint8_t(uint8_t *idata, json_t *jdata, const char *key)
{
    json_int_t value = 0;
    json_t *all_info = NULL;
    all_info = json_object_get(jdata, key);
    if (!json_is_integer(all_info)) {
        printf("key = %s, json_object_get fail\n", key);
        return VOS_ERR;
    }
    value = json_integer_value(all_info);

    *idata = (uint8_t)value;
    printf("uint8idata=%d\n", *idata);
    return VOS_OK;
}


int json_into_int32_t(int32_t *idata, json_t *jdata, const char *key)
{
    json_int_t value = 0;;
    json_t *all_info = NULL;
    all_info = json_object_get(jdata, key);
    if (!json_is_integer(all_info)) {
        printf("key = %s, json_object_get fail\n", key);
        return VOS_ERR;
    }
    value = json_integer_value(all_info);

    *idata = (int32_t)value;
    printf("int32data=%d\n", *idata);
    return VOS_OK;
}

int json_into_uint32_t(uint32_t *idata, json_t *jdata, const char *key)
{
    json_int_t value = 0;;
    json_t *all_info = NULL;
    all_info = json_object_get(jdata, key);
    if (!json_is_integer(all_info)) {
        printf("key = %s, json_object_get fail\n", key);
        return VOS_ERR;
    }
    value = json_integer_value(all_info);

    *idata = (uint32_t)value;
    printf("uint32idata=%d\n", *idata);
    return VOS_OK;
}

//���ݽ������� jsonתΪ�ַ���
int json_into_string(char *sdata, json_t *jdata, const char *key)
{
    json_t *all_info = NULL;
    char *test = NULL;
    all_info = json_object_get(jdata, key);
    if (NULL == all_info || !json_is_string(all_info)) {
        printf("key = %s, json_object_get fail\n", key);
        return VOS_ERR;
    }
    test = json_string_value(all_info);
    memcpy_s(sdata, MSG_ARRVD_MAX_LEN, test, strlen(test) + 1);
    printf("sdata=%s\n", sdata);
    return VOS_OK;
}

//����file����  8�����б�ѡ����Ϊ��Ĳ����ж�
static int sg_getfile(json_t *obj, file_info_s *fileobj)
{
    json_t* sign_info = NULL;
    if (json_is_object(obj)) {
        if (json_into_string(fileobj->name, obj, "name") != VOS_OK) {
            return VOS_ERR;
        }
        json_into_string(fileobj->fileType, obj, "fileType");
        json_into_string(fileobj->url, obj, "url");
        if (json_into_uint32_t(&fileobj->size, obj, "size") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_string(fileobj->md5, obj, "md5") != VOS_OK) {
            return VOS_ERR;
        }
        sign_info = json_object_get(obj, "sign");        //������sign�����е�����
        if (json_is_object(sign_info)) {
            if (json_into_string(fileobj->sign.name, sign_info, "name") != VOS_OK) {
                return VOS_ERR;
            }
            json_into_string(fileobj->sign.url, sign_info, "url");
            json_into_uint32_t(&fileobj->sign.size, sign_info, "size");
            json_into_string(fileobj->sign.md5, sign_info, "md5");
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}

//A.1  �豸��Ϣ�ֶΣ�dev��֡����  
static int json_dev_set_new(json_t *obj, dev_info_s *dev_str)
{
    if (NULL != obj) {
        json_object_set_new(obj, "devType", json_string(dev_str->devType));
        json_object_set_new(obj, "devName", json_string(dev_str->devName));
        printf("\ndevName = %s\n", dev_str->devName);

        json_object_set_new(obj, "mfgInfo", json_string(dev_str->mfgInfo));
        json_object_set_new(obj, "devStatus", json_string(dev_str->devStatus));
        json_object_set_new(obj, "hardVersion", json_string(dev_str->hardVersion));
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//A.2 CPU ��Ϣ�ֶ�:cpu��֡����  
static int json_cpu_set_new(json_t *obj, cpu_info_s *cpu_str)
{
    if (NULL != obj) {
        json_object_set_new(obj, "cpus", json_integer(cpu_str->cpus));
        json_object_set_new(obj, "frequency", json_real(cpu_str->frequency));
        if (cpu_str->cache != 0) {
            json_object_set_new(obj, "cache", json_integer(cpu_str->cache));
        }
        if (strlen(cpu_str->arch) != 0) {
            json_object_set_new(obj, "arch", json_string(cpu_str->arch));
        }
        if (cpu_str->cpuLmt != 0) {
            json_object_set_new(obj, "cpuLmt", json_integer(cpu_str->cpuLmt));
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}

//A.3�ڴ���Ϣ�ֶ�:mem��֡����  
static int json_mem_set_new(json_t *obj, mem_info_s *mem_str)
{
    if (NULL != obj) {
        json_object_set_new(obj, "phy", json_integer(mem_str->phy));
        if (mem_str->virt != 0) {
            json_object_set_new(obj, "virt", json_integer(mem_str->virt));
        }
        if (mem_str->memLmt != 0) {
            json_object_set_new(obj, "memLmt", json_integer(mem_str->memLmt));
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//A.4  Ӳ����Ϣ�ֶ�:disk��֡����  
static int json_disk_set_new(json_t *obj, disk_info_s *disk_str)
{
    if (NULL != obj) {
        json_object_set_new(obj, "disk", json_integer(disk_str->disk));
        if (disk_str->diskLmt != 0) {
            json_object_set_new(obj, "diskLmt", json_integer(disk_str->diskLmt));
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//A.5  ����豸��Ϣ�ֶ�:links��֡����  
static int json_links_set_new(json_t *obj, link_info_s *link_str)
{
    if (obj != NULL) {
        if (strlen(link_str->id) != 0) {
            json_object_set_new(obj, "id", json_string(link_str->id));
        }
        if (strlen(link_str->mac) != 0) {
            json_object_set_new(obj, "mac", json_string(link_str->mac));
        }
        json_object_set_new(obj, "name", json_string(link_str->name));
        json_object_set_new(obj, "type", json_string(link_str->type));
    } else {
        return VOS_ERR;
    }
    if (link_str == NULL) {
        printf("json_links_set_new: link_str is NULL. \n");
        return VOS_ERR;
    }
    if (obj == NULL) {
        printf("json_links_set_new: obj is NULL. \n");
        return VOS_ERR;
    }
    json_object_set_new(obj, "id", json_string(link_str->id));
    json_object_set_new(obj, "mac", json_string(link_str->mac));
    json_object_set_new(obj, "name", json_string(link_str->name));
    json_object_set_new(obj, "type", json_string(link_str->type));
    return VOS_OK;
}
//A.6  ����ϵͳ��Ϣ�ֶ�:os��֡����  
static int json_os_set_new(json_t *obj, os_info_s *os_str)
{
    if (NULL != obj) {
        json_object_set_new(obj, "distro", json_string(os_str->distro));
        json_object_set_new(obj, "version", json_string(os_str->version));
        json_object_set_new(obj, "kernel", json_string(os_str->kernel));
        json_object_set_new(obj, "softVersion", json_string(os_str->softVersion));
        json_object_set_new(obj, "patchVersion", json_string(os_str->patchVersion));
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}

//temp:�¶ȼ����֡����  
static int json_temp_set_new(json_t *obj, temp_info_s *temp_str)
{
    if (NULL != obj) {
        json_object_set_new(obj, "temLow", json_integer(temp_str->temLow));
        json_object_set_new(obj, "temHigh", json_integer(temp_str->temHigh));
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//״̬�����ϱ����ϱ�ʱ������֡����  
static int json_rep_set_new(json_t *obj, rep_period_s *rep_str)
{
    if (NULL != obj) {
        if (rep_str->devPeriod != 0) {
            json_object_set_new(obj, "devPeriod", json_integer(rep_str->devPeriod));
        }
        if (rep_str->conPeriod != 0) {
            json_object_set_new(obj, "conPeriod", json_integer(rep_str->conPeriod));
        }
        if (rep_str->appPeriod != 0) {
            json_object_set_new(obj, "appPeriod", json_integer(rep_str->appPeriod));
        }
        if (rep_str->heartPeriod != 0) {
            json_object_set_new(obj, "heartPeriod", json_integer(rep_str->heartPeriod));
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}

/*****************************************************************************
�� �� ��  : MqttTimeStr
��������  : ����ʱ���
�������  :
�������  :
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
int sg_mqtttimestr(time_t time_val, char *time_buff, size_t buff_len, int use_utc)
{
    int ret;
    struct tm t = { 0 };
    if (0 == use_utc) {
        (void)localtime_r(&time_val, &t);
    } else {                            //UTCʱ��
        (void)gmtime_r(&time_val, &t);
    }
    ret = sprintf_s(time_buff, buff_len, "%04d-%02d-%02dT%02d:%02d:%02dZ",
        t.tm_year + 1900, t.tm_mon + 1, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec);
    // ret = sprintf(time_buff, "%04d-%02d-%02dT%02d:%02d:%02dZ",
          // t.tm_year + 1900, t.tm_mon + 1, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec);
    return ret > 0 ? MQTT_OK : MQTT_ERR;
}


/*****************************************************************************
�� �� ��  : sg_unpack_json_msg_header_request
��������  : ��Ϣͷ��ȡ�ӿ� ������
�������  : root
�������  :
�� �� ֵ  : mqtt_request_header_s
���ú���  :
��������  :
*****************************************************************************/
mqtt_request_header_s *sg_unpack_json_msg_header_request(json_t *root)
{
    mqtt_request_header_s *header = NULL;
    header = (mqtt_request_header_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_request_header_s));
    (void)memset_s(header, sizeof(mqtt_request_header_s), 0, sizeof(mqtt_request_header_s));
    if (NULL == root) {
        printf("can not unpack, root is null\n");
        return header;
    }
    json_into_int32_t(&header->mid, root, "mid");
    json_into_string(header->deviceId, root, "deviceId");
    json_into_string(header->timestamp, root, "timestamp");
    json_into_string(header->type, root, "type");
    json_into_int32_t(&header->expire, root, "expire");
    header->param = json_object_get(root, "param");
    return header;
}
/*****************************************************************************
�� �� ��  : sg_unpack_json_msg_header_reply
��������  : ��Ϣͷ��ȡ�ӿ� Ӧ����
�������  : root
�������  :
�� �� ֵ  : mqtt_reply_header_s
���ú���  :
��������  :
*****************************************************************************/
mqtt_reply_header_s *sg_unpack_json_msg_header_reply(json_t *root)
{
    mqtt_reply_header_s *header = NULL;
    header = (mqtt_reply_header_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_reply_header_s));
    (void)memset_s(header, sizeof(mqtt_reply_header_s), 0, sizeof(mqtt_reply_header_s));
    header->param = NULL;
    if (NULL == root) {
        printf("can not unpack ,root is null\n");
        return header;
    }
    json_into_int32_t(&header->mid, root, "mid");
    json_into_string(header->deviceId, root, "deviceId");
    json_into_string(header->timestamp, root, "timestamp");
    json_into_string(header->type, root, "type");
    json_into_int32_t(&header->code, root, "code");
    json_into_string(header->msg, root, "msg");
    header->param = json_object_get(root, "param");
    return header;
    // VOS_Free(header);
}
/****************************************************************************
�� �� ��  : sg_pack_json_msg_header
��������  : ��Ϣͷ��֡�ӿ�
�������  : code mid type param
�������  : char *
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
char *sg_pack_json_msg_header(uint16_t code, int32_t mid, const char *type, const char *msg, json_t *param)
{
    time_t now_time;
    now_time = time(NULL);
    char timestamp[DATA32_LEN];
    char *result = NULL;
    //ת��json
    json_t *piload = NULL;
    piload = json_object();
    sg_dev_param_info_s idparam = sg_get_param();
    json_object_set_new(piload, "deviceId", json_string(idparam.devid));  //��ȡdeviceId
    //timestamp
    sg_mqtttimestr(now_time, timestamp, sizeof(timestamp), TIME_UTC);    //ʹ��UTCʱ��
    if (NULL != timestamp) {
        json_object_set_new(piload, "timestamp", json_string(timestamp));
    }
    if (CODE_NULL != code) {
        json_object_set_new(piload, "code", json_integer(code));
    }
    if (0 != mid) {
        json_object_set_new(piload, "mid", json_integer(mid));
    }
    if (NULL != type) {
        json_object_set_new(piload, "type", json_string(type));
    }
    if (NULL != msg) {
        json_object_set_new(piload, "msg", json_string(msg));
    }
    if (NULL != param) {
        json_object_set_new(piload, "param", param);
    }
    result = json_dumps(piload, JSON_PRESERVE_ORDER);
    printf("result=%s\n", result);
    json_decref(piload);
    return result;
}


static void sg_pack_dev(json_t *obj, dev_acc_req_s *devaccobj)
{
    json_t *dev_object = NULL;
    json_t *cpu_object = NULL;
    json_t *mem_object = NULL;
    json_t *disk_object = NULL;
    json_t *os_object = NULL;
    dev_object = json_object();
    if (!json_dev_set_new(dev_object, &devaccobj->dev)) {
        json_object_set_new(obj, "dev", dev_object);
    }
    cpu_object = json_object();
    if (!json_cpu_set_new(cpu_object, &devaccobj->cpu)) {
        json_object_set_new(obj, "cpu", cpu_object);
    }
    mem_object = json_object();
    if (!json_mem_set_new(mem_object, &devaccobj->mem)) {
        json_object_set_new(obj, "mem", mem_object);
    }
    disk_object = json_object();
    if (!json_disk_set_new(disk_object, &devaccobj->disk)) {
        json_object_set_new(obj, "disk", disk_object);
    }
    os_object = json_object();
    if (!json_os_set_new(os_object, &devaccobj->os)) {
        json_object_set_new(obj, "os", os_object);
    }
}
/*****************************************************************************
�� �� ��  : sg_pack_dev_linkup_data
��������  : �豸��������
�������  : linkupobj
�������  : *msg
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
void sg_pack_dev_linkup_data(dev_acc_req_s *linkupobj, char *msg)
{
    printf("megsky--test :sg_pack_dev_linkup_data \n");
    uint16_t i = 0;
    uint16_t code = CODE_NULL;
    int32_t mid = 0;	//0��������mid
    json_t *param = NULL;
    json_t *linkobj = NULL;
    json_t *linksobj = NULL;

    srand((unsigned)time(NULL));
    mid = rand();
    param = json_object();
    linksobj = json_array();
    if (NULL != linksobj) {
        for (i = 0; i < linkupobj->link_len; i++) {
            linkobj = json_object();
            if (!json_links_set_new(linkobj, &linkupobj->links[i])) {
                json_array_append_new(linksobj, linkobj);
            }
        }
    }
    sg_pack_dev(param, linkupobj);
    json_object_set_new(param, "links", linksobj);
    char *mssm = sg_pack_json_msg_header(code, mid, EVENT_LINKUP, NULL, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//�豸����Ӧ��  ��δ�ã�
// void sg_pack_dev_linkup_reply(const char *error_msg, char *msg)
// {
//     uint16_t code = CODE_NULL;
//     int32_t mid = 0;	//0��������mid
//     json_t *param = NULL;
//     param = json_object();
//     char *mssm = sg_pack_json_msg_header(code, mid, EVENT_LINKUP, error_msg, param);
//     memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) +1); 
//     if (NULL != mssm) {
//         free(mssm);
//     }
// }

/*****************************************************************************
 �� �� ��  : sg_pack_dev_linkdown_data
 ��������  : �豸�����Ͽ��ϱ�
 �������  : linkdownobj
 �������  : *msg
 �� �� ֵ  :
 ���ú���  :
 ��������  :
*****************************************************************************/
void sg_pack_dev_linkdown_data(char *linkdownobj, const char *error_msg, char *msg)
{
    uint16_t code = CODE_NULL;
    int32_t mid = 0;	//0��������mid
    json_t *reasonobj;
    reasonobj = json_object();
    json_object_set_new(reasonobj, "reason", json_string(linkdownobj));
    char *mssm = sg_pack_json_msg_header(code, mid, EVENT_LINKDOWN, error_msg, reasonobj);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
}

//�豸��������
int sg_pack_dev_heartbeat_request_data(char *msg)
{
    int ret = VOS_OK;
    time_t now_time;
    now_time = time(NULL);
    json_t *heartbeatobj = NULL;

    heart_request_s heart_request = { 0 };
    sprintf_s(heart_request.type, DATA32_LEN, "%s", EVENT_HEARTBEAT);  //�ַ�����ֵ
    // sprintf(heart_request.type,  "%s", EVENT_HEARTBEAT);  //�ַ�����ֵ
    heartbeatobj = json_object();
    //��ȡ����
    sg_dev_param_info_s idparam = sg_get_param();
    json_object_set_new(heartbeatobj, "deviceId", json_string(idparam.devid));
    //timestamp
    ret = sg_mqtttimestr(now_time, heart_request.timestamp, sizeof(heart_request.timestamp), TIME_UTC);    //ʹ��UTCʱ��
    if (ret != MQTT_OK) {
        printf("\nFill json header failed for generate time str.\n");
        return MQTT_ERR;
    }
    json_object_set_new(heartbeatobj, "timestamp", json_string(heart_request.timestamp));
    json_object_set_new(heartbeatobj, "type", json_string(heart_request.type));
    char *mssm = json_dumps(heartbeatobj, JSON_PRESERVE_ORDER);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    printf("msg=%s\n", msg);
    if (NULL != mssm) {
        free(mssm);
    }
    json_decref(heartbeatobj);
    return VOS_OK;
    //deviceId string �� ���豸Ψһ��ʶ
    //	timestamp string �� ��Ϣ���͵�ʱ�����CST ʱ��, ���ȵ���
    //	type string �� EVENT_HEARTBEAT
    //����Ҫ���� pack_json_msg_header(code, mid, type, param);
}

//�豸����Ӧ��
int sg_pack_dev_heartbeat_response_data(char *msg)
{
    int ret = VOS_OK;
    time_t now_time;
    now_time = time(NULL);
    json_t *heartbeatobj = NULL;
    heart_reply_s heart_reply = { 0 };
    heart_reply.code = REQUEST_SUCCESS;
    sprintf_s(heart_reply.type, DATA32_LEN, "%s", EVENT_HEARTBEAT);  //�ַ�����ֵ
    // sprintf(heart_reply.type,  "%s", EVENT_HEARTBEAT);  //�ַ�����ֵ
    heartbeatobj = json_object();
    //��ȡ����
    sg_dev_param_info_s idparam = sg_get_param();
    json_object_set_new(heartbeatobj, "deviceId", json_string(idparam.devid));
    //timestamp
    ret = sg_mqtttimestr(now_time, heart_reply.timestamp, sizeof(heart_reply.timestamp), 1);    //ʹ��UTCʱ��
    if (ret != MQTT_OK)
    {
        printf("Fill json header failed for generate time str.\n");
        return MQTT_ERR;
    }
    json_object_set_new(heartbeatobj, "timestamp", json_string(heart_reply.timestamp));
    json_object_set_new(heartbeatobj, "type", json_string(heart_reply.type));
    json_object_set_new(heartbeatobj, "code", json_integer(heart_reply.code));
    char *mssm = json_dumps(heartbeatobj, JSON_PRESERVE_ORDER);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    printf("msg=%s\n", msg);
    if (NULL != mssm) {
        free(mssm);
    }
    json_decref(heartbeatobj);
    return VOS_OK;
}

/*****************************************************************************
�� �� ��  : sg_unpack_dev_install_cmd
��������  : �豸��������
�������  : obj
�������  : *cmdobj
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
int sg_unpack_dev_install_cmd(json_t *obj, device_upgrade_s *cmdobj)
{
    json_t* file_info = NULL;
    //************************��ʼ��������*****************************************
    if (json_into_int32_t(&cmdobj->jobId, obj, "jobId") != VOS_OK) {          //��ѡΪ��
        return VOS_ERR;
    }
    json_into_uint32_t(&cmdobj->policy, obj, "policy");                //��ѡΪ��
    if (json_into_string(cmdobj->version, obj, "version") != VOS_OK) {                      //��ѡΪ��
        return VOS_ERR;
    }
    if (json_into_uint8_t(&cmdobj->upgradeType, obj, "upgradeType") != VOS_OK) {
        return VOS_ERR;
    }
    file_info = json_object_get(obj, "file");        //�ٽ���file�����е�����
    if (sg_getfile(file_info, &cmdobj->file) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

//�豸��������Ӧ��  ��param
void sg_pack_dev_install_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;  //paramδ��ֵ��ʾ paramΪ�� ����֡
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_SYS_UPGRADE, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }

}
//�豸����״̬��ѯ����   ����Ӧ��Ҳһ��
int32_t sg_unpack_dev_install_query(json_t *obj)
{
    int32_t jobid = 0;
    json_into_int32_t(&jobid, obj, "jobId");
    return jobid;
}

/*****************************************************************************
�� �� ��  : sg_pack_dev_install_query
��������  : �豸����״̬��ѯӦ�� (����Ӧ��Ҳһ��)
�������  : code mid *statusobj
�������  : *msg
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
int sg_pack_dev_install_query(uint16_t code, int32_t mid, const char *error_msg, dev_status_reply_s statusobj, char *msg)
{
    json_t *param = NULL;
    param = json_object();
    json_object_set_new(param, "jobId", json_integer(statusobj.jobId));
    json_object_set_new(param, "progress", json_integer(statusobj.progress));
    json_object_set_new(param, "state", json_integer(statusobj.state));
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_STATUS_QUERY, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
    return VOS_OK;
}
//�豸��������ϱ� ������Ӧ��Ҳһ��
void sg_pack_dev_install_result(dev_upgrede_res_reply_s statusobj, const char *error_msg, char *msg)
{
    uint16_t code = CODE_NULL;
    int32_t mid = 0;	//0��������mid
    json_t *param = NULL;
    param = json_object();
    json_object_set_new(param, "jobId", json_integer(statusobj.jobId));
    json_object_set_new(param, "code", json_integer(statusobj.code));
    if (strlen(statusobj.msg) != 0) {
        json_object_set_new(param, "msg", json_string(statusobj.msg));
    }
    char *mssm = sg_pack_json_msg_header(code, mid, REP_JOB_RESULT, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

static int jsonframmem(json_t *obj, dev_sta_reply_s *devstaobj)
{
    int ret = VOS_OK;
    json_object_set_new(obj, "phy", json_integer(devstaobj->mem_used.phy));
    json_object_set_new(obj, "virt", json_integer(devstaobj->mem_used.virt));
    return ret;
}

//�豸״̬�ϱ�
void sg_pack_dev_run_status(dev_sta_reply_s *statusobj, const char *error_msg, char *msg)
{
    uint16_t i = 0;
    uint16_t code = CODE_NULL;
    int32_t mid = 0;	//0��������mid
    json_t *param = NULL;
    json_t *mem_object = NULL;
    json_t *linkStateobj = NULL;
    json_t *linkStatesobj = NULL;
    param = json_object();
    mem_object = json_object();
    linkStatesobj = json_array();
    if (NULL != linkStatesobj) {
        for (i = 0; i < statusobj->link_len; i++) {
            linkStateobj = json_object();
            if (NULL != linkStateobj) {
                json_object_set_new(linkStateobj, "name", json_string(statusobj->linkState[i].name));
                json_object_set_new(linkStateobj, "status", json_string(statusobj->linkState[i].status));
                json_array_append_new(linkStatesobj, linkStateobj);
            }
        }
    }
    json_object_set_new(param, "cpuRate", json_integer(statusobj->cpuRate));
    if (jsonframmem(mem_object, statusobj) == VOS_OK) {
        json_object_set_new(param, "memUsed", mem_object);
    } else {
        printf("jsonframmem error!!!\n");
    }

    json_object_set_new(param, "diskUsed", json_integer(statusobj->diskUsed));
    json_object_set_new(param, "tempValue", json_integer(statusobj->tempValue));
    json_object_set_new(param, "devDateTime", json_string(statusobj->devDateTime));
    json_object_set_new(param, "devStDateTime", json_string(statusobj->devStDateTime));
    json_object_set_new(param, "devRunTime", json_integer(statusobj->devRunTime));
    json_object_set_new(param, "linkState", linkStatesobj);
    if (strlen(statusobj->longitude) != 0) {
        json_object_set_new(param, "longitude", json_string(statusobj->longitude));
    }
    if (strlen(statusobj->latitude) != 0) {
        json_object_set_new(param, "latitude", json_string(statusobj->latitude));
    }
    char *mssm = sg_pack_json_msg_header(code, mid, REP_SYS_STATUS, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//�豸״̬��ѯ����Ӧ�� 
int sg_pack_dev_run_status_reply(uint16_t code, int32_t mid, const char *error_msg, dev_sta_reply_s *statusobj, char *msg)
{
    uint16_t i = 0;
    char *mssm = NULL;
    json_t *param = NULL;
    json_t *mem_object = NULL;
    json_t *linkStateobj = NULL;
    json_t *linkStatesobj = NULL;
    param = json_object();
    mem_object = json_object();
    linkStatesobj = json_array();
    if (NULL != linkStatesobj) {
        for (i = 0; i < statusobj->link_len; i++) {
            linkStateobj = json_object();
            if (NULL != linkStateobj) {
                json_object_set_new(linkStateobj, "name", json_string(statusobj->linkState[i].name));
                json_object_set_new(linkStateobj, "status", json_string(statusobj->linkState[i].status));
                json_array_append_new(linkStatesobj, linkStateobj);
            }
        }
    }
    json_object_set_new(param, "cpuRate", json_integer(statusobj->cpuRate));
    if (!jsonframmem(mem_object, statusobj)) {
        json_object_set_new(param, "memUsed", mem_object);
    }
    json_object_set_new(param, "diskUsed", json_integer(statusobj->diskUsed));
    json_object_set_new(param, "tempValue", json_integer(statusobj->tempValue));
    json_object_set_new(param, "devDateTime", json_string(statusobj->devDateTime));
    json_object_set_new(param, "devStDateTime", json_string(statusobj->devStDateTime));
    json_object_set_new(param, "devRunTime", json_integer(statusobj->devRunTime));
    json_object_set_new(param, "linkState", linkStatesobj);
    if (strlen(statusobj->longitude) != 0) {
        json_object_set_new(param, "longitude", json_string(statusobj->longitude));
    }
    if (strlen(statusobj->latitude) != 0) {
        json_object_set_new(param, "latitude", json_string(statusobj->latitude));
    }
    mssm = sg_pack_json_msg_header(code, mid, CMD_SYS_STATUS, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
    return VOS_OK;
}

static void sg_pack_devinfo(json_t *obj, dev_info_inq_reply_s *devinfoobj)
{
    json_t *dev_object = NULL;
    json_t *cpu_object = NULL;
    json_t *mem_object = NULL;
    json_t *disk_object = NULL;
    json_t *temp_object = NULL;
    json_t *os_object = NULL;
    dev_object = json_object();
    if (!json_dev_set_new(dev_object, &devinfoobj->dev)) {
        json_object_set_new(obj, "dev", dev_object);
    }
    cpu_object = json_object();
    if (!json_cpu_set_new(cpu_object, &devinfoobj->cpu)) {
        json_object_set_new(obj, "cpu", cpu_object);
    }
    mem_object = json_object();
    if (!json_mem_set_new(mem_object, &devinfoobj->mem)) {
        json_object_set_new(obj, "mem", mem_object);
    }
    disk_object = json_object();
    if (!json_disk_set_new(disk_object, &devinfoobj->disk)) {
        json_object_set_new(obj, "disk", disk_object);
    }
    temp_object = json_object();
    if (!json_temp_set_new(temp_object, &devinfoobj->temperature)) {
        json_object_set_new(obj, "temperature", temp_object);
    }
    os_object = json_object();
    if (!json_os_set_new(os_object, &devinfoobj->os)) {
        json_object_set_new(obj, "os", os_object);
    }
}

//�豸��Ϣ��ѯ����Ӧ�� 
int sg_pack_dev_info_reply(uint16_t code, int32_t mid, const char *error_msg, dev_info_inq_reply_s *statusobj, char *msg)
{
    uint16_t i = 0;
    json_t *param = NULL;
    json_t *linkobj = NULL;
    json_t *linksobj = NULL;
    json_t *repPeriodobj = NULL;
    param = json_object();
    linksobj = json_array();
    if (NULL != linksobj) {
        for (i = 0; i < statusobj->link_len; i++) {
            linkobj = json_object();
            if (!json_links_set_new(linkobj, &statusobj->links[i])) {
                json_array_append_new(linksobj, linkobj);
            }
        }
    }
    sg_pack_devinfo(param, statusobj);
    json_object_set_new(param, "links", linksobj);
    repPeriodobj = json_object();
    if (!json_rep_set_new(repPeriodobj, &statusobj->rep_period)) {
        json_object_set_new(param, "repPeriod", repPeriodobj);
    }
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_INFO_QUERY, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
    return VOS_OK;
}
//�豸���������޸�����
int sg_unpack_dev_set_para_cmd(json_t *obj, dev_man_conf_command_s *paraobj)
{
    json_t* temp_info = NULL;
    json_t* repPeriod_info = NULL;
    json_into_string(paraobj->devName, obj, "devName");       //�Ƚ�����������
    json_into_uint32_t(&paraobj->cpuLmt, obj, "cpuLmt");
    json_into_uint32_t(&paraobj->memLmt, obj, "memLmt");
    json_into_uint32_t(&paraobj->diskLmt, obj, "diskLmt");
    temp_info = json_object_get(obj, "temperature");         //�ٽ���temperature�����е�����
    if (json_is_object(temp_info)) {
        if (json_into_int8_t(&paraobj->temperature.temLow, temp_info, "temLow") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_int8_t(&paraobj->temperature.temHigh, temp_info, "temHigh") != VOS_OK) {
            return VOS_ERR;
        }
    }
    repPeriod_info = json_object_get(obj, "repPeriod");      //������repPeriod�����е�����
    if (json_is_object(repPeriod_info)) {
        json_into_uint32_t(&paraobj->rep_period.devPeriod, repPeriod_info, "devPeriod");
        json_into_uint32_t(&paraobj->rep_period.conPeriod, repPeriod_info, "conPeriod");
        json_into_uint32_t(&paraobj->rep_period.appPeriod, repPeriod_info, "appPeriod");
        json_into_uint32_t(&paraobj->rep_period.heartPeriod, repPeriod_info, "heartPeriod");
    }
    return VOS_OK;
}

//�豸���������޸�����Ӧ�� ��param
void sg_pack_dev_set_para_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;  //paramδ��ֵ��ʾ paramΪ�� ����֡
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_SYS_SET_CONFIG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//�豸ʱ��ͬ������
int sg_unpack_dev_set_time_cmd(json_t *obj, dev_time_command_s *timeobj)
{
    if (json_into_string(timeobj->dateTime, obj, "dateTime") != VOS_OK) {    //�Ƚ�����������
        return VOS_ERR;
    }
    if (json_into_string(timeobj->timeZone, obj, "timeZone") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
//�豸ʱ��ͬ������Ӧ�� ��param
void sg_pack_dev_set_time_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;  //paramδ��ֵ��ʾ paramΪ�� ����֡
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_DATETIME_SYN, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//�豸�¼��ϱ�
void sg_pack_dev_event(dev_thing_reply_s *evenobj, const char *error_msg, char *msg)
{
    char *mssm = NULL;
    uint16_t code = CODE_NULL;
    int32_t mid = 0;	        //0��������mid
    json_t *param = NULL;
    param = json_object();
    json_object_set_new(param, "event", json_string(evenobj->event));
    if (strlen(evenobj->msg) != 0) {
        json_object_set_new(param, "msg", json_string(evenobj->msg));
    }
    mssm = sg_pack_json_msg_header(code, mid, EVENT_SYS_ALARM, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//�豸��־�ٻ�
int sg_unpack_dev_log_cmd(json_t *obj, dev_log_recall_s *logobj)
{
    if (json_into_string(logobj->url, obj, "url") != VOS_OK) {    //�Ƚ�����������
        return VOS_ERR;
    }
    if (json_into_uint8_t(&logobj->logType, obj, "logType") != VOS_OK) {    //�Ƚ�����������
        return VOS_ERR;
    }
    return VOS_OK;
}
//�豸��־�ٻ�Ӧ��
void sg_pack_dev_log_reply(uint16_t code, int32_t mid, const char *error_msg, file_info_s *logobj, char *msg)
{
    json_t *param = NULL;
    json_t *sign_object = NULL;
    param = json_object();
    sign_object = json_object();
    if (NULL != sign_object) {
        json_object_set_new(sign_object, "name", json_string(logobj->sign.name));
        if (strlen(logobj->sign.url) != 0) {
            json_object_set_new(sign_object, "url", json_string(logobj->sign.url));
        }
        if (logobj->sign.size != 0) {
            json_object_set_new(sign_object, "size", json_integer(logobj->sign.size));
        }
        if (strlen(logobj->sign.md5) != 0) {
            json_object_set_new(sign_object, "md5", json_string(logobj->sign.md5));
        }
    }
    json_object_set_new(param, "name", json_string(logobj->name));
    if (strlen(logobj->fileType) != 0) {
        json_object_set_new(param, "fileType", json_string(logobj->fileType));
    }
    if (strlen(logobj->url) != 0) {
        json_object_set_new(param, "url", json_string(logobj->url));
    }
    json_object_set_new(param, "size", json_integer(logobj->size));
    json_object_set_new(param, "md5", json_string(logobj->md5));
    json_object_set_new(param, "sign", sign_object);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_SYS_LOG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//�豸��������
int sg_unpack_dev_ctrl_cmd(json_t *obj, char *ctrlobj)
{
    if (json_into_string(ctrlobj, obj, "action") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
//�豸��������Ӧ�� ��param
void sg_pack_dev_ctrl_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;  //paramδ��ֵ��ʾ paramΪ�� ����֡
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CTRL, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//����withAPP����
static int sg_getwithapp(json_t *obj, with_app_info_s *withappobj)
{
    json_t *withApp_file_info = NULL;
    json_t *withApp_cfgCpu_info = NULL;
    json_t *withApp_cfgMem_info = NULL;
    if (json_is_object(obj)) {
        if (json_into_string(withappobj->version, obj, "version") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_string(withappobj->enable, obj, "enable") != VOS_OK) {
            return VOS_ERR;
        }
        withApp_file_info = json_object_get(obj, "file");
        if (sg_getfile(withApp_file_info, &withappobj->file) != VOS_OK) {
            return VOS_ERR;
        }
        withApp_cfgCpu_info = json_object_get(obj, "cfgCpu");
        if (json_is_object(withApp_cfgCpu_info)) {
            if (json_into_uint32_t(&withappobj->cfgCpu.cpus, withApp_cfgCpu_info, "cpus") != VOS_OK) {
                return VOS_ERR;
            }
            if (json_into_uint32_t(&withappobj->cfgCpu.cpuLmt, withApp_cfgCpu_info, "cpuLmt") != VOS_OK) {
                return VOS_ERR;
            }
        }
        withApp_cfgMem_info = json_object_get(obj, "cfgMem");
        if (json_is_object(withApp_cfgMem_info)) {
            if (json_into_uint32_t(&withappobj->cfgMem.memory, withApp_cfgMem_info, "memory") != VOS_OK) {
                return VOS_ERR;
            }
            if (json_into_uint32_t(&withappobj->cfgMem.memLmt, withApp_cfgMem_info, "memLmt") != VOS_OK) {
                return VOS_ERR;
            }
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//����cfgCpu����
static int sg_getcfgcpu(json_t *obj, cfg_cpu_info_s *cfgcpuobj)
{
    if (json_is_object(obj)) {
        if (json_into_uint32_t(&cfgcpuobj->cpus, obj, "cpus") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_uint32_t(&cfgcpuobj->cpuLmt, obj, "cpuLmt") != VOS_OK) {
            return VOS_ERR;
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//����cfgMem����
static int sg_getcfgmem(json_t *obj, cfg_mem_info_s *cfgmemobj)
{
    if (json_is_object(obj)) {
        if (json_into_uint32_t(&cfgmemobj->memory, obj, "memory") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_uint32_t(&cfgmemobj->memLmt, obj, "memLmt") != VOS_OK) {
            return VOS_ERR;
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//����cfgDisk����
static int sg_getcfgdisk(json_t *obj, cfg_disk_info_s *cfgdiskobj)
{
    if (json_is_object(obj)) {
        if (json_into_uint32_t(&cfgdiskobj->disk, obj, "disk") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_uint32_t(&cfgdiskobj->diskLmt, obj, "diskLmt") != VOS_OK) {
            return VOS_ERR;
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
/*======================================��������======================== */
//������װ���� 
int sg_unpack_container_install_cmd(json_t *obj, container_install_cmd_s *cmdobj)
{
    int i = 0;
    json_t *image_info = NULL;
    json_t *withAPP_info = NULL;
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;
    json_t *cfgDisk_info = NULL;
    if (json_into_int32_t(&cmdobj->jobId, obj, "jobId") != VOS_OK) {      //1��,�Ƚ�������������
        return VOS_ERR;
    }
    json_into_uint32_t(&cmdobj->policy, obj, "policy");
    if (json_into_string(cmdobj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    json_into_string(cmdobj->port, obj, "port");
    for (i = 0; i < cmdobj->mount_len; i++) {
        if (json_into_string(cmdobj->mount[i], obj, "mount") != VOS_OK) {
            return VOS_ERR;
        }
    }
    for (i = 0; i < cmdobj->dev_len; i++) {
        if (json_into_string(cmdobj->dev[i], obj, "dev") != VOS_OK) {
            return VOS_ERR;
        }
    }
    image_info = json_object_get(obj, "image");                                      //2��,�ٽ���image�����е�����
    if (sg_getfile(image_info, &cmdobj->image) != VOS_OK) {
        return VOS_ERR;
    }
    withAPP_info = json_object_get(obj, "withAPP");                                 //2��,����withAPP_info�����е�����
    if (sg_getwithapp(withAPP_info, &cmdobj->withAPP) != VOS_OK) {
        return VOS_ERR;
    }
    cfgCpu_info = json_object_get(obj, "cfgCpu");                                   //2��,����cfgCpu_info�����е�����
    if (sg_getcfgcpu(cfgCpu_info, &cmdobj->cfgCpu) != VOS_OK) {
        return VOS_ERR;
    }
    cfgMem_info = json_object_get(obj, "cfgMem");                                   //2��,����cfgMem_info�����е�����
    if (sg_getcfgmem(cfgMem_info, &cmdobj->cfgMem) != VOS_OK) {
        return VOS_ERR;
    }
    cfgDisk_info = json_object_get(obj, "cfgDisk");                                 //2��,����cfgDisk_info�����е�����
    if (sg_getcfgdisk(cfgDisk_info, &cmdobj->cfgDisk) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

//������װ��������Ӧ��
void sg_pack_container_install_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_INSTALL, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
/*****************************************************************************
�� �� ��  : sg_unpack_container_control_cmd
��������  : �������� (����������ֹͣ��ɾ��)
�������  : json_t *obj
�������  : *msg
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
int sg_unpack_container_control_cmd(json_t *obj, char *msg)
{
    if (NULL != msg) {
        json_into_string(msg, obj, "container");
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
//����������������Ӧ��
void sg_pack_container_start_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_START, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//����ֹͣ����Ӧ��
void sg_pack_container_stop_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_STOP, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//����ɾ������Ӧ��
void sg_pack_container_remove_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_REMOVE, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//���������޸�����
int sg_unpack_container_param_set_cmd(json_t *obj, container_conf_cmd_s *cmdobj)
{
    uint16_t i = 0;
    uint16_t len = 0;
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;
    json_t *cfgDisk_info = NULL;
    json_t *mount_info = NULL;
    json_t *dev_info = NULL;
    json_t *mount_table = NULL;
    json_t *dev_table = NULL;
    char *array_mount_str = NULL;
    char *array_dev_str = NULL;
    if (json_into_string(cmdobj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    json_into_string(cmdobj->port, obj, "port");
    cfgCpu_info = json_object_get(obj, "cfgCpu");
    if (sg_getcfgcpu(cfgCpu_info, &cmdobj->cfgCpu) != VOS_OK) {
        return VOS_ERR;
    }
    cfgMem_info = json_object_get(obj, "cfgMem");
    if (sg_getcfgmem(cfgMem_info, &cmdobj->cfgMem) != VOS_OK) {
        return VOS_ERR;
    }
    cfgDisk_info = json_object_get(obj, "cfgDisk");
    if (sg_getcfgdisk(cfgDisk_info, &cmdobj->cfgDisk) != VOS_OK) {
        return VOS_ERR;
    }
    mount_info = json_object_get(obj, "mount");
    len = cmdobj->mount_len;
    for (i = 0; i < len; i++) {
        mount_table = json_array_get(mount_info, i);
        array_mount_str = json_string_value(mount_table);
        memcpy_s(cmdobj->mount[i], MSG_ARRVD_MAX_LEN, array_mount_str, strlen(array_mount_str) + 1);
    }
    dev_info = json_object_get(obj, "dev");
    len = cmdobj->dev_len;
    for (i = 0; i < len; i++) {
        dev_table = json_array_get(dev_info, i);
        array_dev_str = json_string_value(dev_table);
        memcpy_s(cmdobj->dev[i], MSG_ARRVD_MAX_LEN, array_dev_str, strlen(array_dev_str) + 1);
    }
    return VOS_OK;
}

//���������޸�Ӧ�� ��param
void sg_pack_container_param_set_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_SET_CONFIG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

static void sg_setmount(json_t *mountsobj_s, container_conf_cmd_s infobj)
{
    uint16_t t = 0;
    uint16_t lent = 0;
    json_t *mountobj_s = NULL;
    mountsobj_s = json_array();
    if (NULL != mountsobj_s) {
        lent = infobj.mount_len;
        for (t = 0; t < lent; t++) {
            mountobj_s = json_object();
            if (NULL != mountobj_s) {
                mountobj_s = json_string(infobj.mount[t]);
                json_array_append_new(mountsobj_s, mountobj_s);
            }
        }
    }
}

static void sg_setdev(json_t *devsobj_s, container_conf_cmd_s infobj)
{
    uint16_t t = 0;
    uint16_t lent = 0;
    json_t *devobj_s = NULL;
    devsobj_s = json_array();
    if (NULL != devsobj_s) {
        lent = infobj.dev_len;
        for (t = 0; t < lent; t++) {
            devobj_s = json_object();
            if (NULL != devobj_s) {
                devobj_s = json_string(infobj.dev[t]);
                json_array_append_new(devsobj_s, devobj_s);
            }
        }
    }
}

//��������״̬��ѯӦ��  �Ż��Ƚϸ��ӡ������Թ�-------------------------------------------------------------------------------
void sg_pack_container_param_get_reply(uint16_t code, int32_t mid, const char *error_msg, container_config_reply_s *statusobj, char *msg)
{
    uint16_t i = 0;
    json_t *param = NULL;
    json_t *contPara_obj = NULL;
    json_t *contParas_obj = NULL;
    json_t *cfgCpuobj = NULL;
    json_t *cfgMemobj = NULL;
    json_t *cfgDiskobj = NULL;
    json_t *mountobj = NULL;
    json_t *devobj = NULL;
    param = json_object();
    contParas_obj = json_array();
    if (contParas_obj != NULL) {
        for (i = 0; i < statusobj->contPara_len; i++) {
            contPara_obj = json_object();
            cfgCpuobj = json_object();
            cfgMemobj = json_object();
            cfgDiskobj = json_object();
            mountobj = json_object();
            devobj = json_object();
            if (contPara_obj != NULL) {
                json_object_set_new(contPara_obj, "container", json_string(statusobj->contPara[i].container));
                if (strlen(statusobj->contPara[i].port) != 0) {
                    json_object_set_new(contPara_obj, "port", json_string(statusobj->contPara[i].port));
                }
                if (cfgCpuobj != NULL) {
                    json_object_set_new(cfgCpuobj, "cpus", json_integer(statusobj->contPara[i].cfgCpu.cpus));
                    json_object_set_new(cfgCpuobj, "cpuLmt", json_integer(statusobj->contPara[i].cfgCpu.cpuLmt));
                }
                json_object_set_new(contPara_obj, "cfgCpu", cfgCpuobj);
                if (cfgMemobj != NULL) {
                    json_object_set_new(cfgMemobj, "memory", json_integer(statusobj->contPara[i].cfgMem.memory));
                    json_object_set_new(cfgMemobj, "memLmt", json_integer(statusobj->contPara[i].cfgMem.memLmt));
                }
                json_object_set_new(contPara_obj, "cfgMem", cfgMemobj);

                if (cfgDiskobj != NULL) {
                    json_object_set_new(cfgDiskobj, "disk", json_integer(statusobj->contPara[i].cfgDisk.disk));
                    json_object_set_new(cfgDiskobj, "diskLmt", json_integer(statusobj->contPara[i].cfgDisk.diskLmt));
                }
                json_object_set_new(contPara_obj, "cfgDisk", cfgDiskobj);
                sg_setmount(mountobj, statusobj->contPara[i]);
                json_object_set_new(contPara_obj, "mount", mountobj);
                sg_setdev(devobj, statusobj->contPara[i]);
                json_object_set_new(contPara_obj, "dev", devobj);
            }
            json_array_append_new(contParas_obj, contPara_obj);
        }
    }
    json_object_set_new(param, "contPara", contParas_obj);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_GET_CONFIG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (mssm != NULL) {
        free(mssm);
    }
    if (param != NULL) {
        json_decref(param);
    }
}

//����״̬��ѯӦ��  ����״̬�ϱ�
int sg_pack_container_status_get_reply(char * type, uint16_t code, int32_t mid,
    const char *error_msg, container_status_reply_s *statusobj, char *msg)
{
    int num = 0;
    int ret = VOS_OK;
    char *mssm = NULL;
    json_t *param = NULL;
    json_t *params = NULL;
    if (statusobj == NULL) {
        printf("statusobj == NULL!\n");
        ret = VOS_ERR;
    } else {
        params = json_array();
        for (num = 0; num < statusobj->container_len; num++) {
            param = json_object();
            json_object_set_new(param, "container", json_string(statusobj[num].container));
            json_object_set_new(param, "version", json_string(statusobj[num].version));
            json_object_set_new(param, "state", json_string(statusobj[num].state));
            json_object_set_new(param, "cpuRate", json_integer(statusobj[num].cpuRate));
            json_object_set_new(param, "memUsed", json_integer(statusobj[num].memUsed));
            json_object_set_new(param, "diskUsed", json_integer(statusobj[num].diskUsed));
            json_object_set_new(param, "ip", json_string(statusobj[num].ip));
            json_object_set_new(param, "created", json_string(statusobj[num].created));
            json_object_set_new(param, "started", json_string(statusobj[num].started));
            json_object_set_new(param, "lifeTime", json_integer(statusobj[num].lifeTime));
            json_object_set_new(param, "image", json_string(statusobj[num].image));
            json_array_append_new(params, param);
        }
    }
    mssm = sg_pack_json_msg_header(code, mid, type, error_msg, params);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
    return ret;
}

// //����״̬�ϱ�
// void sg_pack_container_status_get_data(uint16_t code, int32_t mid, const char *error_msg, container_status_reply_s *statusobj, char *msg)
// {
//     json_t *param = NULL;
//     param = json_object();
//     json_object_set_new(param, "container",json_string(statusobj->container));  
//     json_object_set_new(param, "version",json_string(statusobj->version));  
//     json_object_set_new(param, "state",json_string(statusobj->state));
//     json_object_set_new(param, "cpuRate",json_integer(statusobj->cpuRate));
//     json_object_set_new(param, "memUsed",json_integer(statusobj->memUsed));
//     json_object_set_new(param, "diskUsed",json_integer(statusobj->diskUsed));
//     json_object_set_new(param, "ip",json_string(statusobj->ip));
//     json_object_set_new(param, "created",json_string(statusobj->created));
//     json_object_set_new(param, "started",json_string(statusobj->started));
//     json_object_set_new(param, "lifeTime",json_integer(statusobj->lifeTime));
//     json_object_set_new(param, "image",json_string(statusobj->image));
//     char *mssm = sg_pack_json_msg_header(code, mid, REP_CON_STATUS, error_msg, param);
//     memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) +1);
//     if (NULL != mssm){
//         free(mssm);
//     }
//     if (NULL != param){
//         json_decref(param);
//     }
// }

//�����¼��ϱ�
void sg_pack_container_event_pack(uint16_t code, int32_t mid, const char *error_msg, container_event_report_s *statusobj, char *msg)
{
    json_t *param = NULL;
    param = json_object();
    json_object_set_new(param, "container", json_string(statusobj->container));
    json_object_set_new(param, "event", json_string(statusobj->event));
    if (strlen(statusobj->msg) != 0) {
        json_object_set_new(param, "msg", json_string(statusobj->msg));
    }
    char *mssm = sg_pack_json_msg_header(code, mid, EVENT_CON_ALARM, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//������������
int sg_unpack_container_upgrade_cmd(json_t *obj, container_upgrade_cmd_s *cmdobj)
{
    json_t* file_info = NULL;
    if (json_into_int32_t(&cmdobj->jobId, obj, "jobId") != VOS_OK) {
        return VOS_ERR;
    }
    json_into_uint32_t(&cmdobj->policy, obj, "policy");
    if (json_into_string(cmdobj->version, obj, "version") != VOS_OK) {
        return VOS_ERR;
    }
    file_info = json_object_get(obj, "file");         //�ٽ���file�����е�����
    if (sg_getfile(file_info, &cmdobj->file) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
///������������Ӧ�� 
void sg_pack_container_upgrade_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_UPGRADE, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//������־�ٻ�����
int sg_unpack_container_log_get_cmd(json_t *obj, container_log_recall_cmd_s *cmdobj)
{
    json_into_string(cmdobj->container, obj, "container");
    if (json_into_string(cmdobj->url, obj, "url") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
//������־�ٻ�Ӧ��
void sg_pack_container_log_get_reply(uint16_t code, int32_t mid, const char *error_msg, file_info_s *file, char *msg)
{
    json_t *param = NULL;
    json_t *sign_object = NULL;
    param = json_object();
    sign_object = json_object();
    if (NULL != sign_object) {
        json_object_set_new(sign_object, "name", json_string(file->sign.name));
        if (strlen(file->sign.url) != 0) {
            json_object_set_new(sign_object, "url", json_string(file->sign.url));
        }
        if (file->sign.size != 0) {
            json_object_set_new(sign_object, "size", json_integer(file->sign.size));
        }
        if (strlen(file->sign.md5) != 0) {
            json_object_set_new(sign_object, "md5", json_string(file->sign.md5));
        }
    }
    json_object_set_new(param, "name", json_string(file->name));
    if (strlen(file->fileType) != 0) {
        json_object_set_new(param, "fileType", json_string(file->fileType));
    }
    if (strlen(file->url) != 0) {
        json_object_set_new(param, "url", json_string(file->url));
    }
    json_object_set_new(param, "size", json_integer(file->size));
    json_object_set_new(param, "md5", json_string(file->md5));
    json_object_set_new(param, "sign", sign_object);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_LOG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

/*=================================================================APP����========================================================================= */
//Ӧ�ð�װ��������
int sg_unpack_app_install_cmd(json_t *obj, app_install_cmd_s *cmdobj)
{
    json_t *file_info = NULL;
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;
    if (json_into_int32_t(&cmdobj->jobId, obj, "jobId") != VOS_OK) {
        return VOS_ERR;
    }
    json_into_uint32_t(&cmdobj->policy, obj, "policy");
    if (json_into_string(cmdobj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    if (json_into_string(cmdobj->version, obj, "version") != VOS_OK) {
        return VOS_ERR;
    }
    if (json_into_string(cmdobj->enable, obj, "enable") != VOS_OK) {
        return VOS_ERR;
    }
    if (json_into_string(cmdobj->app, obj, "app") != VOS_OK) {
        return VOS_ERR;
    }
    file_info = json_object_get(obj, "file");
    if (sg_getfile(file_info, &cmdobj->file) != VOS_OK) {
        return VOS_ERR;
    }
    cfgCpu_info = json_object_get(obj, "cfgCpu");
    if (sg_getcfgcpu(cfgCpu_info, &cmdobj->cfgCpu) != VOS_OK) {
        return VOS_ERR;
    }
    cfgMem_info = json_object_get(obj, "cfgMem");
    if (sg_getcfgmem(cfgMem_info, &cmdobj->cfgMem) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

//Ӧ�ð�װ��������Ӧ��
void sg_pack_app_install_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_INSTALL, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//Ӧ�ÿ�������  ����  ֹͣ ж�� ʹ��  ȥʹ��  �ϳ�һ��
int sg_unpack_app_control_cmd(json_t *obj, app_control_cmd_s *cmdobj)
{
    if (json_into_string(cmdobj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    if (json_into_string(cmdobj->app, obj, "app") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
//Ӧ������Ӧ�� ��param
void sg_pack_app_start_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_START, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//Ӧ��ֹͣӦ�� ��param
void sg_pack_app_stop_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_STOP, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//Ӧ��ж��Ӧ�� ��param
void sg_pack_app_uninstall_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_REMOVE, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
////Ӧ��ʹ��Ӧ�� ��param
void sg_pack_app_enable_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_ENABLE, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//Ӧ��ȥʹ��Ӧ�� ��param
void sg_pack_app_unenble_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_UNENABLE, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//Ӧ�������޸�����
int sg_unpack_app_param_set_cmd(json_t *obj, app_conf_cmd_s *cmdobj)
{
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;
    if (json_into_string(cmdobj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    if (json_into_string(cmdobj->app, obj, "app") != VOS_OK) {
        return VOS_ERR;
    }
    cfgCpu_info = json_object_get(obj, "cfgCpu");
    if (json_is_object(cfgCpu_info)) {
        if (json_into_uint32_t(&cmdobj->cfgCpu.cpus, cfgCpu_info, "cpus") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_uint32_t(&cmdobj->cfgCpu.cpuLmt, cfgCpu_info, "cpuLmt") != VOS_OK) {
            return VOS_ERR;
        }
    }
    cfgMem_info = json_object_get(obj, "cfgMem");
    if (json_is_object(cfgMem_info)) {
        if (json_into_uint32_t(&cmdobj->cfgMem.memory, cfgMem_info, "memory") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_uint32_t(&cmdobj->cfgMem.memLmt, cfgMem_info, "memLmt") != VOS_OK) {
            return VOS_ERR;
        }
    }
    return VOS_OK;
}
//Ӧ�������޸�Ӧ��
void sg_pack_app_param_set_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_SET_CONFIG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//Ӧ������״̬��ѯ����
int sg_unpack_app_param_get(json_t *obj, char *msg)
{
    if (NULL != msg) {
        json_into_string(msg, obj, "container");
        return VOS_OK;
    } else {
        return VOS_ERR;
    }
}

//Ӧ�����ò�ѯӦ��
void sg_pack_app_param_get_reply(uint16_t code, int32_t mid, const char *error_msg, app_conf_reply_s *statusobj, char *msg)
{
    uint16_t i = 0;
    uint16_t len = 0;
    json_t *param = NULL;
    json_t *appCfgsobj = NULL;
    json_t *appCfgsobjs = NULL;
    json_t *cfgCpuobj = NULL;
    json_t *cfgMemobj = NULL;
    param = json_object();
    appCfgsobjs = json_array();
    if (NULL != appCfgsobjs) {
        len = statusobj->app_num;
        for (i = 0; i < len; i++) {
            appCfgsobj = json_object();
            cfgCpuobj = json_object();
            cfgMemobj = json_object();
            if (NULL != appCfgsobj) {
                json_object_set_new(appCfgsobj, "app", json_string(statusobj->appCfgs[i].app));
                if (NULL != cfgCpuobj) {
                    json_object_set_new(cfgCpuobj, "cpus", json_integer(statusobj->appCfgs[i].cfgCpu.cpus));
                    json_object_set_new(cfgCpuobj, "cpuLmt", json_integer(statusobj->appCfgs[i].cfgCpu.cpuLmt));
                }
                json_object_set_new(appCfgsobj, "cfgCpu", cfgCpuobj);
                if (NULL != cfgMemobj) {
                    json_object_set_new(cfgMemobj, "memory", json_integer(statusobj->appCfgs[i].cfgMem.memory));
                    json_object_set_new(cfgMemobj, "memLmt", json_integer(statusobj->appCfgs[i].cfgMem.memLmt));
                }
                json_object_set_new(appCfgsobj, "cfgMem", cfgMemobj);
                json_array_append_new(appCfgsobjs, appCfgsobj);
            }
        }
    }
    json_object_set_new(param, "container", json_string(statusobj->container));
    json_object_set_new(param, "appCfgs", appCfgsobjs);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_GET_CONFIG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

//Ӧ��״̬��ѯ����
int sg_unpack_app_status_get(json_t *obj, char *msg)
{
    if (NULL != msg) {
        json_into_string(msg, obj, "container");
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}

//��ȡapps�ṹ�������е�process�ṹ����������
static void sg_getprocess(json_t *appsobj_s, apps_info_s infobj)
{
    uint16_t t = 0;
    uint16_t lent = 0;
    json_t *appsobj = NULL;
    appsobj_s = json_array();
    if (NULL != appsobj_s) {
        lent = infobj.srvNumber;
        for (t = 0; t < lent; t++) {
            appsobj = json_object();
            if (NULL != appsobj) {
                json_object_set_new(appsobj, "srvIndex", json_integer(infobj.process[t].srvIndex));
                json_object_set_new(appsobj, "srvName", json_string(infobj.process[t].srvName));
                json_object_set_new(appsobj, "srvEnable", json_string(infobj.process[t].srvEnable));
                json_object_set_new(appsobj, "srvStatus", json_string(infobj.process[t].srvStatus));
                json_object_set_new(appsobj, "cpuLmt", json_integer(infobj.process[t].cpuLmt));
                json_object_set_new(appsobj, "cpuRate", json_integer(infobj.process[t].cpuRate));
                json_object_set_new(appsobj, "memLmt", json_integer(infobj.process[t].memLmt));
                json_object_set_new(appsobj, "memUsed", json_integer(infobj.process[t].memUsed));
                json_object_set_new(appsobj, "startTime", json_string(infobj.process[t].startTime));
                json_array_append_new(appsobj_s, appsobj);
            }
        }
    }
}
//Ӧ��״̬��ѯӦ��
void sg_pack_app_status_get_reply(uint16_t code, int32_t mid, const char *error_msg, app_inq_reply_s *statusobj, char *msg)
{
    uint16_t i = 0;
    uint16_t len = 0;
    json_t *param = NULL;
    json_t *appobj = NULL;
    json_t *appobjs = NULL;
    json_t *getprocessobjs = NULL;
    param = json_object();
    appobjs = json_array();
    if (NULL != appobjs) {
        len = statusobj->apps_num;
        for (i = 0; i < len; i++) {
            appobj = json_object();
            getprocessobjs = json_object();
            if (NULL != appobj) {
                json_object_set_new(appobj, "app", json_string(statusobj->apps[i].app));
                json_object_set_new(appobj, "version", json_string(statusobj->apps[i].version));
                json_object_set_new(appobj, "appHash", json_string(statusobj->apps[i].appHash));
                json_object_set_new(appobj, "srvNumber", json_integer(statusobj->apps[i].srvNumber));
                sg_getprocess(getprocessobjs, statusobj->apps[i]);
                json_object_set_new(appobj, "process", getprocessobjs);
                json_array_append_new(appobjs, appobj);
            }
        }
    }
    json_object_set_new(param, "container", json_string(statusobj->container));
    json_object_set_new(param, "apps", appobjs);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_STATUS, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//Ӧ��״̬�ϱ�
void sg_pack_app_status_get_data(uint16_t code, int32_t mid, const char *error_msg, app_status_reply_s *statusobj, char *msg)
{
    uint16_t i = 0;
    uint16_t len = 0;
    json_t *param = NULL;
    json_t *appobj = NULL;
    json_t *appobjs = NULL;
    json_t *getprocessobjs = NULL;
    param = json_object();
    appobjs = json_array();
    if (NULL != appobjs) {
        len = statusobj->apps_num;
        for (i = 0; i < len; i++) {
            appobj = json_object();
            getprocessobjs = json_object();
            if (NULL != appobj) {
                json_object_set_new(appobj, "app", json_string(statusobj->apps[i].app));
                json_object_set_new(appobj, "version", json_string(statusobj->apps[i].version));
                json_object_set_new(appobj, "appHash", json_string(statusobj->apps[i].appHash));
                json_object_set_new(appobj, "srvNumber", json_integer(statusobj->apps[i].srvNumber));
                sg_getprocess(getprocessobjs, statusobj->apps[i]);
                json_object_set_new(appobj, "process", getprocessobjs);
                json_array_append_new(appobjs, appobj);
            }
        }
    }
    json_object_set_new(param, "container", json_string(statusobj->container));
    json_object_set_new(param, "apps", appobjs);
    char *mssm = sg_pack_json_msg_header(code, mid, REP_APP_STATUS, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//Ӧ���¼��ϱ�
void sg_pack_app_event_pack(uint16_t code, int32_t mid, const char *error_msg, app_event_reply_s *statusobj, char *msg)
{
    char *mssm = NULL;
    json_t *param = NULL;
    param = json_object();
    json_object_set_new(param, "container", json_string(statusobj->container));
    if (strlen(statusobj->app) != 0) {
        json_object_set_new(param, "app", json_string(statusobj->app));
    }
    json_object_set_new(param, "event", json_string(statusobj->event));
    if (strlen(statusobj->msg) != 0) {
        json_object_set_new(param, "msg", json_string(statusobj->msg));
    }
    mssm = sg_pack_json_msg_header(code, mid, EVENT_APP_ALARM, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//Ӧ����������
int sg_unpack_app_upgrade_cmd(json_t *obj, app_upgrade_cmd_s *cmdobj)
{
    json_t* file_info = NULL;
    //************************��ʼ��������*****************************************
    if (json_into_int32_t(&cmdobj->jobId, obj, "jobId") != VOS_OK) {
        return VOS_ERR;
    }
    json_into_uint32_t(&cmdobj->policy, obj, "policy");
    if (json_into_string(cmdobj->version, obj, "version") != VOS_OK) {
        return VOS_ERR;
    }
    if (json_into_string(cmdobj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    file_info = json_object_get(obj, "file");
    if (sg_getfile(file_info, &cmdobj->file) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
//Ӧ����������Ӧ��
void sg_pack_app_upgrade_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    json_t *param = NULL;
    param = json_object();
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_UPGRADE, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}
//Ӧ����־�ٻ�����
int sg_unpack_app_log_get_cmd(json_t *obj, app_log_recall_cmd_s *cmdobj)
{
    if (json_into_string(cmdobj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    if (json_into_string(cmdobj->url, obj, "url") != VOS_OK) {
        return VOS_ERR;
    }
    json_into_string(cmdobj->app, obj, "app");
    return VOS_OK;
}
//Ӧ����־�ٻ�Ӧ��
void sg_pack_app_log_get_reply(uint16_t code, int32_t mid, const char *error_msg, file_info_s *file, char *msg)
{
    json_t *param = NULL;
    json_t *sign_object = NULL;
    param = json_object();
    sign_object = json_object();
    if (NULL != sign_object) {
        json_object_set_new(sign_object, "name", json_string(file->sign.name));
        if (strlen(file->sign.url) != 0) {
            json_object_set_new(sign_object, "url", json_string(file->sign.url));
        }
        if (file->sign.size != 0) {
            json_object_set_new(sign_object, "size", json_integer(file->sign.size));
        }
        if (strlen(file->sign.md5) != 0) {
            json_object_set_new(sign_object, "md5", json_string(file->sign.md5));
        }
    }
    json_object_set_new(param, "name", json_string(file->name));
    if (strlen(file->fileType) != 0) {
        json_object_set_new(param, "fileType", json_string(file->fileType));
    }
    if (strlen(file->url) != 0) {
        json_object_set_new(param, "url", json_string(file->url));
    }
    json_object_set_new(param, "size", json_integer(file->size));
    json_object_set_new(param, "md5", json_string(file->md5));
    json_object_set_new(param, "sign", sign_object);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_LOG, error_msg, param);
    memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1);
    if (NULL != mssm) {
        free(mssm);
    }
    if (NULL != param) {
        json_decref(param);
    }
}

