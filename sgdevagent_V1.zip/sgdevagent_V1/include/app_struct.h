/*=====================================================================
 * 文件：app_struct.h
 *
 * 描述：公共定义的头文件定义
 *
 * 作者：田振超			2020年10月15日10:00:49
 *
 * 修改记录：
 =====================================================================*/

#ifndef _APP_STRUCT_H_
#define _APP_STRUCT_H_

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdint.h>
 // #include "vrp_timer.h"
 // #include "vrp_queue.h"
 // #include "vrp_task.h"
#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "ssp_mid.h"
#include "jansson.h"
#include "ssp_syslog.h"
#include "net_common.h"
#include "ifm_status.h"

//syslog相关
#define SGDEV_MODULE   "SGDEV"

/* MQTT订阅发布相关 */
#define ADDRESS     "tcp://127.0.0.1:1883"
#define QOS         0
#define TIMEOUT     10000L
#define G_CLIENTID  "msk_data_pub" 
#define MSG_ARRVD_MAX_LEN   3*1024

#define REBOOT_EDGE_RESET 1
#define REBOOT_EDGE_SET 0       //组件重启宏

#define MODE_MQTT 1
#define MODE_RMTMAN 0

/* 基本数据类型和常量定义 */
#define MQTT_OK 0
#define MQTT_ERR 1
#define TYPE_REQUEST 1
#define TYPE_REPLY 2
#define DEVICE_DELETE       2
#define DEVICE_ONLINE       1
#define DEVICE_OFFLINE      0
#define CHAR char
#define UINT32 unsigned int
#define ULONG unsigned long 
#define DEV_INFO_MSG_BUFFER_LEN 1024
#define DEV_INFO_MSG_BUFFER_NUM 16

#define REPORT 1    //容器状态上报
#define INQUIRE 2   //容器状态查询

#define MAX_COUNT 3
#define TIME_LOCAL 0  
#define TIME_UTC 1     //定义使用UTC时间

#define FLAG_NULL   0
#define FLAG_FAULT  1
#define FLAG_RECOVER  2

#define DATA16_LEN 16
#define DATA32_LEN 32    //定义数组长度宏定义
#define DATA64_LEN 64   
#define DATA128_LEN 128
#define DATA256_LEN 256
#define DATA512_LEN 512

#define UPGRADEPACH 0
#define UPGRADEHOST 3

//表4 应答 code 编码格式
#define CODE_NULL           0 //null
#define REQUEST_SUCCESS     200 //请求成功
#define REQUEST_WAIT        202 //请求被接受，但是服务器未处理完
#define REQUEST_FAILED      400 //请求失败
#define REQUEST_CERTIFICATE 401 //请求未认证/认证错误
#define REQUEST_REFUSE      403 //请求被拒绝
#define REQUEST_NOTEXITS    404 //请求的资源不存在
#define REQUEST_TIMEOUT     408 //请求超出了服务器的等待时间
#define OTHER_ERROR         500 //其他错误

//表28 设备资源告警事件
#define DEV_CPU_UTIL_EXCEEDS   1001 //cpu 利用率超过阀值  级别：一般
#define DEV_CPU_UTIL_RESTORE   1002 //cpu 利用率超过阀值恢复 级别：一般
#define DEV_MEM_UTIL_EXCEEDS   1003 //内存 使用率超过阀值 级别：一般
#define DEV_MEM_UTIL_RESTORE   1004 //内存 使用率超过阀值恢复 级别：一般
#define DEV_DISK_UTIL_EXCEEDS  1005 //磁盘 空间使用率超过阀值 级别：一般

//表29 设备安全事件
#define OPEN_ILLEGAL_PORT  2001 //开放非法端口 级别：紧急
#define NET_OUTLINK_EVENT  2002 //网络外联事件 级别：紧急
#define USB_ILLEGAL_INSERT 2003 //USB 存储设备非法插入 级别：紧急
#define PORT_OCCUPY        2004 //串口占用     级别：一般

//表30 设备故障事件
#define FAN_STOP_RUNNING   3001 //散热风扇停止运行 级别：一般
#define EXT_DEV_ABNORMAL   3002 //外接装置异常 级别：一般
#define HIGH_TEMP          3003 //超高温 级别：紧急
#define HIGH_TEMP_RESTORE  3004 //超高温恢复 级别：一般
#define LOW_TEMP           3005 //超低温 级别：紧急
#define LOW_TEMP_RESTORE   3006 //超低温恢复 级别：一般
#define POWER_DOWN         3007 //掉电 级别：紧急   
#define OPEN_THE_LID       3008 //上盖开盖 级别：紧急
#define END_CAP_OPEN       3009 //端盖开盖 级别：紧急
#define COMPONENT_RESTART  3010 //重要组件异常重启（在 msg 中填写组件名称） 级别：紧急
#define TERMINAL_RESTART   3011 //终端重启上报 级别：紧急

//表56 事件编号 4xxx：容器告警事件
#define CON_CPU_UTIL_EXCEEDS   4001 //容器cpu利用率超过阀值  级别：一般
#define CON_CPU_UTIL_RESTORE   4002 //容器cpu利用率超过阀值恢复 级别：一般
#define CON_MEM_UTIL_EXCEEDS   4003 //容器内存使用率超过阀值 级别：一般
#define CON_MEM_UTIL_RESTORE   4004 //容器内存使用率超过阀值恢复 级别：一般
#define CON_DISK_UTIL_EXCEEDS  4005 //容器磁盘空间使用率超过阀值 级别：一般
#define CON_RESTART_ABNORMAL   4006 //容器异常重启 级别：严重
#define CONTAINER_FAILURE      4007 //容器故障 级别：严重

//表80 event 应用告警事件
#define APP_CPU_UTIL_EXCEEDS   5001 //应用cpu利用率超过阀值  级别：一般
#define APP_CPU_UTIL_RESTORE   5002 //应用cpu利用率超过阀值恢复 级别：一般
#define APP_MEM_UTIL_EXCEEDS   5003 //应用内存使用率超过阀值 级别：一般
#define APP_MEM_UTIL_RESTORE   5004 //应用内存使用率超过阀值恢复 级别：一般
#define APP_UPGRADE            5005 //应用升级 级别：一般
#define APP_RESTART_ABNORMAL   5006 //App异常重启 级别：一般

/*Start================MQTT定义=======================*/

/* MQTT消息通用部分结构体 */
typedef struct mqtt_header {
    char        token[40];
    char        timestamp[32];
}mqtt_header_s;
/*End================MQTT定义=======================*/

typedef struct requestIDa {
    int		lenth;
    char	requestid[48];
}requestIDMap;

/*Start================设备信息定义=======================*/
typedef struct mqtt_data_info {
    char msg_send[MSG_ARRVD_MAX_LEN];
    char pubtopic[256];
}mqtt_data_info_s;
/*End================设备信息定义=======================*/

#define F_DESC(x) 1
#define SEM_MAX_WAIT_TIMES 20
#define MAX_QUE_DEPTH 4096
#define MSECOND 1000000
#define TEN_MSECOND 100000
#define REQUEST_TYPE 77
#define JSON_BUF_SIZE 256
#define CPU_USAGE 1
#define MEM_USAGE 2
#define STORAGE_USAGE 3


/********************type字段说明：***************************
所有下发命令以“CMD_”开头
所有上报事件均以“EVENT_”或“REP_”开头
************************************************************/
#define EVENT_LINKUP		"EVENT_LINKUP"      //设备接入               **
#define EVENT_LINKDOWN		"EVENT_LINKDOWN"    //设备主动断开上报        **
#define EVENT_HEARTBEAT		"EVENT_HEARTBEAT"   //设备心跳请求            **
#define CMD_SYS_UPGRADE		"CMD_SYS_UPGRADE"   //设备升级命令
#define CMD_STATUS_QUERY	"CMD_STATUS_QUERY"  //设备升级状态查询命令
#define REP_SYS_STATUS		"REP_SYS_STATUS"    //设备状态上报            **
#define CMD_SYS_STATUS		"CMD_SYS_STATUS"    //设备状态查询命令
#define CMD_INFO_QUERY		"CMD_INFO_QUERY"    //设备信息查询命令
#define CMD_SYS_SET_CONFIG	"CMD_SYS_SET_CONFIG"//设备管理参数修改命令
#define CMD_DATETIME_SYN	"CMD_DATETIME_SYN"  //设备时间同步命令
#define EVENT_SYS_ALARM 	"EVENT_SYS_ALARM"   //设备事件上报            **
#define CMD_SYS_LOG			"CMD_SYS_LOG"       //设备日志召回
#define CMD_CTRL			"CMD_CTRL"          //设备控制命令
#define CMD_CON_INSTALL		"CMD_CON_INSTALL"
#define CMD_CON_START		"CMD_CON_START"
#define CMD_CON_STOP		"CMD_CON_STOP"
#define CMD_CON_REMOVE		"CMD_CON_REMOVE"
#define CMD_CON_SET_CONFIG	"CMD_CON_SET_CONFIG"
#define CMD_CON_GET_CONFIG	"CMD_CON_GET_CONFIG"
#define CMD_CON_STATUS		"CMD_CON_STATUS"
#define REP_CON_STATUS		"REP_CON_STATUS"
#define EVENT_CON_ALARM		"EVENT_CON_ALARM"
#define CMD_CON_UPGRADE		"CMD_CON_UPGRADE"
#define REP_JOB_RESULT		"REP_JOB_RESULT"
#define CMD_CON_LOG			"CMD_CON_LOG"
#define CMD_APP_INSTALL		"CMD_APP_INSTALL"
#define CMD_APP_START		"CMD_APP_START"
#define CMD_APP_STOP		"CMD_APP_STOP"
#define CMD_APP_REMOVE		"CMD_APP_REMOVE"
#define CMD_APP_ENABLE		"CMD_APP_ENABLE"
#define CMD_APP_UNENABLE	"CMD_APP_UNENABLE"
#define CMD_APP_SET_CONFIG	"CMD_APP_SET_CONFIG"
#define CMD_APP_GET_CONFIG	"CMD_APP_GET_CONFIG"
#define CMD_APP_STATUS		"CMD_APP_STATUS"
#define REP_APP_STATUS		"REP_APP_STATUS"
#define EVENT_APP_ALARM		"EVENT_APP_ALARM"
#define CMD_APP_UPGRADE		"CMD_APP_UPGRADE"
#define CMD_APP_LOG			"CMD_APP_LOG"

typedef enum {
    TASK_EXE_STATUS_NULL = 0,           //0
    TASK_EXE_DEV_UP = 1,                        //设备升级状态应答
    TASK_EXE_CONTAINER_INSTALL = 2,             //容器安装状态查询应答
    TASK_EXE_CONTAINER_UP = 3,                  //容器升级状态查询应答
    TASK_EXE_APP_INSTALL = 4,                   //应用安装状态查询应答
    TASK_EXE_APP_UP = 5,                        //应用升级状态查询应答
    TASK_NUM
} exe_task_type_tag_t;

typedef enum {
    STATUS_NULL = 0,
    STATUS_PRE_DOWNLOAD = 1,
    STATUS_EXE_DOWNLOAD = 2,
    STATUS_PRE_INSTALL = 3,
    STATUS_EXE_INSTALL = 4,
    STATUS_FINISH_INSTALL = 5,
    STATUS_NUM
} up_status_tag_t;

typedef enum {
    QUEUE_NULL = 0,
    QUEUE_UNPACK = 1,
    QUEUE_PACK = 2,
    QUEUE_RESULT = 3,
    QUEUE_DEVTASK = 4,
    QUEUE_CONTAINERTASK = 5,
    QUEUE_APPTASK = 6,
    QUEUE_NUM
} queue_tag_t;

/*#############################################类型枚举##############################################*/
typedef enum {
    TAG_CMD_NULL = 0,
    TAG_EVENT_LINKUP = 1,               //设备接入
    TAG_EVENT_LINKDOWN,                 //设备主动断开上报
    TAG_EVENT_HEARTBEAT,                //设备心跳请求
    TAG_CMD_SYS_UPGRADE,                 //设备升级命令
    TAG_CMD_STATUS_QUERY,               //设备升级状态查询 //设备升级状态查询应答
    TAG_CMD_STATUS_QUERY_CONT_INS,      //容器安装状态查询命令 //容器安装状态查询应答
    TAG_CMD_STATUS_QUERY_CONT_UP,		//容器升级状态查询命令    //容器升级状态查询应答
    TAG_CMD_STATUS_QUERY_APP_INS,		//应用安装状态查询命令      //应用安装状态查询应答
    TAG_CMD_STATUS_QUERY_APP_UP,		//应用升级状态查询命令//应用升级状态查询应答
    TAG_REP_SYS_STATUS,                  //设备状态上报
    TAG_CMD_SYS_STATUS,                  //设备状态查询
    TAG_CMD_INFO_QUERY,                  //设备信息查询命令 //设备信息查询命令应答
    TAG_CMD_SYS_SET_CONFIG,              //设备管理参数修改命令 //设备管理参数修改命令应答
    TAG_CMD_DATETIME_SYN,                //设备时间同步命令//设备时间同步命令应答
    TAG_EVENT_SYS_ALARM,                 //设备事件上报    
    TAG_CMD_SYS_LOG,                     //设备日志召回        //设备日志召回应答
    TAG_CMD_CTRL,                        //设备控制命令//设备控制命令应答
    TAG_CMD_CON_INSTALL,                //容器安装//容器安装控制应答
    TAG_CMD_CON_START,                  //启动容器 //容器启动控制命令应答
    TAG_CMD_CON_STOP,                   //容器停止//容器停止控制应答
    TAG_CMD_CON_REMOVE,                 //删除容器//容器删除控制应答
    TAG_CMD_CON_SET_CONFIG,             //容器配置修改//容器配置修改应答
    TAG_CMD_CON_GET_CONFIG,             //容器配置查询//容器配置查询应答 
    TAG_CMD_CON_STATUS,                 //容器状态查询 //容器状态查询应答
    TAG_REP_CON_STATUS,                 //容器状态上报
    TAG_EVENT_CON_ALARM,                //容器事件上报
    TAG_CMD_CON_UPGRADE,                //容器升级 //容器升级命令应答
    TAG_REP_JOB_RESULT,                 //容器升级结果上报      //应用安装结果上报  //应用升级结果上报                                                      
    TAG_CMD_CON_LOG,                    //容器日志召回 //容器日志召回应答
    TAG_CMD_APP_INSTALL,                //应用安装控制命令 //应用安装控制命令应答
    TAG_CMD_APP_START,                  //应用启动
    TAG_CMD_APP_STOP,                   //应用停止
    TAG_CMD_APP_REMOVE,                 //应用卸载
    TAG_CMD_APP_ENABLE,                 //应用使能
    TAG_CMD_APP_UNENABLE,               //应用去使能
    TAG_CMD_APP_SET_CONFIG,             //应用配置修改命令 //应用配置修改命令应答
    TAG_CMD_APP_GET_CONFIG,             //应用配置查询命令            //应用配置查询应答
    TAG_CMD_APP_STATUS,                 //应用状态查询命令 //应用状态查询应答
    TAG_REP_APP_STATUS,                 //应用状态上报
    TAG_EVENT_APP_ALARM,                //应用事件上报                                
    TAG_CMD_APP_UPGRADE,                //应用升级命令 //应用升级命令应答
    TAG_CMD_APP_LOG                     //应用日志召回 //应用日志召回应答
} cmd_tag_t;

typedef unsigned char method_t; //方法类型

// int memcpy_safe(void *s1, int s1_size, void *s2, int s2_size, int n);

// int GeneratedTimeStr(time_t time_val, char* time_buff, size_t buff_len, int use_utc);

//请求报文头
typedef struct mqtt_request_header {
    int32_t          mid;
    char             deviceId[DATA64_LEN];
    char             timestamp[DATA32_LEN];
    int32_t          expire;
    char             type[DATA32_LEN];
    json_t*          param;
}mqtt_request_header_s;

//应答报文头
typedef struct mqtt_reply_header {
    int32_t          mid;
    char             deviceId[DATA64_LEN];
    char             timestamp[DATA32_LEN];
    char             type[DATA32_LEN];
    json_t*          param;
    uint16_t         code;
    char             msg[DATA256_LEN];
}mqtt_reply_header_s;

//A.1  设备信息字段：dev
typedef struct dev_info {
    char             devType[DATA64_LEN];     //终端类型
    char             devName[DATA64_LEN];     //终端名称 
    char             mfgInfo[DATA64_LEN];     //终端厂商信息
    char             devStatus[DATA64_LEN];   //终端状态
    char             hardVersion[DATA64_LEN]; //终端硬件版本号    
}dev_info_s;

//A.2 CPU 信息字段:cpu
typedef struct cpu_info {
    uint8_t          cpus;                    //CPU 核数
    double           frequency;               //CPU 主频 GHz 为单位 
    uint32_t         cache;                   //CPU 缓存以 MB/核为单位
    char             arch[DATA64_LEN];        //CPU 架构
    uint32_t         cpuLmt;                  //CPU 监控阈值    
}cpu_info_s;

//A.3内存信息字段:mem
typedef struct mem_info {
    uint32_t         phy;                     //物理内存，以M为单位
    uint32_t         virt;                    //虚拟内存，以M为单位 
    uint8_t          memLmt;                  //内存监控阈值，例如50表示50% 
}mem_info_s;

//A.4  硬盘信息字段:disk
typedef struct disk_info {
    uint32_t         disk;                    //磁盘空间，以M为单位
    uint8_t          diskLmt;                 //磁盘监控阈值，例如50表示50%
}disk_info_s;

//A.5  外接设备信息字段:links
typedef struct link_info {
    char            type[DATA32_LEN];         //接口的类型，如以太网口,4G,"Ethernet","4G"     
    char            name[DATA32_LEN];         //接口的名称如为以太网口，4G,则形如"eth1","ppp-0"
    char            id[DATA32_LEN];           //接口的ID,主要用于HPLC和4G等外部模块
    char            mac[DATA32_LEN];          //如接口为以太网，4G，则添加mac地址，形如"B8-85-74-15-A5-3E"  
}link_info_s;
//A.6  操作系统信息字段:os
typedef struct os_info {
    char            distro[DATA64_LEN];        //操作系统的名称，如"Ubuntu""Redhat"
    char            version[DATA64_LEN];       //操作系统版本，如"18.10"
    char            kernel[DATA64_LEN];        //操作系统内核，如"3.10-17"
    char            softVersion[DATA64_LEN];   //平台软件组件版本，如"V01.024"
    char            patchVersion[DATA64_LEN];  //平台软件组件补丁版本，如"PV01.0001"
}os_info_s;

//A.7   cpu 阈值信息字段: cfgCpu
typedef struct cfg_cpu_info {
    unsigned int     cpus;                        //CPU核数（例如值为2,3,4）
    unsigned int     cpuLmt;                      //CPU监控阈值
}cfg_cpu_info_s;

//A.8   内存阈值信息字段: cfgMem
typedef struct cfg_mem_info {
    unsigned int     memory;                      //内存限值,单位： M Byte
    unsigned int     memLmt;                      //内存监控阈值，百分数
}cfg_mem_info_s;

//A.9   硬盘阈值信息字段: cfgDisk
typedef struct cfg_disk_info {
    unsigned int     disk;                        //存储限值，单位： M Byte
    unsigned int     diskLmt;                     //磁盘存储监控阈值，百分数
}cfg_disk_info_s;

//A.11  数字签证信息字段:sign
typedef struct sign_info {
    char            name[DATA64_LEN];          //数字证书文件名字
    char            url[DATA64_LEN];           //数字证书文件路径，即 url 地址，如“https://123.123.123.123:6789”
    uint32_t        size;                      //文件的大小，单位： KBytes     
    char            md5[DATA64_LEN];           //数字证书文件的 md5 值，用于校验文件
}sign_info_s;

//A.10  文件信息字段:file
typedef struct file_info {
    char            name[DATA64_LEN];          //文件的名字
    char            fileType[DATA64_LEN];      //文件类型，如压缩文件（tar）等，由平台和终端统一规定
    char            url[DATA64_LEN];           //文件路径，即 url 地址，如“https://123.123.123.123:6789”
    uint32_t        size;                      //文件的大小，单位： KBytes     
    char            md5[DATA64_LEN];           //文件的 md5 值，用于校验文件
    sign_info_s     sign;                      //文件的数字签证信息
}file_info_s;


/* 1. (2) 设备接入请求 */
typedef struct dev_acc_req {
    dev_info_s       dev;                       //终端信息，详见附录 A
    cpu_info_s       cpu;                       //CPU 信息，详见附录 A  
    mem_info_s       mem;                       //内存信息，详见附录 A
    disk_info_s      disk;                      //磁盘信息，详见附录 A
    os_info_s        os;                        //操作系统信息，详见附录 A
    link_info_s      *links;         // 其他的终端信息，其中每个元素为一个 JSON对象，其定义详见附录 A   
    int              link_len;
}dev_acc_req_s;

/* 1. (3) 设备接入应答  无param*/

/* 1. (4)设备主动断开上报  单变量不需要定义结构体*/

/* 1. (5) 设备心跳请求  */
typedef struct heart_request {
    char            deviceId[DATA64_LEN];        //边设备唯一标识 
    char            timestamp[DATA32_LEN];       //消息发送的时间戳， CST 时间,精度到秒
    char            type[DATA32_LEN];            //EVENT_HEARTBEAT
}heart_request_s;

/* 1. (6) 设备心跳应答  */
typedef struct heart_reply {
    char            deviceId[DATA64_LEN];          //边设备唯一标识 
    char            timestamp[DATA32_LEN];         //消息发送的时间戳， CST 时间,精度到秒 
    char            type[DATA32_LEN];              //EVENT_HEARTBEAT             
    uint16_t        code;                          //标识应答的返回码:200
}heart_reply_s;

/* 2. (2) 设备升级命令  */
typedef struct device_upgrade {
    int32_t         jobId;                         //本升级操作作为一个工作任务，分配的 ID
    uint32_t        policy;                        //从接收到该升级指令时间后开始升级的时间间隔（单位：秒），缺省或等于 0 时，表示立即升级
    char            version[DATA64_LEN];           //升级后的版本号             
    uint8_t         upgradeType;                   //升级类型， 0 表示补丁升级， 1 表示文件系统升级， 2 表示内核升级， 3 表示全量升级（文件系统+内核升级）
    file_info_s     file;                          //升级文件信息
}device_upgrade_s;

/* 2. (3) 设备升级命令应答  无param*/

/* 2. (4)设备升级状态查询命令  单变量不需要定义结构体*/

/* 2. (5)设备升级状态查询应答 */
typedef struct dev_status_reply {
    int32_t          jobId;                         //升级操作作为一个工作任务，分配的 ID
    uint8_t          progress;                      //进度。百分比，省略百分号
    uint8_t          state;                         /*描述当前升级过程执行过程。包括：
                                                    1：待下载
                                                    2：下载中
                                                    3：待安装
                                                    4：安装中
                                                    5：安装完毕*/
}dev_status_reply_s;

/* 2. (6)设备升级结果上报 ，容器，应用升级/安装都一样 */
typedef struct dev_upgrede_res_reply {
    int32_t             jobId;                  //升级操作作为一个工作任务，分配的 ID
    uint16_t            code;                   //容器升级结果编码
    char                msg[DATA64_LEN];        //容器升级结果描述，例如下载地址不可用
}dev_upgrede_res_reply_s;

//内存使用情况
typedef struct mem_used {
    int32_t         phy;                            //占用的物理内存（例如 50 表示 50%）
    int32_t         virt;                           //占用的虚拟内存（例如 50 表示 50%）
}mem_used_s;

//外接设备的相关信息
typedef struct link_dev_info {
    char            name[DATA64_LEN];               //接口的名称如为以太网口，则形如“eth1”
    char            status[DATA64_LEN];             //设备接口状态，如up/down
}link_dev_info_s;

/* 3. (1)设备状态上报 */
typedef struct dev_sta_reply {
    int             cpuRate;                       //CPU 负载（例如 50 表示 50%）
    mem_used_s      mem_used;                      //内存使用情况
    uint8_t         diskUsed;                      //磁盘占用率（例如 50 表示 50%）
    int             tempValue;                     //主板（cpu）温度，单位：摄氏度℃
    char            devDateTime[DATA64_LEN];       //设备当前时间
    char            devStDateTime[DATA64_LEN];     //设备最近一次启动时间    
    uint32_t        devRunTime;                    //设备运行时长，单位：秒
    link_dev_info_s *linkState;                    //其他的设备信息，其中每个元素表示一类设备元素
    char            longitude[DATA64_LEN];         //地理位置信息经度 
    char            latitude[DATA64_LEN];          //地理位置信息纬度 
    int             link_len;
}dev_sta_reply_s;

/* 3. (2) 设备状态查询命令  无param*/

/* 3. (3) 设备状态查询命令应答 和设备状态上报一样*/

/* 3. (4) 设备信息查询命令  无param*/

//描述温度监控信息
typedef struct temp_info {
    int         temLow;                      //主板温度监控低温阈值   
    int         temHigh;                     //主板温度监控高温阈值
}temp_info_s;

//状态主动上报的上报时间间隔
typedef struct rep_period {
    uint32_t        devPeriod;                  //终端状态主动上报的时间间隔，单位：秒
    uint32_t        conPeriod;                  //容器状态主动上报的时间间隔，单位：秒
    uint32_t        appPeriod;                  //APP 状态主动上报的时间间隔，单位：秒
    uint32_t        heartPeriod;                //终端应用层心跳上报的时间间隔,单位：秒
}rep_period_s;

/* 3. (5) 设备信息查询命令应答 */
typedef struct dev_info_inq_reply {
    dev_info_s       dev;                       //终端信息，详见附录A
    cpu_info_s       cpu;                       //CPU 信息，详见附录 A  
    mem_info_s       mem;                       //内存信息，详见附录 A
    disk_info_s      disk;                      //磁盘信息，详见附录 A
    temp_info_s      temperature;               //温度监控信息
    os_info_s        os;                        //操作系统信息，详见附录 A
    link_info_s      *links;                     //其他的终端信息，其中每个元素为一个 JSON对象，其定义详见附录 A    
    rep_period_s     rep_period;                //状态主动上报的上报时间间隔
    int              link_len;
}dev_info_inq_reply_s;

/* 3. (6) 设备管理参数修改命令 */
typedef struct dev_man_conf_command {
    char             devName[DATA64_LEN];       //设备名称    
    uint8_t          cpuLmt;                    //CPU 监控阈值,例如 50 表示 50%
    uint8_t          memLmt;                    //内存监控阈值,例如 50 表示 50%   
    uint8_t          diskLmt;                   //磁盘监控阈值,例如 50 表示 50%
    temp_info_s      temperature;               //温度监控信息
    rep_period_s     rep_period;                //状态主动上报的上报时间间隔
}dev_man_conf_command_s;

/* 3. (7) 设备管理参数修改命令应答  无param*/

/* 3. (8) 设备时间同步命令 */
typedef struct dev_time_command {
    char             dateTime[DATA64_LEN];       //日期和时间参数 
    char             timeZone[DATA64_LEN];       //时区
}dev_time_command_s;

/* 3. (9) 设备时间同步命令应答 无param*/

/* 3. (10) 设备事件上报 */
typedef struct dev_event_reply {
    char                event[DATA64_LEN];        //下表中的一些典型事件用 1001,1002,1003 表示
    char                msg[DATA64_LEN];          //msg 给出事件具体情况的描述，最长不超过256 字符
}dev_thing_reply_s;

/* 3. (11) 设备日志召回 */
typedef struct dev_log_recall {
    char                url[DATA64_LEN];        //文件上传路径
    uint8_t             logType;                //日志类型， 0-全部类型日志； 1-系统日志； 2-操作日志； 3-安全日志； 4-驱动日志； 5-broker日志、 6-审计日志； 7-调试日志； 8-255 用于扩展。
}dev_log_recall_s;

/* 3. (12)设备日志召回应答  单变量不需要定义结构体*/

/* 4. (1)设备控制命令  单变量不需要定义结构体*/

/* 4. (2) 设备控制命令应答 无param*/

//描述随容器一起安装到容器内的应用软件信息
typedef struct with_app_info {
    char                version[DATA64_LEN];    //版本号
    file_info_s         file;                   //应用文件信息
    cfg_cpu_info_s      cfgCpu;                 //cpu 资源配置参数
    cfg_mem_info_s      cfgMem;                 //memory 资源配置参数
    char                enable[DATA64_LEN];     //使能/去使能状态定义，使能为“1”，去使能为“0”
}with_app_info_s;

/* 1. (2) 容器安装控制命令 */
typedef struct container_install_cmd {
    int32_t             jobId;                  //作为一个工作任务，分配的 ID
    uint32_t            policy;                 //从接收到该安装指令时间后开始安装的时间间隔（单位：秒），缺省或等于 0 时，表示立即升级
    char                container[DATA64_LEN];  //容器名称
    file_info_s         image;                  //容器镜像
    with_app_info_s     withAPP;                //随容器安装时，被添加的 APP 名称  
    cfg_cpu_info_s      cfgCpu;                 //cpu 资源配置参数
    cfg_mem_info_s      cfgMem;                 //memory 资源配置参数
    cfg_disk_info_s     cfgDisk;                //disk 资源配置参数
    char                port[DATA64_LEN];       //容器端口资源配置参数
    char                mount[DATA64_LEN][DATA64_LEN]; //映射的本地文件目录资源配置参数
    char                dev[DATA64_LEN][DATA64_LEN];   //映射的本地物理接口资源配置参数
    uint16_t            mount_len;
    uint16_t            dev_len;

}container_install_cmd_s;

/* 1. (3)容器安装控制应答  单变量不需要定义结构体*/

/* 1. (4)容器安装状态查询命令  单变量不需要定义结构体*/

/* 1. (5)容器安装状态查询应答 */
typedef struct container_install_inq_reply {
    int32_t             jobId;                  //升级操作作为一个工作任务，分配的 ID
    uint8_t             progress;               //进度。百分比，省略百分号
    uint8_t             state;                  /*描述当前升级过程执行过程。包括：
                                                1：待下载
                                                2：下载中
                                                3：待安装
                                                4：安装中
                                                5：安装完毕*/
}container_install_inq_reply_s;

/* 1. (6)容器安装结果上报 见设备升级结果上报*/

/* 2. (2)容器启动控制命令  单变量不需要定义结构体*/

/* 2. (3) 容器启动控制命令应答 无param*/

/* 3. (2)容器停止控制命令  单变量不需要定义结构体*/

/* 3. (3)容器停止控制应答 无param*/

/* 4. (2)容器停止控制应答 单变量不需要定义结构体*/

/* 4. (3)容器删除控制应答 无param*/

/* 5. (2)容器配置修改命令 */
typedef struct container_conf_cmd {
    char                container[DATA64_LEN];  //容器名称  
    cfg_cpu_info_s      cfgCpu;                 //cpu 资源配置参数,详见附录 A
    cfg_mem_info_s      cfgMem;                 //memory 资源配置参数,详见附录 A
    cfg_disk_info_s     cfgDisk;                //disk 资源配置参数,详见附录 A
    char                port[DATA64_LEN];       //端口资源配置参数
    char                mount[DATA64_LEN][DATA64_LEN]; //映射的本地文件目录资源配置参数
    char                dev[DATA64_LEN][DATA64_LEN];   //映射的本地物理接口资源配置参数
    uint16_t            mount_len;
    uint16_t            dev_len;
}container_conf_cmd_s;

/* 5. (3)容器配置修改应答 无param*/

/* 6. (2)容器配置查询命令 无param*/

/* 6. (3)容器配置查询应答 */
typedef struct container_config_reply {
    container_conf_cmd_s    *contPara;         // 其他的终端信息，其中每个元素为一个 JSON对象，其定义详见附录 A
    uint16_t                contPara_len;
}container_config_reply_s;


/* 7. (2)容器状态查询命令 无param*/

/* 7. (3)容器状态查询应答 */
typedef struct container_status_reply {
    char                container[DATA64_LEN];  //容器名称
    char                version[DATA64_LEN];    //容器版本号
    char                state[DATA64_LEN];      //容器运行状态， running 或 stopped
    int                 cpuRate;                //CPU 占用率，百分比
    int                 memUsed;                //内存占用率，百分比       
    int                 diskUsed;               //磁盘占用率，百分比 
    char                ip[DATA64_LEN];         //IP 地址及端口
    char                created[DATA64_LEN];    //创建时间           ***暂时没有
    char                started[DATA64_LEN];    //最近一次启动时间    
    time_t              lifeTime;               //运行时间，单位：秒
    char                image[DATA64_LEN];      //容器镜像信息       ***暂时没有
    int                 container_len;
}container_status_reply_s;

/* 8 容器状态上报  和7.（3）相同*/

/* 9  容器事件上报 */
typedef struct container_event_report {
    char                container[DATA64_LEN];  //容器名称     
    char                event[DATA64_LEN];      //下表中的一些典型事件用 4001,4002,4003 表示
    char                msg[DATA64_LEN];        //msg 给出事件具体情况的描述，最长不超过 256字符
}container_event_report_s;

/* 10. (2)容器升级命令 */
typedef struct container_upgrade_cmd {
    int32_t             jobId;                  //本升级操作作为一个工作任务，分配的 ID
    uint32_t            policy;                 //从接收到该升级指令时间后开始升级的时间间隔（单位：秒），缺省或等于 0 时，表示立即升级
    char                version[DATA64_LEN];    //升级后的版本号
    file_info_s         file;                   //文件信息
}container_upgrade_cmd_s;

/* 10. (3)容器升级命令应答 无param*/

/* 10. (4)容器升级状态查询命令  单变量不需要定义结构体*/

/* 10. (5)容器升级状态查询应答 */
typedef struct container_upgrede_inq_reply {
    int32_t             jobId;                  //升级操作作为一个工作任务，分配的 ID
    uint8_t             progress;               //进度。百分比，省略百分号
    uint8_t             state;                  /*描述当前升级过程执行过程。包括：
                                                1：待下载
                                                2：下载中
                                                3：待安装
                                                4：安装中
                                                5：安装完毕*/
}container_upgrede_inq_reply_s;

/* 10. (6)容器升级结果上报 在设备中可找到 */


/* 11. (1) 容器日志召回命令 */
typedef struct container_log_recall_cmd {
    char                container[DATA64_LEN];  //容器名称，如果容器名称不出现，则召回所有容器的日志
    char                url[DATA64_LEN];        //文件上传路径
}container_log_recall_cmd_s;

/* 11. (2)容器日志召回应答  单变量不需要定义结构体*/

/* 1. (2) 应用安装控制命令 */
typedef struct app_install_cmd {
    int32_t             jobId;                  //本升级操作作为一个工作任务，分配的 ID
    uint32_t            policy;                 //从接收到该安装指令时间后开始安装的时间间隔（单位：秒），缺省或等于 0 时，表示立即升级
    char                container[DATA64_LEN];  //容器名字
    char                version[DATA64_LEN];    //应用版本号
    file_info_s         file;                   //升级的 APP，详见附录 A
    cfg_cpu_info_s      cfgCpu;                 //cpu 资源配置参数,详见附录 A
    cfg_mem_info_s      cfgMem;                 //memory 资源配置参数,详见附录 A
    char                enable[DATA64_LEN];     //使能/去使能状态定义，使能为“1”，去使能为“0”
    char                app[DATA64_LEN];        //应用名称
}app_install_cmd_s;

/* 1. (3)应用安装控制命令应答 无param*/

/* 1. (4)应用安装状态查询命令  单变量不需要定义结构体*/

/* 1. (5) 应用安装状态查询应答 */
typedef struct app_install_inq_reply {
    int32_t           jobId;                  //升级操作作为一个工作任务，分配的 ID
    uint8_t           progress;               //进度。百分比，省略百分号
    uint8_t           state;                  /*描述当前升级过程执行过程。包括：
                                                1：待下载
                                                2：下载中
                                                3：待安装
                                                4：安装中
                                                5：安装完毕*/
}app_install_inq_reply_s;

/* 1. (6)应用安装结果上报  见设备升级结果上报 */


/* 2. (2)应用控制命令 */
typedef struct app_control_cmd {
    char                container[DATA64_LEN];  //容器名称
    char                app[DATA64_LEN];        //应用名称
}app_control_cmd_s;

/* 2. (3)应用控制命令应答 无param*/

/* 3. (2)应用配置修改命令 */
typedef struct app_conf_cmd {
    char                container[DATA64_LEN];  //容器名字
    char                app[DATA64_LEN];        //应用文件名字
    cfg_cpu_info_s      cfgCpu;                 //cpu 资源配置参数,详见附录 A
    cfg_mem_info_s      cfgMem;                 //memory 资源配置参数,详见附录 A
}app_conf_cmd_s;

/* 3. (3)应用配置修改命令应答 无param*/

/* 4. (2)应用配置查询命令  单变量不需要定义结构体*/

//表71 Array<appCfgs>字段说明
typedef struct app_cfgs_info {
    char                app[DATA64_LEN];        //应用文件名字
    cfg_cpu_info_s      cfgCpu;                 //cpu 资源配置参数,详见附录 A
    cfg_mem_info_s      cfgMem;                 //memory 资源配置参数,详见附录 A  
}app_cfgs_info_s;

/* 4. (3)应用配置查询应答 */
typedef struct app_conf_reply {
    char                container[DATA64_LEN];  //容器名字
    app_cfgs_info_s     appCfgs[DATA16_LEN];    //应用配置参数   翟工说定义的太大，这块最多不超过10个
    uint16_t            app_num;
}app_conf_reply_s;

/* 5. (2)应用状态查询命令  单变量不需要定义结构体*/

//表75 Array<process>字段说明
typedef struct process_info {
    uint32_t            srvIndex;               //进程索引
    char                srvName[DATA64_LEN];    //进程名称
    char                srvEnable[DATA64_LEN];  //服务使能状态， yes 或 no
    char                srvStatus[DATA64_LEN];  //服务状态， running 或 stopped
    uint8_t             cpuLmt;                 //CPU 检测阈值，百分比数据
    uint8_t             cpuRate;                //当前 CPU 使用率，百分比数据
    uint8_t             memLmt;                 //内存检测阈值，百分比数据
    uint8_t             memUsed;                //当前内存使用空间的大小，百分比数据
    char                startTime[DATA64_LEN];  //表示服务启动时间，百分比数据
}process_info_s;

//表74 Array<apps>报文字段说明
typedef struct apps_info {
    char                app[DATA64_LEN];        //APP 名称
    char                version[DATA32_LEN];    //APP 版本
    char                appHash[DATA64_LEN];    //APP 的哈希值
    uint32_t            srvNumber;              //当前 APP 的进程数量
    process_info_s      *process;               //进程字段
    // uint16_t            process_num;
}apps_info_s;

/* 5. (3)应用状态查询应答 */
typedef struct app_inq_reply {
    char                container[DATA64_LEN];        //容器名称
    apps_info_s         *apps;                        //app 状态参数 
    uint16_t            apps_num;
}app_inq_reply_s;

/* 6 应用状态上报 */
typedef struct app_status_reply {
    char                container[DATA64_LEN];        //容器名称
    apps_info_s         apps[DATA16_LEN];             //app 状态参数 
    uint16_t            apps_num;
}app_status_reply_s;

/* 7 应用事件上报 */
typedef struct app_event_reply {
    char                container[DATA64_LEN];        //容器名称
    char                app[DATA64_LEN];              //app 名称，如果 APP 名称不出现，则上报的是所有 APP 的统一事件。
    char                event[DATA64_LEN];            //见表 80
    char                msg[DATA64_LEN];              //msg 给出事件具体情况的描述，最长不超过256 字符
}app_event_reply_s;

/* 8. (2)应用升级命令 */
typedef struct app_upgrade_cmd {
    int32_t         jobId;                         //本升级操作作为一个工作任务，分配的 ID
    uint32_t        policy;                        //从接收到该升级指令时间后开始升级的时间间隔（单位：秒），缺省或等于 0 时，表示立即升级
    char            version[DATA64_LEN];           //升级后的版本号             
    char            container[DATA64_LEN];         //容器名称
    file_info_s     file;                          //升级文件
}app_upgrade_cmd_s;

/* 8. (3)应用升级命令应答 无param*/

/* 8. (4)应用升级状态查询命令  单变量不需要定义结构体*/

/* 8. (5)应用升级状态查询应答 */
typedef struct app_upgrede_inq_reply {
    int32_t           jobId;                  //升级操作作为一个工作任务，分配的 ID
    uint8_t           progress;               //进度。百分比，省略百分号
    uint8_t           state;                  /*描述当前升级过程执行过程。包括：
                                                1：待下载
                                                2：下载中
                                                3：待安装
                                                4：安装中
                                                5：安装完毕*/
}app_upgrede_inq_reply_s;

/* 8. (6)应用升级结果上报 见设备升级结果上报*/


/* 9. (1) 应用日志召回命令 */
typedef struct app_log_recall_cmd {
    char              container[DATA64_LEN];  //容器名称
    char              url[DATA64_LEN];        //文件上传路径
    char              app[DATA64_LEN];        //app 名称，如果 APP 名称不出现，则召回的是所有 APP 的日志。
}app_log_recall_cmd_s;



/* 设备参数 */
typedef struct sg_dev_param_info {
    uint8_t         startmode;                  // 启动模式 0正常 1专检
    char            mqtttopicversion[DATA32_LEN];//协议版本 目前为v1
    char            devid[DATA32_LEN];           //设备ID   字符串 
    char            ip[DATA32_LEN];              //IP地址   字符串 
    uint32_t        port;                        //端口号 
    char            clientid[DATA32_LEN];
    char            user[DATA32_LEN];
    char            password[DATA32_LEN];
}sg_dev_param_info_s;


/* 断面文件 */
typedef struct sg_dev_section_info {
    uint8_t         rebootReason;               //重启原因  0：正常重启  1：设备升级重启
    int32_t         jobid;
    int32_t         midid;
    char            version[DATA64_LEN];
}sg_dev_section_info_s;


//周期结构体
typedef struct sg_period_info {
    uint32_t        appperiod;                  //APP状态上报周期 单位秒 
    uint32_t        containerperiod;            //容器状态上报周期 单位秒
    uint32_t        devperiod;                  //设备状态上报周期
    uint32_t        devheartbeatperiod;         //设备心跳上报周期 
}sg_period_info_s;



/* 临时定义 */

// #define MID_SGDEV
// #define STORAGE_PATH_LEN                128
// #define STORAGE_PARTITION_NAME_LEN      50
// #define STORAGE_PARTITION_MAX_NUM       4
// #define STORAGE_CLEAN_THRESHOLD_OFFSET  10


// typedef struct {
//     int alert;
//     int warning;
//     int alert_reboot;
//     int usage;
// } cpuusage_s;

// typedef struct {
//     int alert;
//     int warning;
//     int alert_reboot;
//     int usage;
// } memoryusage_s;

// typedef struct {
//     char path[STORAGE_PATH_LEN];
//     char name[STORAGE_PARTITION_NAME_LEN];
//     int alert;
//     int warning;
//     int usage;
// } storageusage_s;


// typedef struct {
//     int tm_sec;
//     int tm_min;
//     int tm_hour;
//     int tm_mday;
//     int tm_mon;
//     int tm_year;
//     int tm_wday;
//     int tm_yday;
//     int tm_isdst;
// } sys_time_s;


// /*复位版类型*/
// typedef enum enBoardType {
//     BOARD_MAIN = 0, /*主控板*/
//     BOARD_LTE0,     /*LTE0模块*/
//     BOARD_LTE1,     /*LTE1模块*/
//     BOARD_TYPE_BUTT
// }BOARD_TYPE_E;

// /* 设备复位原因 */
// typedef enum enRebootReason {
//     REBOOT_REASON_UNKNOW = 0,          /*未知复位原因*/
//     REBOOT_REASON_USER_CMD,            /*手动命令复位*/
//     // ...
//     REBOOT_REASON_BUTT
// }REBOOT_REASON_E;





// // vm_rpc_container_status
// // #include "vm_public.h"

// #define MAX_OVA_NAME_LEN                      128
// #define VM_UUID_LEN                           128
// #define MAX_CONTAINER_NAME_LEN                64
// #define CONTAINER_DEV_LIST_NORTH_MAX_LEN      8500

// typedef struct INSTALL_OVA_PARA_NORTH {
//     int north_type; // 0:netconf 1:mqtt
//     char ova_name[MAX_OVA_NAME_LEN + 1];
//     char uuid[VM_UUID_LEN + 1];
//     char container_name[MAX_CONTAINER_NAME_LEN + 1];
//     int index;
//     int disk_size;
//     int mem_size;
//     unsigned long long cpu_mask;
//     char dev_list[CONTAINER_DEV_LIST_NORTH_MAX_LEN + 1]; // "dev:map,dev:map..."，带/dev/
//     int container_type; // 1:lxc 2:docker 3:kvm
// }INSTALL_OVA_PARA_NORTH_S;

// #define VM_PATH_MAX_128                       128
// #define MAX_VERSION_LEN                       32
// #define VM_STATUS_LEN                         32
// #define IP_STR_LEN                            32
// #define OS_TYPE_LEN                           8
// #define OS_VERSION_LEN                        64
// #define CONTAINER_USER_NAME_LEN               16
// #define VM_SUPPORT_MAX_EX_DISK                2
// #define CONTAINER_UPTIME_LEN                  128
// typedef struct {
//     char exstorage_mount_path[VM_PATH_MAX_128 + 1];
//     int exstorage_size;
//     int exstorage_usage;
//     int total_exstorage_size;
//     int total_exstorage_usage;
// }container_external_info;

// typedef struct {
//     int volume_index;
//     int disk_size;
//     int volume_disk_usage;
//     char dest_path[CONTAINER_VOLUME_DEST_PATH_MAX_LEN + 1];
//     char host_path[CONTAINER_VOLUME_DEST_PATH_MAX_LEN + 1];
// }container_volume_info;

// typedef struct CONTAINER_INFO
// {
//     char container_name[MAX_CONTAINER_NAME_LEN + 1];            //容器名称
//     char container_version[MAX_VERSION_LEN + 1];                //容器版本
//     char container_patch_version[MAX_VERSION_LEN + 1];
//     char container_status[VM_STATUS_LEN + 1];                   //容器状态
//     char container_ipaddr[IP_STR_LEN + 1];                      //容器IP
//     unsigned long long cpu_mask;
//     int cpuusage;                                               //cpu占用率
//     unsigned int container_mem_size;    
//     int memoryusage;                                            //mem占用率
//     unsigned int container_storage_size;    
//     int stroageusage;                                           //disk占用率
//     int container_arch; 
//     char container_osType[OS_TYPE_LEN + 1];
//     char container_osVersion[OS_VERSION_LEN + 1];
//     int privileged;
//     char container_user[CONTAINER_USER_NAME_LEN + 1];
//     container_external_info container_external[VM_SUPPORT_MAX_EX_DISK];
//     int host_memory_size;
//     bool verified;
//     int container_idx;
//     int container_type;
//     container_volume_info container_volume[VM_VOLUME_DATA_IMG_MAX_NUM];
//     char container_uuid[VM_UUID_LEN + 1];
//     char container_up_time[CONTAINER_UPTIME_LEN];              
//     unsigned int cpu_threshold;
//     unsigned int memory_threshold;
//     unsigned int storage_threshold;
// }CONTAINER_INFO_S;



// // #include "app_management_service_api.h"

// #define APP_MANAGEMENT_LXC_NAME_MAX_LEN 64
// #define APP_MANAGEMENT_APP_PATH_MAX_LEN 128
// #define APP_MANAGEMENT_APP_NAME_MAX_LEN 64
// #define APP_MANAGEMENT_APP_HASH_MAX_LEN 64
// #define APP_MANAGEMENT_ERRMSG_MAX_LEN   128
// #define GLOBLE_ERR_CODE_LEN             10
// typedef struct {
//     unsigned int opt;
//     char lxc_name[APP_MANAGEMENT_LXC_NAME_MAX_LEN + 1];
//     char app_name[APP_MANAGEMENT_APP_NAME_MAX_LEN + 1];
//     char app_file[APP_MANAGEMENT_APP_PATH_MAX_LEN + 1];
//     char app_hash[APP_MANAGEMENT_APP_HASH_MAX_LEN + 1];
//     int verify;
//     unsigned long long cpu_mask;
//     int memory_threshold;
// }APPM_OPERATION_PARA;

// typedef struct {
//     char errMsg[APP_MANAGEMENT_ERRMSG_MAX_LEN + 1];
//     char errCode[GLOBLE_ERR_CODE_LEN + 1];
// } appm_error_message;

// // app_management_status_call_get_app_info
// // #include "app_management_service_api.h"

// #define APP_MANAGEMENT_SERVICE_NAME_MAX_LEN     64
// #define APP_MANAGEMENT_APP_VERSION_MAX_LEN      32
// #define APP_MANAGEMENT_APP_SERVICE_MAX          10
// typedef struct {
//     int year;
//     char month;
//     char day;
//     char hour;
//     char minute;
//     char second;
// }service_start_time_s;

// typedef struct {
//     char name[APP_MANAGEMENT_SERVICE_NAME_MAX_LEN + 1];
//     char enable;
//     char status;
//     int cpu_usage_threshold;//cpu usage percent * 1000. (1.2%->12)
//     int cpu_usage_current;
//     int memory_usage_threshold;//unit:KB
//     int memory_usage_current;
//     service_start_time_s start_time;
//     char * log;
//     unsigned long long cpu_mask;
// }app_service_info;

// typedef struct {
//     char name[APP_MANAGEMENT_APP_NAME_MAX_LEN + 1];
//     char version[APP_MANAGEMENT_APP_VERSION_MAX_LEN + 1];
//     char hash[APP_MANAGEMENT_APP_HASH_MAX_LEN + 1];
//     int verified;
//     app_service_info services[APP_MANAGEMENT_APP_SERVICE_MAX];
// }app_info_t;


// typedef enum {
//     ALARM_CPU,
//     ALARM_MEMORY,
//     ALARM_STORAGE,
//     ALARM_BUTT,
// }container_alarm_type;


#endif

