/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent debug header file
*/

#ifndef __SGDEV_DEBUG_H__
#define __SGDEV_DEBUG_H__

#include "ssp_syslog.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SGDEV_MODULE   "SGDEV"

#define SGDEV_EMERG(type, module, fmt, arg...)  ssp_syslog(LOG_EMERG, type, module, fmt, ##arg)
#define SGDEV_ALERT(type, module, fmt, arg...)  ssp_syslog(LOG_ALERT, type, module, fmt, ##arg)
#define SGDEV_CRIT(type, module, fmt, arg...)   ssp_syslog(LOG_CRIT, type, module, fmt, ##arg)
#define SGDEV_ERROR(type, module, fmt, arg...)  ssp_syslog(LOG_ERR, type, module, fmt, ##arg)
#define SGDEV_WARN(type, module, fmt, arg...)   ssp_syslog(LOG_WARNING, type, module, fmt, ##arg)
#define SGDEV_NOTICE(type, module, fmt, arg...) ssp_syslog(LOG_NOTICE, type, module, fmt, ##arg)
#define SGDEV_INFO(type, module, fmt, arg...)   ssp_syslog(LOG_INFO, type, module, fmt, ##arg)
#define SGDEV_DEBUG(type, module, fmt, arg...)  ssp_syslog(LOG_DEBUG, type, module, fmt, ##arg)

void sg_log_init(void);
void sg_log_close(void);

#ifdef __cplusplus
}
#endif

#endif
