#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "ssp_mid.h"

#include "vrp_queue.h"
#include "vrp_task.h"
#include "vrp_timer.h"
#include "sgdev_debug.h"
#include "sgdev_struct.h"
#include "sgdev_queue.h"
#include "upmqtt_json.h"
#include "upmqtt_dev.h"
#include "upmqtt_json.h"
#include "thread_dev_insert.h"
#include "thread_manage.h"
#include "task_deal.h"

#include "timer_pack.h"

unsigned int g_timer_task_id = 0;
unsigned int g_timer_queue_id = 0;

uint32_t g_create_time_heart_id = VOS_NULL_LONG;
uint32_t g_create_time_dev_id = VOS_NULL_LONG;
uint32_t g_create_time_container_id = VOS_NULL_LONG;
uint32_t g_create_time_app_id = VOS_NULL_LONG;

int g_heart_flag = 0;
int g_heart_send_count = 0;


//心跳定时器
static int sg_timer_heart_callback(void)
{
    int ret = VOS_OK;
    mqtt_data_info_s *item = NULL;

    int connect_flag;
    connect_flag = sg_get_link_connect_flag();
    if (connect_flag == DEVICE_OFFLINE) {
        return VOS_ERR;
    }

    if (sg_get_dev_ins_flag() == DEVICE_OFFLINE) {
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "device not online.\n");
        return VOS_ERR;
    }

    if (g_heart_flag == 1) {
        g_heart_send_count = 0;
        g_heart_flag = 0;
    }

    if (g_heart_send_count > HEART_MAX_COUNT) {
        sg_set_dev_ins_flag(DEVICE_OFFLINE);
        g_heart_send_count = 0;        // 发送设备断开命令吗
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "heartbeats sent over limit， device offline.\n");
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));

    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_request_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_heart_callback:sprintf_s pub_topic failed.\n");
    }

    ret = sg_pack_dev_heartbeat_request_data(item->msg_send);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Failed to obtain device heartbeat information.\n");
    }

    sg_push_pack_item(item);        //入列
    g_heart_send_count++;
    return VOS_OK;
}

// 设备状态刷新定时器
static int sg_timer_dev_callback(void)
{
    int connect_flag;
    connect_flag = sg_get_link_connect_flag();
    if (connect_flag == DEVICE_OFFLINE) {
        return VOS_ERR;
    }

    if (sg_get_dev_ins_flag() == DEVICE_OFFLINE) {
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_dev_callback:device not online.\n");
        return VOS_ERR;
    }

    sg_handle_dev_inquire_reply(REP_SYS_STATUS, 0);

    return VOS_OK;
}

// 容器状态刷新定时器
static int sg_timer_container_callback(void)
{
    int connect_flag;
    connect_flag = sg_get_link_connect_flag();
    if (connect_flag == DEVICE_OFFLINE) {
        return VOS_ERR;
    }

    if (sg_get_dev_ins_flag() == DEVICE_OFFLINE) {
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_container_callback:device not online.\n");
        return VOS_ERR;
    }
    sg_handle_container_status_get(REP_CON_STATUS, 0);
    return VOS_OK;
}

// APP状态刷新定时器
static int sg_timer_app_callback(void)
{
    int connect_flag;
    connect_flag = sg_get_link_connect_flag();
    if (connect_flag == DEVICE_OFFLINE) {
        return VOS_ERR;
    }

    if (sg_get_dev_ins_flag() == DEVICE_OFFLINE) {
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_app_callback:device not online.\n");
        return VOS_ERR;
    }

    sg_handle_app_status_report(REP_APP_STATUS, 0);
    return VOS_OK;
}

static void sg_timer_queue_entry(void)
{
    unsigned int ret;
    uintptr_t msg[VOS_QUEUE_MSG_NUM];
    for (;;) {
        (void)memset_s((void *)msg, sizeof(msg), 0, sizeof(msg));
        ret = VOS_Que_Read(g_timer_queue_id, msg, VOS_WAIT, 0);
        if (!ret) {
            if (((VOS_TIMERMSG_S *)msg)->tm_pfFunc) {
                (void)(((VOS_TIMERMSG_S *)msg)->tm_pfFunc)(((VOS_TIMERMSG_S *)msg)->tm_pArg);
            }
        } else {
            break;
        }
    }
}

static void sg_timer_task_entry(void)
{
    unsigned int ret;
    unsigned int event;
    for (;;) {
        ret = VOS_Ev_Read(VOS_TIMER_EVENT, &event, VOS_WAIT, 0);
        if (!ret) {
            if (event & VOS_TIMER_EVENT) {
                sg_timer_queue_entry();
            }
        }
    }
}

static int sg_timer_task_create(void)
{
    unsigned int ret;
    ret = VOS_T_Create("sgtm", 0, 0, 0, NULL,
        (TaskStartAddress_PF)sg_timer_task_entry, &g_timer_task_id);
    if (ret) {
        return -1;
    }

    return 0;
}
static int sg_timer_queue_create(void)
{
    unsigned int ret;
    ret = VOS_Que_Create("sgtm", 0, VOS_Q_SYN | VOS_Q_FIFO, &g_timer_queue_id);
    if (ret) {
        return -1;
    }

    return 0;
}


int sg_timer_pre_create()
{
    // 创建任务
    if (sg_timer_task_create() != VOS_OK) {
        return VOS_ERR;
    }

    if (sg_timer_queue_create() != VOS_OK) {
        return VOS_ERR;
    }

    return VOS_OK;
}

int sg_timer_heart_create(uint32_t timeout)
{
    uint32_t ret;
    uint32_t time_out = (uint32_t)(timeout * SG_SECOND); //  ms

    if (g_create_time_heart_id != VOS_NULL_LONG) {
        if (VOS_Timer_Delete(g_create_time_heart_id) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "VOS_Timer_Delete g_create_time_heart_id fail!\n");
        } else {
            g_create_time_heart_id = VOS_NULL_LONG;
        }
    }

    ret = VOS_Timer_Create(g_timer_task_id, g_timer_queue_id, time_out, (void(*) (void *))sg_timer_heart_callback, NULL,
        &g_create_time_heart_id, VOS_TIMER_LOOP);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_heart_create fail!\n");
        return -1;
    }

    return VOS_OK;
}

int sg_timer_dev_create(uint32_t timeout)
{
    uint32_t ret;
    uint32_t time_out = (uint32_t)(timeout * SG_SECOND); // ms

    if (g_create_time_dev_id != VOS_NULL_LONG) {
        if (VOS_Timer_Delete(g_create_time_dev_id) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "VOS_Timer_Delete g_create_time_dev_id fail!\n");
        } else {
            g_create_time_dev_id = VOS_NULL_LONG;
        }
    }

    ret = VOS_Timer_Create(g_timer_task_id, g_timer_queue_id, time_out, (void(*) (void *))sg_timer_dev_callback, NULL,
        &g_create_time_dev_id, VOS_TIMER_LOOP);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_dev_create fail!\n");
        return -1;
    }
    return VOS_OK;
}
int sg_timer_container_create(uint32_t timeout)
{
    uint32_t ret; 
    uint32_t time_out = (uint32_t)(timeout * SG_SECOND); // ms

    if (g_create_time_container_id != VOS_NULL_LONG) {
        if (VOS_Timer_Delete(g_create_time_container_id) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "VOS_Timer_Delete g_create_time_container_id fail!\n");
        } else {
            g_create_time_container_id = VOS_NULL_LONG;
        }
    }

    ret = VOS_Timer_Create(g_timer_task_id, g_timer_queue_id, time_out, (void(*) (void *))sg_timer_container_callback,
        NULL, &g_create_time_container_id, VOS_TIMER_LOOP);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_container_create fail!\n");
        return -1;
    }
    return VOS_OK;
}
int sg_timer_app_create(uint32_t timeout)
{
    uint32_t ret;
    uint32_t time_out = (uint32_t)(timeout * SG_SECOND); //  ms

    if (g_create_time_app_id != VOS_NULL_LONG) {
        if (VOS_Timer_Delete(g_create_time_app_id) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "VOS_Timer_Delete g_create_time_app_id fail!\n");
        } else {
            g_create_time_app_id = VOS_NULL_LONG;
        }
    }

    ret = VOS_Timer_Create(g_timer_task_id, g_timer_queue_id, time_out, (void(*) (void *))sg_timer_app_callback, NULL,
        &g_create_time_app_id, VOS_TIMER_LOOP);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_timer_app_create fail!\n");
        return -1;
    }
    return VOS_OK;
}

void sg_timer_heart_delete(void)
{
    uint32_t ret;
    ret = VOS_Timer_Delete(g_create_time_heart_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "timer heart delete failed.\n");
    }
}

void sg_timer_dev_delete(void)
{
    uint32_t ret;
    ret = VOS_Timer_Delete(g_create_time_dev_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "timer device delete failed.\n");
    }
}

void sg_timer_container_deletee(void)
{
    uint32_t ret;
    ret = VOS_Timer_Delete(g_create_time_container_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "timer container delete failed.\n");
    }
}

void sg_timer_app_delete(void)
{
    uint32_t ret;
    ret = VOS_Timer_Delete(g_create_time_app_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "timer app delete failed.\n");
    }
}

int sg_get_dev_heart_flag(void)
{
    return g_heart_flag;
}

void sg_set_dev_heart_flag(int flag)
{
    g_heart_flag = flag;
}
