#include <string.h>
#include <stdio.h>

#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "ssp_mid.h"
#include "vm_public.h"
#include "vm_rpc_api.h"
#include "sysman_rpc_api.h"
#include "app_management_service_api.h"

#include <glib-object.h>
#include <thrift/c_glib/thrift.h>

#include "sgdev_struct.h"
#include "sgdev_debug.h"
#include "sgdev_common.h"
#include "sgdev_queue.h"
#include "sgdev_param.h"
#include "sgdev_curl.h"
#include "upmqtt_json.h"
#include "upmqtt_json.h"
#include "upmqtt_container.h"
#include "upmqtt_dev.h"

#include "task_link.h"
#include "timer_pack.h"
#include "thread_interact.h"
#include "task_container.h"

void sg_container_sig_info_set(container_status_array_s *contPara, CONTAINER_INFO_S *container_list, int num);
void sg_vos_free_container_info(INSTALL_OVA_PARA_NORTH_SG_S *install_info)
{
    if (install_info == NULL) {
        return;
    }
    if (install_info->dev_map.dev_list != NULL) {
        (void)VOS_Free(install_info->dev_map.dev_list);
        install_info->dev_map.dev_list = NULL;
    }

    if (install_info->mount_dir_add.mount_dir != NULL) {
        (void)VOS_Free(install_info->mount_dir_add.mount_dir);
        install_info->mount_dir_add.mount_dir = NULL;
    }

    if (install_info->container_name != NULL) {
        (void)VOS_Free(install_info->container_name);
        install_info->container_name = NULL;
    }

    if (install_info->ova_name != NULL) {
        (void)VOS_Free(install_info->ova_name);
        install_info->ova_name = NULL;
    }
}
// ������װ����Ӧ�������֡
void sg_container_install_reply_frame(uint16_t code, int32_t mid, char* errormsg)
{
    mqtt_data_info_s *item = NULL;
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_reply_frame memory .\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_reply_frame sprintf_s pub_topic failed .\n");
    }

    if (sg_pack_container_install_cmd(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_install_cmd failed .\n");
    }

    sg_push_pack_item(item);
}

// ������������Ӧ�������֡
void sg_container_modify_reply_frame(uint16_t code, int32_t mid, char* errormsg)
{
    mqtt_data_info_s *item = NULL;
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_modify_reply_frame memory failed.\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_reply_frame sprintf_s pub_topic failed .\n");
    }

    if (sg_pack_container_param_set_reply(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_install_cmd failed .\n");
    }

    sg_push_pack_item(item);
}

// ��������������ֵ
static int sg_container_install_para(INSTALL_OVA_PARA_NORTH_SG_S *install_info,
                                        container_install_cmd_s *cmd_obj, char* errmsg)
{
    uint32_t cpus = 0;
    unsigned long long i = 0;
    size_t container_len = 0;
    char left_obj[DATA_BUF_F64_SIZE] = { 0 };
    char right_obj[DATA_BUF_F64_SIZE] = { 0 };
    if (cmd_obj == NULL) {
        return VOS_ERR;
    }

    container_len = strlen(cmd_obj->container) + 1;
    install_info->container_name = (char*)VOS_Malloc(MID_SGDEV, sizeof(char) * container_len);
    if (install_info->container_name == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_para allocate memory failed .\n");
        return VOS_ERR;
    }

    (void)memset_s(install_info->container_name, container_len, 0, container_len);
    if (memcpy_s(install_info->container_name, container_len, cmd_obj->container, strlen(cmd_obj->container)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_array: container_name failed!\n");
    }

    cpus = (uint32_t)(cmd_obj->cfgCpu.cpus);
    install_info->cpu_mask = 0;
    for (i = 0; i < cpus; i++) {
        install_info->cpu_mask |= i;                                 // cpu������ֵ
    }

    install_info->cpu_threshold = (unsigned int)cmd_obj->cfgCpu.cpuLmt;            // cpu�����ֵ��ֵ
    install_info->mem_size = cmd_obj->cfgMem.memory;                 // �ڴ���ֵ��ֵ
    install_info->mem_threshold = (unsigned int)cmd_obj->cfgMem.memLmt;            // �ڴ�����ֵ��ֵ
    install_info->disk_size = cmd_obj->cfgDisk.disk;                 // �洢��ֵ��ֵ
    install_info->disk_threshold = (unsigned int)cmd_obj->cfgDisk.diskLmt;         // ���̴洢�����ֵ��ֵ

    if (strlen(cmd_obj->port) != 0) {
        install_info->port_map.add_type = PORT_ADD_OVERWRITE;
        install_info->port_map.num = 1;
        if (sg_str_colon(cmd_obj->port, (int)strlen(cmd_obj->port), left_obj, right_obj) != VOS_OK) {
            if (sprintf_s(errmsg, DATA_BUF_F128_SIZE, "port is not correct") < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_para:sprintf_s errmsg failed .\n");
                return VOS_ERR;
            }
        }
        install_info->port_map.port_node[0].host_port = (unsigned int)atoi(left_obj);
        install_info->port_map.port_node[0].container_port = (unsigned int)atoi(right_obj);
    }

    return VOS_OK;
}

// �����޸Ļ���������ֵ
static int sg_container_conf_para(INSTALL_OVA_PARA_NORTH_SG_S *conf_info,
    container_conf_cmd_s *conf_obj, char* errmsg)
{
    uint32_t cpus = 0;
    unsigned long long i = 0;
    size_t container_len = 0;
    char left_obj[DATA_BUF_F64_SIZE] = { 0 };
    char right_obj[DATA_BUF_F64_SIZE] = { 0 };
    if (conf_obj == NULL) {
        return VOS_ERR;
    }

    container_len = strlen(conf_obj->container) + 1;
    conf_info->container_name = (char*)VOS_Malloc(MID_SGDEV, sizeof(char) * container_len);
    if (conf_info->container_name == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_para allocate memory failed .\n");
        return VOS_ERR;
    }

    (void)memset_s(conf_info->container_name, container_len, 0, container_len);
    if (memcpy_s(conf_info->container_name, container_len, conf_obj->container, strlen(conf_obj->container)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_array: container_name failed!\n");
    }

    cpus = (uint32_t)conf_obj->cfgCpu.cpus;
    conf_info->cpu_mask = 0;
    for (i = 0; i < cpus; i++) {
        conf_info->cpu_mask |= i;                                 // cpu������ֵ
    }

    conf_info->cpu_threshold = (unsigned int)conf_obj->cfgCpu.cpuLmt;            // cpu�����ֵ��ֵ
    conf_info->mem_size = conf_obj->cfgMem.memory;                 // �ڴ���ֵ��ֵ
    conf_info->mem_threshold = (unsigned int)conf_obj->cfgMem.memLmt;            // �ڴ�����ֵ��ֵ
    conf_info->disk_size = conf_obj->cfgDisk.disk;                 // �洢��ֵ��ֵ
    conf_info->disk_threshold = (unsigned int)conf_obj->cfgDisk.diskLmt;         // ���̴洢�����ֵ��ֵ

    if (strlen(conf_obj->port) != 0) {
        conf_info->port_map.add_type = PORT_ADD_OVERWRITE;
        conf_info->port_map.num = 1;
        if (sg_str_colon(conf_obj->port, (int)strlen(conf_obj->port), left_obj, right_obj) != VOS_OK) {
            if (sprintf_s(errmsg, DATA_BUF_F128_SIZE, "port is not correct") < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_para:sprintf_s errmsg failed .\n");
                return VOS_ERR;
            }
        }
        conf_info->port_map.port_node[0].host_port = (unsigned int)atoi(left_obj);
        conf_info->port_map.port_node[0].container_port = (unsigned int)atoi(right_obj);
    }

    return VOS_OK;
}

int sg_container_install(container_install_cmd_s *cmd_obj, char *errmsg)
{
    int ret = VOS_OK;
    size_t ova_len = 0;
    INSTALL_OVA_PARA_NORTH_SG_S install_info = { 0 };

    ova_len = strlen(cmd_obj->image.name) + 1;
    if (ova_len <= 1) {
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", "image.name is not correct") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s image.name is not correct failed.\n");
        }
        return VOS_ERR;
    } 
    install_info.ova_name = (char *)VOS_Malloc(MID_SGDEV, sizeof(char) * ova_len);
    if (install_info.ova_name == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install allocate memory failed .\n");
        return VOS_ERR;
    }

    (void)memset_s(install_info.ova_name, (size_t)ova_len, 0, (size_t)ova_len);
    if (memcpy_s(install_info.ova_name, ova_len, cmd_obj->container, strlen(cmd_obj->image.name)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install: ova_name failed!\n");
    }

    if (sg_container_install_para(&install_info, cmd_obj, errmsg) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_para set failed .\n");
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", "param is not correct") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s param is not correct failed.\n");
        }
        ret = VOS_ERR;
    }

    if (sg_set_container_modify_mount(cmd_obj->mount, cmd_obj->mount_len, &install_info.mount_dir_add) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_mount failed .\n");
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", "mount param is not correct") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s param is not correct failed.\n");
        }
        ret = VOS_ERR;
    }

    if (sg_set_container_modify_dev(cmd_obj->dev, cmd_obj->dev_len, &install_info.dev_map) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_dev failed .\n");
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", "dev param is not correct") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s param is not correct failed.\n");
        }
        ret = VOS_ERR;
    }

    if (strlen(cmd_obj->image.sign.name) != 0) {
        install_info.verify = true;
    }

    if (!vm_rpc_container_install_north_sg(&install_info, errmsg, VM_RET_STRING_SIZE)) {
        ret = VOS_ERR;
    }

    sg_vos_free_container_info(&install_info);
    return ret;
}

int sg_container_update(container_install_cmd_s *cmd_obj, char *errmsg)
{
    return 0;
}

// ���������޸Ĵ�������
int sg_container_modify_north(container_conf_cmd_s *cmd_obj, char *errmsg)
{
    int ret = VOS_OK;

    char errRet[VM_RET_STRING_SIZE] = { 0 };
    INSTALL_OVA_PARA_NORTH_SG_S install_info = { 0 };

    if (sg_container_conf_para(&install_info, cmd_obj, errmsg) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_conf_para set failed .\n");
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", " param is not correct") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s  is not correct failed.\n");
        }
        ret = VOS_ERR;
    }

    if (sg_set_container_modify_mount(cmd_obj->mount, cmd_obj->mount_len, &install_info.mount_dir_add) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_mount failed .\n"); // ��ȡmount
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", "mount param is not correct") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s mount is not correct failed.\n");
        }
        ret = VOS_ERR;
    }

    if (sg_set_container_modify_dev(cmd_obj->dev, cmd_obj->dev_len, &install_info.dev_map) != VOS_OK) {       // ��ȡdev
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_dev failed .\n");
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", "dev param is not correct") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s dev is not correct failed.\n");
        }
        ret = VOS_ERR;
    }

    if (!vm_rpc_container_modify_north_sg(&install_info, errRet, VM_RET_STRING_SIZE)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_container_modify_north_sg error!\n");
        ret = VOS_ERR;
    }

    if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", errRet) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s vm_rpc_container_modify_north_sg failed.\n");
    }
    sg_vos_free_container_info(&install_info);
    return ret;
}

/* *
 * sg_set_container_modify_mount
 * ����:��ȡmount����
 * ����:container_conf_cmd_s *cmd_obj
 * ����:container_mount_dir_add_s *mount_info
 * ����ֵ:int
 */

int sg_set_container_modify_mount(char mount[][DATA_BUF_F256_SIZE], size_t mount_len,
    container_mount_dir_add_s *mount_info)
{
    int ret = VOS_OK;
    size_t i = 0;
    char left_obj[DATA_BUF_F64_SIZE] = { 0 };
    char right_obj[DATA_BUF_F64_SIZE] = { 0 };
    if (mount_len == 0) {
        return VOS_ERR;
    }

    mount_info->num = (int)mount_len;
    mount_info->add_type = MOUNT_DIR_ADD_OVERWRITE;
    mount_info->mount_dir = (mount_dir_cfg_s*)VOS_Malloc(MID_SGDEV, sizeof(mount_dir_cfg_s) * mount_len);
    if (mount_info->mount_dir == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_mount VOS_Malloc failed .\n");
        return VOS_ERR;
    }

    (void)memset_s(mount_info->mount_dir, sizeof(mount_dir_cfg_s) * mount_len, 0,
        sizeof(mount_dir_cfg_s) * mount_len);
    for (i = 0; i < mount_len; i++) {
        if (sg_str_colon(mount[i], (int)strlen(mount[i]), left_obj, right_obj) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_mount:sg_str_colon failed .\n");
            ret = VOS_ERR;
        }
        if (sprintf_s(mount_info->mount_dir[i].host_dir, VM_PATH_MAX_128, "%s", left_obj) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s mount_dir_add.mount_dir:host_dir failed.\n");
            ret = VOS_ERR;
        }
        if (sprintf_s(mount_info->mount_dir[i].container_dir, VM_PATH_MAX_128, "%s", right_obj)) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s mount_dir_add.mount_dir:container_dir failed.\n");
            ret = VOS_ERR;
        }
    }

    return ret;
}
/* *
 * sg_et_container_modify_dev
 * ����:��ȡdev����
 * ����:container_conf_cmd_s *cmd_obj
 * ����:install_map_dev *dev_info
 * ����ֵ:int
 */
int sg_set_container_modify_dev(char dev[][DATA_BUF_F256_SIZE], size_t dev_len,
    install_map_dev *dev_info)
{
    int ret = VOS_OK;
    size_t i = 0;
    char left_obj[DATA_BUF_F64_SIZE] = { 0 };
    char right_obj[DATA_BUF_F64_SIZE] = { 0 };
    if (dev_len == 0) {
        return VOS_ERR;
    }

    dev_info->dev_num = (int)dev_len;
    dev_info->dev_list = (install_dev_node*)VOS_Malloc(MID_SGDEV,
        sizeof(install_dev_node) * dev_len);
    if (dev_info->dev_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_dev VOS_Malloc failed .\n");
        return VOS_ERR;
    }

    (void)memset_s(dev_info->dev_list, sizeof(install_dev_node) * dev_len, 0,
        sizeof(install_dev_node) * dev_len);
    for (i = 0; i < dev_len; i++) {
        if (sg_str_colon(dev[i], (int)strlen(dev[i]), left_obj, right_obj) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_dev sg_str_colon failed .\n");
            ret = VOS_ERR;
        }
        if (sprintf_s(dev_info->dev_list[i].host_dev, CONTAINER_DEV_NAME_MAX_LEN, "%s", left_obj) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_dev host_dev failed .\n");
            ret = VOS_ERR;
        }
        if (sprintf_s(dev_info->dev_list[i].map_dev, CONTAINER_DEV_NAME_MAX_LEN, "%s", right_obj) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_container_modify_dev map_dev failed .\n");
            ret = VOS_ERR;
        }
    }

    return ret;
}

// ���޷��ų�����תΪcpu����  ��Ҫȷ��
void sg_container_cpumask_to_cpucore(char *cpucore, unsigned len, long long cpu_mask)
{
    int cpu_core_len = 0;
    int i;

    for (i = 0; i < 64; i++) {
        if ((unsigned long long)cpu_mask & 1) {
            cpu_core_len += sprintf_s(&cpucore[cpu_core_len], len - (unsigned int)cpu_core_len, "%d", i);
        }
        cpu_mask = (unsigned long long)cpu_mask >> 1;
    }
    if (cpu_core_len > 0) {
        cpucore[cpu_core_len - 1] = 0;
    }
}
// ��ȡport
int sg_get_port_map_info(container_conf_cmd_s *container_conf_cmd)
{
    int ret = VOS_OK;
    int port_num = 0;
    char errRet[VM_RET_STRING_SIZE]         = { 0 };
    port_map_node *port_info                = NULL;

    if (!vm_rpc_get_port_map_info(container_conf_cmd->container, &port_num, &port_info, errRet, VM_RET_STRING_SIZE)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_get_port_map_info error !\n");
        ret = VOS_ERR;
    }
    if (port_num <= 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_get_port_map_info error !\n");
    } else {
        if (port_info == NULL) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "port_info NULL!\n");
        } else {
            if (sprintf_s(container_conf_cmd->port, DATA_BUF_F64_SIZE, "%d:%d", 
                port_info[0].host_port, port_info[0].container_port) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "container_conf_cmd->port get failed!\n");
            }
        }
    }
    if (port_info) {
        (void)VOS_Free(port_info);
        port_info = NULL;
    }
    return ret;
}

// ��ȡĿ¼ӳ����Ϣ
int sg_get_mount_dir(container_conf_cmd_s *container_conf_cmd)
{
    int ret = VOS_OK;
    int i = 0;
    int mount_num = 0;
    char errRet[VM_RET_STRING_SIZE]       = { 0 };
    container_mount_dir_get_s *mount_info = NULL;

    if (!vm_rpc_get_mount_dir(container_conf_cmd->container, &mount_num, &mount_info, errRet, VM_RET_STRING_SIZE)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_get_mount_dir error !\n");
        ret = VOS_ERR;
    }
    container_conf_cmd->mount_len = (size_t)mount_num;
    if (mount_num <= 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_get_mount_dir error !\n");
        return VOS_ERR;
    }
    if (mount_info == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mount_info NULL!\n");
        return VOS_ERR;
    }
    for (i = 0; i < mount_num; i++) {
        if (sprintf_s(container_conf_cmd->mount[i], DATA_BUF_F64_SIZE, "%s:%s",
            mount_info[i].host_dir, mount_info[i].container_dir) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "container_conf_cmd->mount get failed!\n");
        }
    }

    if (mount_info) {
        (void)VOS_Free(mount_info);
        mount_info = NULL;
    }
    return ret;
}

//��ȡ�豸�ڵ���Ϣ
int sg_get_container_device_list(container_conf_cmd_s *container_conf_cmd)
{
    int ret = VOS_OK;
    int i = 0;
    int dev_num = 0;
    char errRet[VM_RET_STRING_SIZE]   = { 0 };
    container_dev_node *dev_info      = NULL;

    if (!vm_status_call_get_container_device_list(container_conf_cmd->container, &dev_info,
        &dev_num, errRet, VM_RET_STRING_SIZE)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_status_call_get_container_device_list error !\n");
        ret = VOS_ERR;
    }
    container_conf_cmd->dev_len = (size_t)dev_num;
    if (dev_num <= 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_status_call_get_container_device_list error !\n");
        return VOS_ERR;
    }
    if (dev_info == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "dev_info NULL!\n");
        return VOS_ERR;
    }
    for (i = 0; i < dev_num; i++) {
        if (sprintf_s(container_conf_cmd->dev[i], DATA_BUF_F64_SIZE, "%s:%s",
            dev_info[i].host_dev, dev_info[i].map_dev) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "container_conf_cmd->dev get failed!\n");
        }
    }

    if (dev_info) {
        (void)VOS_Free(dev_info);
        dev_info = NULL;
    }
    return ret;
}

int sg_container_config_to_reply(container_config_reply_s *contiainer_config_reply, int container_num, 
        CONTAINER_INFO_S *container_list)
{
    int num           = 0;
    int ret           = VOS_OK;
    char cpucore[DATA_BUF_F128_SIZE] = { 0 };

    contiainer_config_reply->contPara_len = container_num;
    contiainer_config_reply->contPara = (container_conf_cmd_s *)VOS_Malloc(MID_SGDEV,
        sizeof(container_conf_cmd_s) * (size_t)container_num);
    if (contiainer_config_reply->contPara == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "malloc use failure!\n");
        ret = VOS_ERR;
    }
    (void)memset_s(contiainer_config_reply->contPara, sizeof(container_conf_cmd_s) * (size_t)container_num, 0,
        sizeof(container_conf_cmd_s) * (size_t)container_num);
    for (num = 0; num < container_num; num++) {
        if (memcpy_s(contiainer_config_reply->contPara[num].container, DATA_BUF_F64_SIZE,
            container_list[num].container_name, strlen(container_list[num].container_name)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_config_to_reply: container_name failed!\n");
        }

        sg_container_cpumask_to_cpucore(cpucore, DATA_BUF_F128_SIZE, (long long)container_list[num].cpu_mask);
        contiainer_config_reply->contPara[num].cfgCpu.cpus = sg_hamming_weight(container_list[num].cpu_mask);
        contiainer_config_reply->contPara[num].cfgCpu.cpuLmt = (int)container_list[num].cpu_threshold;
        contiainer_config_reply->contPara[num].cfgMem.memory = (int)container_list[num].container_mem_size;
        contiainer_config_reply->contPara[num].cfgMem.memLmt = (int)container_list[num].memory_threshold;
        contiainer_config_reply->contPara[num].cfgDisk.disk = (int)container_list[num].container_storage_size;
        contiainer_config_reply->contPara[num].cfgDisk.diskLmt = (int)container_list[num].storage_threshold;

        if (sg_get_port_map_info(&contiainer_config_reply->contPara[num]) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_port_map_info error!\n");
            ret = VOS_ERR;
        }

        if (sg_get_mount_dir(&contiainer_config_reply->contPara[num]) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_mount_dir error!\n");
            ret = VOS_ERR;
        }

        if (sg_get_container_device_list(&contiainer_config_reply->contPara[num]) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_container_device_list error!\n");
            ret = VOS_ERR;
        }
    }
    return ret;
}
void sg_container_sig_info_set(container_status_array_s *contPara, CONTAINER_INFO_S *container_list, int num)
{
    if (memcpy_s(contPara->container, DATA_BUF_F64_SIZE,
        container_list[num].container_name, strlen(container_list[num].container_name)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_status_to_reply: container failed!\n");
    }                                                                                               // �������Ƹ�ֵ
    if (memcpy_s(contPara->version, DATA_BUF_F64_SIZE,
        container_list[num].container_version, strlen(container_list[num].container_version)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_status_to_reply: version failed!\n");
    }                                                                                               // �����汾��
    if (memcpy_s(contPara->state, DATA_BUF_F64_SIZE,
        container_list[num].container_status, strlen(container_list[num].container_status)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_status_to_reply: state failed!\n");
    }                                                                                               // ��������״̬
    if (memcpy_s(contPara->ip, DATA_BUF_F64_SIZE,
        container_list[num].container_ipaddr, strlen(container_list[num].container_ipaddr)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_status_to_reply: ip failed!\n");
    }                                                                                               // IP��ַ���˿�
    contPara->cpuRate = container_list[num].cpuusage;                  // CPUռ����
    contPara->memUsed = container_list[num].memoryusage;               // �ڴ�ռ����
    contPara->diskUsed = container_list[num].stroageusage;             // ����ռ����
}
// contiainer_status_reply->contPara[num].created =          // ����ʱ��      ��ʱû��
// contiainer_status_reply->contPara[num].image =            // ����������Ϣ  ��ʱû��
// ��ȡ����ʱ�� ���ж�һ��status �ǲ��ǳ���running״̬  Ȼ���� ��ǰʱ���ȥ���һ������ʱ���������ʱ��
int sg_container_status_to_reply(container_status_reply_s *contiainer_status_reply, int container_num, 
        CONTAINER_INFO_S *container_list)
{
    char *ptr         = NULL;
    int num           = 0;
    int ret           = VOS_OK;
    time_t uptime_num = 0;
    time_t up_time    = 0;
    struct tm tmp_ptr = { 0 };

    contiainer_status_reply->contPara_len = container_num;
    contiainer_status_reply->contPara = (container_status_array_s *)VOS_Malloc(MID_SGDEV,
        sizeof(container_status_array_s) * (size_t)container_num);
    if (contiainer_status_reply->contPara == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_status_to_reply:malloc failed\n");
        ret = VOS_ERR;
    }

    (void)memset_s(contiainer_status_reply->contPara, sizeof(container_status_array_s)  * (size_t)container_num, 0,
        sizeof(container_status_array_s) * (size_t)container_num);

    for (num = 0; num < container_num; num++) {
        sg_container_sig_info_set(&contiainer_status_reply->contPara[num], container_list, num);//������Ϣ
        uptime_num = (time_t)strtoul(container_list[num].container_up_time, &ptr, 10);
        if (uptime_num == 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_status_to_reply:uptime_num get error\n");
            ret = VOS_ERR;
        }

        (void)localtime_r(&uptime_num, &tmp_ptr);
        if (sprintf_s(contiainer_status_reply->contPara[num].started, DATA_BUF_F64_SIZE, "%d-%d-%d %d:%d:%d",
            1900 + tmp_ptr.tm_year, 1 + tmp_ptr.tm_mon, tmp_ptr.tm_mday,
            tmp_ptr.tm_hour, tmp_ptr.tm_min, tmp_ptr.tm_sec) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "contPara[%d].started get failed .\n", num);
        }

        if (strncmp(contiainer_status_reply->contPara[num].state, "running", strlen("running")) != 0) {
            contiainer_status_reply->contPara[num].lifeTime = 0;
        } else {
            up_time = time(NULL) - uptime_num;
            contiainer_status_reply->contPara[num].lifeTime = up_time;                              // ����ʱ�䣬��λ:��
        }
    }
    return ret;
}

// ����ѡ������ �������� ֹͣ ɾ��
bool sg_container_select_control(char *type, char *container_name, char *errormsg)
{
    bool res = true;
    char errorcode[DATA_BUF_F256_SIZE]  = { 0 };
    if (strncmp(type, CMD_CON_START, strlen(CMD_CON_START)) == 0) {
        res = vm_rpc_container_start(container_name, errorcode, DATA_BUF_F256_SIZE, errormsg, DATA_BUF_F256_SIZE);
    } else if (strncmp(type, CMD_CON_STOP, strlen(CMD_CON_STOP)) == 0) {
        res = vm_rpc_container_stop(container_name, errorcode, DATA_BUF_F256_SIZE, errormsg, DATA_BUF_F256_SIZE);
    } else if (strncmp(type, CMD_CON_REMOVE, strlen(CMD_CON_REMOVE)) == 0) {
        res = vm_rpc_container_uninstall(container_name, errorcode, DATA_BUF_F256_SIZE, errormsg, DATA_BUF_F256_SIZE);
    }
    return res;
}
