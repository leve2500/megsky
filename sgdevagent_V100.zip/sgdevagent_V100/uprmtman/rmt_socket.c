#include <signal.h>
#include <stdio.h>
#include <strings.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "sgdev_struct.h"
#include "sgdev_debug.h"
#include "rmt_socket.h"

typedef socklen_t SOCKLEN;
typedef struct sockaddr SA;

struct sockaddr_in  g_sockaddr;
int                 g_socket;

unsigned char   g_net_type; // 0:TCP; 1:UDP
fd_set  g_readSet;      // ����¼��
fd_set  g_writeSet;     // д��¼��

fd_set  g_exceptSet;        //�쳣
struct timeval	g_tTimeout; //�����߳����������������ʱ��

int g_isAlreadyListen;

// socket����
int g_sockettype;           // 0:clientsocket 1:serversocket

// ����״̬
int	g_connect_state;
// �Է�����Ϣ
s_socket_param g_clientparam;

// ��д�豸��ʼ��
static void sg_init_rw_set(long nSec, long uSec)
{
    FD_ZERO(&g_readSet);
    FD_SET(g_socket, &g_readSet);
    FD_ZERO(&g_writeSet);
    FD_SET(g_socket, &g_writeSet);
    FD_ZERO(&g_exceptSet);
    FD_SET(g_socket, &g_exceptSet);

    g_tTimeout.tv_sec = nSec;   // ���߳��еĶ�ʱ�ȴ�
    g_tTimeout.tv_usec = uSec;
}


// ��Socket��ַ�ṹת����׼�ṹ
static void sg_convert_sock_addr(s_socket_param addr1, int ListenFlag)
{
    g_sockaddr.sin_family = AF_INET;         // AF_UNIX
    g_sockaddr.sin_port = htons(addr1.port_number);
    g_sockaddr.sin_addr.s_addr = inet_addr(addr1.ip_address);
}

// �Ƿ��Ѿ�����
int sg_get_connect_state(void)
{
    return g_connect_state;
}

// �Ͽ�����
void sg_cloese_socket()
{
    if (g_socket == 0)
        return;

    (void)close(g_socket);
    g_isAlreadyListen = 0;
    g_socket = 0;
    g_connect_state = SOCKET_NOTCONNECTTED;
}

static int sg_init_socket(void)
{
    if (g_socket == 0) {
        return g_socket;
    }

    if (g_net_type == UDP_TYPE) {
        g_socket = socket(AF_INET, SOCK_DGRAM, 0);
    } else {
        g_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (g_socket == 0) {
            g_socket = socket(AF_INET, SOCK_STREAM, 0);
        }
    }

    if (g_socket <= 0) {
        g_socket = 0;
        return g_socket;
    }

    if (fcntl(g_socket, F_SETFL, O_NONBLOCK) < 0) {        // ���÷�������ʽ
        sg_cloese_socket();
    }

    if (g_sockettype) {        // ����IP
        const int bBroadcast = 1;
        if (setsockopt(g_socket, SOL_SOCKET, SO_REUSEADDR, (char*)&bBroadcast, sizeof(bBroadcast)) != 0) {
            sg_cloese_socket();
        }
    }
    errno = 0;
    return g_socket;
}


void sg_sockket_init(void)
{
    g_socket = 0;
    g_net_type = (unsigned char)LINK_UNKNOWN;
    g_connect_state = SOCKET_NOTCONNECTTED;
}

void sg_sockket_exit()
{
    if (g_socket > 0) {
        sg_cloese_socket();
    }
}

void sg_set_socket_param(s_socket_param sockaddr, int ServerSocketFlag)
{
    g_net_type = sockaddr.type;		// ����Э������
    g_socket = 0;
    g_connect_state = SOCKET_NOTCONNECTTED;
    sg_convert_sock_addr(sockaddr, ServerSocketFlag);
    g_sockettype = ServerSocketFlag;
    g_isAlreadyListen = 0;
}

int sg_connect_socket(void)
{
    int error = 1;
    int bFlag = 1;
    int len = sizeof(int);
    int nResult = 0;
    if (g_sockettype) {
        return SOCKET_NOTCONNECTTED;
    }

    if (g_connect_state == SOCKET_CONNECTTING) {      // ��������
        sg_init_rw_set(0, 1);// ��ʼ����ʱʱ���fd_set
        nResult = select(g_socket + 1, NULL, &g_writeSet, NULL, &g_tTimeout);
        if (nResult <= 0) {   // ����û�н���
            sg_cloese_socket();
            return g_connect_state;
        }

        if (FD_ISSET(g_socket, &g_writeSet)) {
            g_connect_state = SOCKET_CONNECTNORMAL;
            (void)getsockopt(g_socket, SOL_SOCKET, SO_ERROR, (char*)&error, (socklen_t*)&len);
            if (!error && bFlag) {
                g_connect_state = SOCKET_CONNECTNORMAL;
            } else {
                sg_cloese_socket();
            }
        } else {
            sg_cloese_socket();
        }
    } else if (g_connect_state == SOCKET_NOTCONNECTTED) {
        if (sg_init_socket() == 0) {              // socket��ʼ��
            return g_connect_state;
        }
        int ret = connect(g_socket, (SA*)&g_sockaddr, sizeof(g_sockaddr));
        if (ret < 0) {
            if (errno == EINPROGRESS || errno == 0) {        // ��������ʽ�����Ӳ����������
                g_connect_state = SOCKET_CONNECTTING;
            } else {
                sg_cloese_socket();// ����ʧ��
            }
        } else {
            g_connect_state = SOCKET_CONNECTNORMAL;// ���ӳɹ�
        }
    }
    return g_connect_state;
}

// ��������
int sg_read_data(char* data, int count)
{
    int readCount = 0;
    sg_init_rw_set(0, 1);
    int nResult = select(g_socket + 1, &g_readSet, NULL, &g_exceptSet, &g_tTimeout);
    if (nResult < 0) {
        readCount = -1;
        sg_cloese_socket();
        return readCount;
    }
    if (nResult == 0) {
        if (FD_ISSET(g_socket, &g_exceptSet)) {
            readCount = -1;
            sg_cloese_socket();
            return readCount;
        }
    }

    if (FD_ISSET(g_socket, &g_exceptSet)) {
        sg_cloese_socket();
        return -1;
    }
    if (FD_ISSET(g_socket, &g_readSet)) {
        readCount = recv(g_socket, (char*)data, (unsigned long)count, 0);
        if (readCount <= 0) {
            if (errno == ENOBUFS || errno == EAGAIN || errno == EWOULDBLOCK) {
                readCount = 0;
            } else {
                readCount = -1;
            }
        }
    } else {
        readCount = -1;
    }

    if (readCount == -1) {
        sg_cloese_socket();
    }

    return readCount;
}

// ��������
int sg_write_data(char *data, int count)
{
    int writeCount = -1;
    sg_init_rw_set(0, 1);
    int nResult = select(g_socket + 1, NULL, &g_writeSet, &g_exceptSet, &g_tTimeout);
    if (nResult < 0) {
        char tError[32];
        if (sprintf_s(tError, DATA_BUF_F32_SIZE, "socket error id :%d!!!!", errno) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s socket error!\n");
        }
        sg_cloese_socket();
        writeCount = -1;
        return writeCount;
    }

    if (nResult == 0) {
        if (FD_ISSET(g_socket, &g_exceptSet)) {
            writeCount = -1;
            sg_cloese_socket();
            return writeCount;
        }
    }

    if (FD_ISSET(g_socket, &g_exceptSet)) {
        sg_cloese_socket();
        return -1;
    }
    if (FD_ISSET(g_socket, &g_writeSet)) {
        writeCount = send(g_socket, data, (unsigned long)count, 0);
        if (writeCount < 0) {
            if (errno == EWOULDBLOCK) {
                writeCount = 0;
            } else {
                writeCount = -1;
            }
        }
    } else {
        writeCount = -1;
    }

    if (writeCount == -1) {
        sg_cloese_socket();
    }

    return writeCount;
}

