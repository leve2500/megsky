/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent curl header file
*/

#ifndef __SGDEV_CURL_H__
#define __SGDEV_CURL_H__

#ifdef __cplusplus
extern "C" {
#endif

#define DEFAULT_FILE_PATH "/mnt/internal_storage"
#define KB_CONVERSION_SIZE (1024)
#define FIZE_SIZE_THRESHOLD (10)

typedef struct http_file {
    char filename[512];
    FILE *stream;
}http_file_s;

int sg_curl_download_file(char *filename, char *filepath);
int sg_curl_upload_file(char *file, char *url);
int sg_file_download(file_info_s file, char *msg);

#ifdef __cplusplus
}
#endif

#endif
