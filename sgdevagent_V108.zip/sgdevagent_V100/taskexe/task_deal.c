#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include <glib-object.h>
#include <thrift/c_glib/thrift.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "ssp_mid.h"

#include "vm_public.h"
#include "sysman_rpc_api.h"
#include "app_management_service_api.h"

#include "sgdev_struct.h"
#include "sgdev_curl.h"
#include "sgdev_queue.h"

#include "sgdev_debug.h"
#include "task_dev.h"
#include "task_app.h"
#include "task_container.h"
#include "task_link.h"
#include "timer_pack.h"
#include "upmqtt_json.h"
#include "upmqtt_json.h"
#include "upmqtt_dev.h"
#include "upmqtt_app.h"
#include "upmqtt_container.h"
#include "thread_interact.h"
#include "task_deal.h"


// ����ϱ�
void sg_execute_result_report(int type, char *errormsg, dev_upgrede_res_reply_s statusobj)
{
    mqtt_data_info_s *sitem = NULL;
    sitem = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    (void)memset_s(sitem, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (memcpy_s(statusobj.msg, DATA_BUF_F256_SIZE, errormsg, DATA_BUF_F256_SIZE) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_execute_result_report: msg failed!\n");
    }
    switch (type) {
        case TAG_CMD_SYS_UPGRADE:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_CON_INSTALL:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_CON_UPGRADE:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_APP_INSTALL:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_APP_UPGRADE:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        default:
            break;
    }

    sg_pack_dev_install_result(statusobj, errormsg, sitem->msg_send);
    sg_push_pack_item(sitem);
}

// �豸��������
void sg_handle_dev_install_cmd(int32_t mid, device_upgrade_s *cmd_obj)
{
    dev_status_reply_s status = { 0 };
    dev_upgrede_res_reply_s reply_status = { 0 };
    mqtt_data_info_s *item = NULL;
    reply_status.code = REQUEST_WAIT;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };

    status.jobId = cmd_obj->jobId;
    reply_status.jobId = cmd_obj->jobId;
    status.state = STATUS_PRE_DOWNLOAD;
    set_device_upgrade_status(status); // ���ÿ�ʼ״̬

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_install_cmd: errormsg failed!\n");
    }
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_install_cmd:item is null\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_install_cmd : sprintf_s pub_topic error.\n");
    }

    if (sg_pack_dev_install_cmd(reply_status.code, mid, errormsg, item->msg_send)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "pack .\n");
    }

    sg_push_pack_item(item);

    reply_status.code = REQUEST_SUCCESS;
    status.state = STATUS_EXE_DOWNLOAD;
    set_device_upgrade_status(status);
    if (sg_file_download(cmd_obj->file, errormsg) != VOS_OK) {
        reply_status.code = REQUEST_NOTEXITS;
    }

    status.state = STATUS_PRE_INSTALL;
    set_device_upgrade_status(status);
    if (cmd_obj->policy > 0) {
        return;
    }

    if (sg_dev_install(cmd_obj, errormsg) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "device upgrade failed.\n");
        sg_execute_result_report(TAG_CMD_SYS_UPGRADE, errormsg, reply_status);
    }

    sg_write_section_file(1, cmd_obj->jobId, mid, cmd_obj->version);
}
// �豸�������� ���洦��
void sg_handle_dev_install_section(sg_dev_section_info_s *paramcfg)
{
    char errormsg[DATA_BUF_F256_SIZE]   = { 0 };
    dev_upgrede_res_reply_s reply_status = { 0 };
    dev_status_reply_s status;
    status.jobId = paramcfg->jobId;
    status.state = STATUS_FINISH_INSTALL;
    set_device_upgrade_status(status);          // ����״̬

    // �汾�ж�
    sg_execute_result_report(TAG_CMD_SYS_UPGRADE, errormsg, reply_status); // �ϱ����
}

// �豸״̬�ϱ� �豸״̬��ѯ����
void sg_handle_dev_inquire_reply(char *type, int32_t mid)
{
    char errormsg[DATA_BUF_F256_SIZE]   = { 0 };
    uint16_t code                       = REQUEST_SUCCESS;
    dev_usage_status_s devusage         = { 0 };
    dev_sta_reply_s dev_sta_rep_item    = { 0 };
    dev_reply_info_s dev_reply_item     = { 0 };
    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: errormsg failed!\n");
    }

    if (sg_devusage_status_call_get_threshold(&devusage, &dev_sta_rep_item.diskUsed) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get devusage failed", strlen("get devusage failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: devusage failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_get_device_temperature_threshold(&dev_sta_rep_item) != VOS_OK) { // �¶Ȼ�ȡ ���壨CPU���¶���Ҫ�жϻ�ȡ
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get temp failed", strlen("get temp failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: temp failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sgcc_get_links_status(&dev_sta_rep_item.linkState, &dev_sta_rep_item.link_len) != VOS_OK) { // ��ȡlinks��Ϣ
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "links_status failed", strlen("links_status failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: links_status failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_devusage_status_call_get_location(&dev_sta_rep_item) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get location failed", strlen("get location failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: location failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_device_copy_all(&dev_sta_rep_item, &devusage, errormsg) != VOS_OK) {
        code = REQUEST_FAILED;
    }
    dev_reply_item.code = code;
    dev_reply_item.mid = mid;
    if (memcpy_s(dev_reply_item.type, DATA_BUF_F64_SIZE, type, strlen(type) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: type failed!\n");
    }

    sg_dev_status_result_reply(&dev_reply_item, &dev_sta_rep_item, errormsg);
}

// �豸��Ϣ��ѯ����
void sg_handle_dev_info_cmd(int32_t mid)
{
    uint16_t code                                     = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE]                 = { 0 };
    dev_info_inq_reply_s dev_info_inq_reply_item      = { 0 };

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: errormsg failed!\n");
    }

    if (sg_get_dev_devinfo(&dev_info_inq_reply_item.dev) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "device info failed", strlen("device info failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: device info failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_get_cpu_devinfo(&dev_info_inq_reply_item.cpu) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get cpu info failed", strlen("get cpu info failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: cpu info failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_get_mem_devinfo(&dev_info_inq_reply_item.mem) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get mem info failed", strlen("get mem info failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: mem info failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_get_disk_devinfo(&dev_info_inq_reply_item.disk) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get disk info failed", strlen("get disk info failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: disk info failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_get_os_devinfo(&dev_info_inq_reply_item.os) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get os info failed", strlen("get os info failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: os info failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_get_monitor_temperature_threshold(&dev_info_inq_reply_item.temperature) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get temp info failed", strlen("get temp info failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: temp info failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_get_dev_link_and_period_param(&dev_info_inq_reply_item, errormsg) != VOS_OK) {
        code = REQUEST_FAILED;
    }
    sg_dev_info_result_reply(code, mid, &dev_info_inq_reply_item, errormsg);
}

// �豸���������޸�����
void sg_handle_dev_set_para_cmd(int32_t mid, dev_man_conf_command_s *paraobj)    // paraobjΪ�������
{
    uint16_t code                                      = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE]                  = { 0 };
    mqtt_data_info_s *item                             = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_para_cmd: errormsg failed!\n");
    }

    if (sg_set_cpu_usage_threshold(paraobj) != VOS_OK) {                      // ����CPU�����ֵ
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "set cpu_usage failed", strlen("set cpu_usage failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_para_cmd: cpu_usage failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_set_mem_usage_threshold(paraobj) != VOS_OK) {                      // ����MEM�����ֵ
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "set mem_usage failed", strlen("set mem_usage failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_para_cmd: mem_usage failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sg_set_disk_usage_threshold(paraobj) != VOS_OK) {                     // ����DISK�����ֵ
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "set disk_usage failed", strlen("set disk_usage failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_para_cmd: disk_usage failed!\n");
        }
    }

    if (sg_set_temperature_threshold(paraobj) != VOS_OK) {                    // �����¶ȼ����Ϣ
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "temperature failed", strlen("temperature failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_para_cmd: temperature failed!\n");
        }
        code = REQUEST_FAILED;
    }

    sg_set_period(&paraobj->rep_period);                                       // ʱ��������
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_para_cmd:item is NULL!\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error!\n");
    }

    if (sg_pack_dev_set_para_reply(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_set_para_reply error!\n");
    }
    sg_push_pack_item(item);
}

// �豸ʱ��ͬ������
void sg_handle_dev_set_time_cmd(int32_t mid, dev_time_command_s *timeobj)
{
    uint16_t code                      = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE]  = { 0 };
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };
    sys_time_s systime                 = { 0 };
    mqtt_data_info_s *item             = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_time_cmd: errormsg failed!\n");
    }
    if (sg_get_time(timeobj->dateTime, &systime) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get time failed", strlen("get time failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_time_cmd: dateTime failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        return;
    }

    if (datetime_action_call_set_sys_datetime_systohc(&systime, errmsg, DATA_BUF_F256_SIZE) != VOS_OK) { // ����ʱ��
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "set datetime failed", strlen("set datetime failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_time_cmd: set datetime failed!\n");
        }
        code = REQUEST_FAILED;
    }

    if (datetime_config_call_set_timezone(timeobj->timeZone, errmsg, DATA_BUF_F256_SIZE) != VOS_OK) {    // ����ʱ��
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "set timezone failed", strlen("set timezone failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_time_cmd: set timezone failed!\n");
        }
        code = REQUEST_FAILED;
    }
    sysman_rpc_transport_close();

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_set_time_cmd:item is NULL!\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error!\n");
    }

    if (sg_pack_dev_set_time_reply(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_set_time_reply error!\n");
    }
    sg_push_pack_item(item);
}

// �豸��־�ٻ�  ���Թ�
void sg_handle_dev_log_cmd(int32_t mid, dev_log_recall_s *logobj)
{
    uint16_t code                       = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE]   = { 0 };
    file_info_s fileinfo                = { 0 };
    mqtt_data_info_s *item              = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_log_cmd: errormsg failed!\n");
    }
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_log_cmd:item is null\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error.\n");
    }

    sg_pack_dev_log_reply(code, mid, errormsg, &fileinfo, item->msg_send);
    sg_push_pack_item(item);
}

// �豸��������
void sg_handle_dev_ctrl_cmd(int32_t mid, char *action)
{
    mqtt_data_info_s *item = NULL;
    uint16_t code = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_ctrl_cmd: errormsg failed!\n");
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_ctrl_cmd: item is NULL!\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error.\n");
    }

    if (sg_pack_dev_ctrl_reply(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_ctrl_reply error.\n");
    }
    sg_push_pack_item(item);

    if (strncmp(action, "os-reboot", strlen("os-reboot")) == 0) {
        if (reboot_action_call_reboot_reason(5, BOARD_MAIN, REBOOT_REASON_USER_CMD,       //�����ն�ϵͳ
            errormsg, DATA_BUF_F256_SIZE) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_ctrl_cmd: reboot_action error.\n");
        }
    } else if (strncmp(action, "edge-reboot", strlen("edge-reboot")) == 0) {
        sg_set_edge_reboot(REBOOT_EDGE_SET);                                              //�����ն����
    } else {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_ctrl_cmd: action error.\n");
    }
}

// ������װ����
void sg_handle_container_install_cmd(int32_t mid, container_install_cmd_s *cmd_obj)
{
    bool app_flag = false;
    dev_upgrede_res_reply_s statusobj = { 0 };
    dev_status_reply_s status = { 0 };
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    statusobj.code = REQUEST_WAIT;
    status.state = STATUS_PRE_DOWNLOAD;
    set_container_install_status(status);

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_install_cmd: errormsg failed!\n");
    }
    if (strlen(cmd_obj->withAPP.version) != 0) {
        app_flag = true;
        sg_container_install_reply_frame(statusobj.code, mid, errormsg);
    }

    statusobj.code = REQUEST_SUCCESS;
    status.state = STATUS_EXE_DOWNLOAD;
    set_container_install_status(status);
    if (app_flag && sg_file_download(cmd_obj->withAPP.file, errormsg) != VOS_OK) {
        statusobj.code = REQUEST_NOTEXITS;
    }

    if (sg_file_download(cmd_obj->image, statusobj.msg) != VOS_OK) {
        statusobj.code = REQUEST_NOTEXITS;
        sg_execute_result_report(TAG_CMD_CON_INSTALL, errormsg, statusobj);
        return;
    }

    if (cmd_obj->policy > 0) {        // �����������
        return;
    }

    if (sg_container_install(cmd_obj, errormsg) != VOS_OK) {
        statusobj.code = REQUEST_FAILED;
    }

    if (app_flag) {
        if (sg_container_with_app_install(cmd_obj, errormsg) != VOS_OK) {
            statusobj.code = REQUEST_FAILED;
        }
    }

    status.state = STATUS_FINISH_INSTALL;
    set_container_install_status(status);
    sg_execute_result_report(TAG_CMD_CON_INSTALL, errormsg, statusobj);
}

// ��������  �������� ֹͣ ɾ��
void sg_handle_container_control_cmd(char *type, int32_t mid, char *container_name)
{
    mqtt_data_info_s *item = NULL;
    uint16_t code = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    container_reply_info_s container_reply_item = { 0 };

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_control_cmd: errormsg failed!\n");
    }

    if (!sg_container_select_control(type, container_name, errormsg)) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "rpc_container_start failed",
            strlen("rpc_container_start failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_control_cmd: errormsg failed!\n");
        }
        code = REQUEST_FAILED;
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_start_cmd: item is NULL!\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error.\n");
    }

    container_reply_item.code = code;
    container_reply_item.mid = mid;
    if (memcpy_s(container_reply_item.type, DATA_BUF_F64_SIZE, type, strlen(type) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_control_cmd: type failed!\n");
    }

    if (sg_pack_container_control_reply(&container_reply_item, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_control_cmd: container_reply_item failed!\n");
    }
    sg_push_pack_item(item);
}

// ���������޸�
void sg_handle_container_param_set_cmd(int32_t mid, container_conf_cmd_s *cmd_obj)
{
    uint16_t code                     = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_control_cmd: errormsg failed!\n");
    }
    if (sg_container_modify_north(cmd_obj, errormsg) != VOS_OK) {
        code = REQUEST_FAILED;
    }

    sg_container_modify_reply_frame(code, mid, errormsg);
}

// �������ò�ѯ���� 
void sg_handle_container_param_get(int32_t mid)
{
    int container_num = 0;
    mqtt_data_info_s *item = NULL;
    uint16_t code = REQUEST_SUCCESS;
    CONTAINER_INFO_S *container_list = NULL;
    container_config_reply_s contiainer_config_reply = { 0 };
    char errmsg[SYSMAN_RPC_ERRMSG_MAX]               = { 0 };
    char errormsg[DATA_BUF_F256_SIZE]                = { 0 };

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_param_get: errormsg failed!\n");
    }
    if (!vm_rpc_container_status(&container_list, &container_num, NULL, errmsg, SYSMAN_RPC_ERRMSG_MAX)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_container_status error!\n");
        code = REQUEST_FAILED;
    }
    if (container_num == 0) {                   // �Ƿ���������Ϊ��
        code = REQUEST_FAILED;
        if (container_list != NULL) {           // ���ڴ��ͷŵ�
            (void)VOS_Free(container_list);
            container_list = NULL;
        }
    } else {                                    // ���������������
        if (sg_container_config_to_reply(&contiainer_config_reply, container_num, container_list) != VOS_OK) {
            code = REQUEST_FAILED;
        }
        if (container_list != NULL) {           // ���ڴ��ͷŵ�
            (void)VOS_Free(container_list);
            container_list = NULL;
        }
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_param_get:item is NULL\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic error.\n");
    }
    sg_pack_container_param_get_reply(code, mid, errormsg, &contiainer_config_reply, item->msg_send);
    sg_push_pack_item(item);
}

// ����״̬��ѯӦ�� ����״̬�ϱ�
void sg_handle_container_status_get(char *type, int32_t mid)
{
    char errormsg[DATA_BUF_F256_SIZE]   = { 0 };
    int container_cnt                   = 0;
    uint16_t code                       = REQUEST_SUCCESS;
    container_status_reply_s status     = { 0 };
    mqtt_data_info_s *item              = NULL;
    CONTAINER_INFO_S *container_list    = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_status_get: errormsg failed!\n");
    }
    if (vm_rpc_container_status(&container_list, &container_cnt, NULL, errormsg, DATA_BUF_F256_SIZE) != true) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "rpc_con_status error!", strlen("rpc_con_status error!") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_status_get: rpc_con_status failed!\n");
        }
        code = REQUEST_FAILED;
    }
    if (container_cnt == 0) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "container_cnt null!", strlen("container_cnt null!") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_status_get: container_cnt failed!\n");
        }
        code = REQUEST_FAILED;
        if (container_list != NULL) {
            (void)VOS_Free(container_list);
            container_list = NULL;
        }
    } else {
        if (sg_container_status_to_reply(&status, container_cnt, container_list) != VOS_OK) {
            if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "sg_con_status_err!", strlen("sg_con_status_err!") + 1) != 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_status_get: sg_con_status failed!\n");
            }
            code = REQUEST_FAILED;
        }
        if (container_list != NULL) {           // ���ڴ��ͷŵ�
            (void)VOS_Free(container_list);
            container_list = NULL;
        }
    }
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_status_get:item is NULL\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic error.\n");
    }
    sg_pack_container_status_get_reply(type, code, mid, errormsg, &status, item->msg_send);
    sg_push_pack_item(item);
}

// ��������  �Ⱥ���
void sg_handle_container_upgrade_cmd(int32_t mid, container_upgrade_cmd_s *cmd_obj)
{
    uint16_t code                     = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    mqtt_data_info_s *item            = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_upgrade_cmd: errormsg failed!\n");
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_upgrade_cmd:item is NULL\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_upgrade_cmd item->pub_topic error.\n");
    }

    if (sg_pack_container_upgrade_reply(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_upgrade_reply error.\n");
    }
    
    sg_push_pack_item(item);
}

// ������־�ٻ�
void sg_handle_container_log_get_cmd(int32_t mid, container_log_recall_cmd_s *cmd_obj)
{
    int ret = VOS_OK;
    uint16_t code                      = REQUEST_SUCCESS;
    mqtt_data_info_s *item             = NULL;
    file_info_s fileinfo               = { 0 };
    char errormsg[DATA_BUF_F256_SIZE]  = { 0 };
    char file_road[DATA_BUF_F256_SIZE] = { 0 };
    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_log_get_cmd: errormsg failed!\n");
    }

    if (appm_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_log_get_cmd:appm_rpc_transport_open failed\n");
        code = REQUEST_FAILED;
    }
    ret = app_management_status_call_get_app_log(cmd_obj->container, "all", 1,
        1, errormsg);  // ʱ�����õԹ����� ��ʼʱ��Ϊ������װʱ��   ����ʱ��Ϊ��ǰʱ��
    appm_rpc_transport_close();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "app_management_status_call_get_app_info error! \n");
    }

    if (sprintf_s(fileinfo.name, DATA_BUF_F64_SIZE, "{%s}.log", cmd_obj->container) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_log_get_cmd sprintf_s fileinfo.name  error \n");
    }

    if (memcpy_s(fileinfo.url, DATA_BUF_F64_SIZE, cmd_obj->url, strlen(cmd_obj->url)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_log_get_cmd memcpy_s fileinfo.url  error \n");
    }

    if (sprintf_s(file_road, DATA_BUF_F256_SIZE, "/run/shm/appm/{%s}/app_log_dir", cmd_obj->container)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_log_get_cmd sprintf_s file_road  error \n");
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_container_log_get_cmd:item is NULL\n");
        return;
    }
    
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic error.\n");
    }

    sg_pack_container_log_get_reply(code, mid, errormsg, &fileinfo, item->msg_send);
    sg_push_pack_item(item);
}

// Ӧ�ð�װ����
void sg_handle_app_install_cmd(int32_t mid, app_install_cmd_s *cmd_obj)
{
    dev_upgrede_res_reply_s statusobj = { 0 };
    statusobj.code                    = REQUEST_WAIT;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    dev_status_reply_s status         = { 0 };

    statusobj.jobId = cmd_obj->jobId;
    status.jobId = cmd_obj->jobId;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_install_cmd: errormsg failed!\n");
    }
    status.state = STATUS_PRE_DOWNLOAD;
    set_app_install_status(status);                 // ���ÿ�ʼ״̬
    sg_app_install_reply_frame(statusobj.code, mid, errormsg);

    statusobj.code = REQUEST_SUCCESS;
    status.state = STATUS_EXE_DOWNLOAD;
    set_app_install_status(status);                 // ������������

    if (sg_file_download(cmd_obj->file, statusobj.msg) != VOS_OK) {
        statusobj.code = REQUEST_NOTEXITS;
    }

    status.state = STATUS_PRE_INSTALL;
    set_app_install_status(status);                 // ��ʼ��װ
    if (cmd_obj->policy > 0) {
        return;
    }

    if (sg_app_install(cmd_obj, statusobj.msg) != VOS_OK) {
        statusobj.code = REQUEST_REFUSE;
    }

    status.state = STATUS_FINISH_INSTALL;
    set_app_install_status(status);                 // ���ð�װ���
    sg_execute_result_report(TAG_CMD_APP_INSTALL, errormsg, statusobj);
}

// Ӧ�ÿ��� �������� ֹͣ ж�� ʹ�� ȥʹ��
void sg_handle_app_control_cmd(char *type, int32_t mid, app_control_cmd_s *cmd_obj)
{
    uint16_t code                       = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE]   = { 0 };
    APPM_OPERATION_PARA  para           = { 0 };
    app_reply_info_s app_reply_item     = { 0 };
    mqtt_data_info_s *item              = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_control_cmd: errormsg failed!\n");
    }
    if (memcpy_s(para.lxc_name, APP_MANAGEMENT_LXC_NAME_MAX_LEN + 1, cmd_obj->container,
        strlen(cmd_obj->container)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_control_cmd: lxc_name failed!\n");
    }
    if (memcpy_s(para.app_name, APP_MANAGEMENT_APP_NAME_MAX_LEN + 1, cmd_obj->app, strlen(cmd_obj->app)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_control_cmd: app_name failed!\n");
    }

    if (appm_rpc_transport_open() != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "rpc_open error", strlen("rpc_open error") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_control_cmd: rpc_open failed!\n");
        }
        code = REQUEST_FAILED;
    }
    if (sg_app_select_control(type, &para) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "app_control error", strlen("app_control error") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_control_cmd: app_control failed!\n");
        }
        code = REQUEST_FAILED;
    }
    appm_rpc_transport_close();
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_start_cmd:item is NULL!\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error.\n");
    }
    app_reply_item.code = code;
    app_reply_item.mid = mid;
    if (memcpy_s(app_reply_item.type, DATA_BUF_F64_SIZE, type, strlen(type) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_control_cmd: type failed!\n");
    }
    if (sg_pack_app_control_reply(&app_reply_item, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_control_reply failed!\n");
    }
    sg_push_pack_item(item);
}

// Ӧ�������޸�
void sg_handle_app_param_set_cmd(int32_t mid, app_conf_cmd_s *cmd_obj)
{
    uint32_t cpus                 = 0;
    unsigned long long i              = 0;
    uint16_t code                     = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    APPM_OPERATION_PARA para_obj      = { 0 };
    mqtt_data_info_s *item            = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_set_cmd: errormsg failed!\n");
    }
    if (memcpy_s(para_obj.lxc_name, APP_MANAGEMENT_LXC_NAME_MAX_LEN + 1, cmd_obj->container,
        strlen(cmd_obj->container)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_set_cmd: lxc_name failed!\n");
    }
    if (memcpy_s(para_obj.app_name, APP_MANAGEMENT_LXC_NAME_MAX_LEN + 1, cmd_obj->app, strlen(cmd_obj->app)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_set_cmd: app_name failed!\n");
    }
    cpus = (uint32_t)cmd_obj->cfgCpu.cpus;
    para_obj.cpu_mask = 0;
    for (i = 0; i < cpus; i++) {
        para_obj.cpu_mask |= i;
    }
    para_obj.cpu_threshold = (int)cmd_obj->cfgCpu.cpuLmt;
    para_obj.memory_limit = (int)cmd_obj->cfgMem.memory;
    para_obj.memory_threshold = (int)cmd_obj->cfgMem.memLmt;
    if (sg_appm_modify_app_info_cmd(&para_obj) != VOS_OK) {
        code = REQUEST_FAILED;
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_stop_cmd:item is NULL!\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error.\n");
    }

    if (sg_pack_app_param_set_reply(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_param_set_reply error.\n");
    }
    sg_push_pack_item(item);
}

// Ӧ������״̬��ѯ����
void sg_handle_app_param_get(int32_t mid, char *container_name)
{
    int ret                           = VOS_OK;
    int app_cnt                       = 0;
    int num                           = 0;
    uint16_t code                     = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    app_conf_reply_s statusobj        = { 0 };
    app_info_t *app_info              = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_get: errormsg failed!\n");
    }

    if (appm_rpc_transport_open() != VOS_OK) {
        code = REQUEST_FAILED;
    }
    ret = app_management_status_call_get_app_info(container_name, &app_info, &app_cnt, errormsg);
    appm_rpc_transport_close();
    if (ret != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "app_management_status_call_get_app_info error",
            strlen("app_management_status_call_get_app_info error") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_get: app_management failed!\n");
        }
        code = REQUEST_FAILED;
    }
    statusobj.app_num = app_cnt;
    if (memcpy_s(statusobj.container, DATA_BUF_F64_SIZE, container_name, strlen(container_name)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_get: container failed!\n");
    }

    statusobj.appCfgs = (app_cfgs_info_s*)VOS_Malloc(MID_SGDEV, sizeof(app_cfgs_info_s) * (size_t)app_cnt);
    if (statusobj.appCfgs == NULL) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "appCfgs is null", strlen("appCfgs is null") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_get: appCfgs failed!\n");
        }
        code = REQUEST_FAILED;
    }
    (void)memset_s(statusobj.appCfgs, sizeof(app_cfgs_info_s) * (size_t)app_cnt, 0,
        sizeof(app_cfgs_info_s) * (size_t)app_cnt);
    for (num = 0; num < app_cnt; num++) { 
        if (memcpy_s(statusobj.appCfgs[num].app, DATA_BUF_F64_SIZE, app_info[num].name,
            strlen(app_info[num].name)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_get: app failed!\n");
        }
        statusobj.appCfgs[num].cfgCpu.cpus = sg_hamming_weight(app_info[num].services->cpu_mask);
        statusobj.appCfgs[num].cfgCpu.cpuLmt = app_info[num].services->cpu_usage_threshold;
        statusobj.appCfgs[num].cfgMem.memory = app_info[num].services->memory_usage_current;
        statusobj.appCfgs[num].cfgMem.memLmt = app_info[num].services->memory_usage_threshold;
    }
    sg_app_config_result_reply(code, mid, &statusobj, errormsg);
    (void)VOS_Free(statusobj.appCfgs);
    statusobj.appCfgs = NULL;
}

// Ӧ��״̬��ѯ����
void sg_handle_app_status_get(char *type, int32_t mid, char *container_name)
{
    int num                           = 0;
    int app_cnt                       = 0;
    uint16_t code                     = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    mqtt_data_info_s *item            = NULL;
    app_info_t *app_info              = NULL;
    app_inq_reply_s statusobj         = { 0 };

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_status_get: errormsg failed!\n");
    }
    if (appm_rpc_transport_open() != VOS_OK) {
        code = REQUEST_FAILED;
    }
    if (app_management_status_call_get_app_info(container_name, &app_info, &app_cnt, errormsg) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "app_management_status_call_get_app_info error",
            strlen("app_management_status_call_get_app_info error") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_status_get: app_management failed!\n");
        }
        code = REQUEST_FAILED;
    }
    appm_rpc_transport_close();
    statusobj.apps_num = app_cnt;
    if (memcpy_s(statusobj.container, DATA_BUF_F64_SIZE, container_name, strlen(container_name)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_status_get: container failed!\n");
    }

    if (sg_get_apps_array(statusobj.apps, app_cnt, app_info) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get_apps_array failed", strlen("get_apps_array failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_status_get: get_apps_array failed!\n");
        }
        code = REQUEST_FAILED;
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_status_get:item is NULL\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic error.\n");
    }
    sg_pack_app_status_get_reply(type, code, mid, errormsg, &statusobj, item->msg_send);

    for (num = 0; num < app_cnt; num++) {   // �ͷ��ڴ�
        (void)VOS_Free(statusobj.apps[num].process);
        statusobj.apps[num].process = NULL;
    }
    (void)VOS_Free(statusobj.apps);
    statusobj.apps = NULL;
    sg_push_pack_item(item);
}

// Ӧ��״̬�ϱ�
void sg_handle_app_status_report(char *type, int32_t mid)
{
    int num           = 0;
    int container_num = 0;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };
    CONTAINER_INFO_S *container_list = NULL;

    if (!vm_rpc_container_status(&container_list, &container_num, NULL, errmsg, SYSMAN_RPC_ERRMSG_MAX)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_container_status error.\n");
    }

    if (container_num == 0) {                   // �Ƿ���������Ϊ��
        if (container_list != NULL) {           // ���ڴ��ͷŵ�
            (void)VOS_Free(container_list);
            container_list = NULL;
        }
    } else {                                    // ���������������
        for (num = 0; num < container_num; num++) {
            sg_handle_app_status_get(type, mid, container_list[num].container_name);
        }

        if (container_list != NULL) {           // ���ڴ��ͷŵ�
            (void)VOS_Free(container_list);
            container_list = NULL;
        }
    }
}

// Ӧ������
void sg_handle_app_upgrade_cmd(int32_t mid, app_upgrade_cmd_s *cmd_obj)
{
    dev_upgrede_res_reply_s statusobj = { 0 };
    statusobj.code                    = REQUEST_WAIT;
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    dev_status_reply_s status         = { 0 };

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_upgrade_cmd: errormsg failed!\n");
    }
    statusobj.jobId = cmd_obj->jobId;
    status.jobId = cmd_obj->jobId;
    status.state = STATUS_PRE_DOWNLOAD;
    set_app_upgrade_status(status);     //���ÿ�ʼ״̬
    sg_app_update_reply_frame(statusobj.code, mid, errormsg);

    statusobj.code = REQUEST_SUCCESS;
    status.state = STATUS_EXE_DOWNLOAD;
    set_app_upgrade_status(status);     //������������

    if (sg_file_download(cmd_obj->file, statusobj.msg) != VOS_OK) {
        statusobj.code = REQUEST_NOTEXITS;
    }

    status.state = STATUS_PRE_INSTALL;
    set_app_upgrade_status(status);     //��ʼ��װ

    if (cmd_obj->policy > 0) {
        return;
    }
    if (sg_app_update(cmd_obj, statusobj.msg) != VOS_OK) {
        statusobj.code = REQUEST_REFUSE;
    }

    status.state = STATUS_FINISH_INSTALL;
    set_app_install_status(status);                 // ���ð�װ���
    sg_execute_result_report(TAG_CMD_APP_UPGRADE, errormsg, statusobj);
}

// Ӧ����־��ѯ
void sg_handle_app_log_get_cmd(int32_t mid, app_log_recall_cmd_s cmd_obj)
{
    uint16_t code                      = REQUEST_SUCCESS;
    char errormsg[DATA_BUF_F256_SIZE]  = { 0 };
    file_info_s fielinfo               = { 0 };
    mqtt_data_info_s *item             = NULL;

    if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "command success", strlen("command success") + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_log_get_cmd: errormsg failed!\n");
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_log_get_cmd:item is NULL\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic error.\n");
    }

    sg_pack_app_log_get_reply(code, mid, errormsg, &fielinfo, item->msg_send);
    sg_push_pack_item(item);
}
