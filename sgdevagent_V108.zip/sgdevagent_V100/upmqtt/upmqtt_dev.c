#include <time.h>
#include <string.h>
#include <stdlib.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vos_util.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "sysman_rpc_api.h"

#include "sgdev_struct.h"
#include "sgdev_debug.h"
#include "sgdev_param.h"
#include "upmqtt_json.h"
#include "upmqtt_dev.h"
#include "task_dev.h"

// A.1 �豸��Ϣ�ֶ�:dev��֡����
static int json_dev_set_new(json_t *obj, dev_info_s *dev_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }
    (void)json_object_set_new(obj, "devType", json_string(dev_str->devType));
    (void)json_object_set_new(obj, "devName", json_string(dev_str->devName));
    (void)json_object_set_new(obj, "mfgInfo", json_string(dev_str->mfgInfo));
    (void)json_object_set_new(obj, "devStatus", json_string(dev_str->devStatus));
    (void)json_object_set_new(obj, "hardVersion", json_string(dev_str->hardVersion));
    return VOS_OK;
}
// A.2 CPU ��Ϣ�ֶ�:cpu��֡����
static int json_cpu_set_new(json_t *obj, cpu_info_s *cpu_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }
    (void)json_object_set_new(obj, "cpus", json_integer(cpu_str->cpus));
    (void)json_object_set_new(obj, "frequency", json_real(cpu_str->frequency));
    if (cpu_str->cache != 0) {
        (void)json_object_set_new(obj, "cache", json_integer(cpu_str->cache));
    }

    if (strlen(cpu_str->arch) != 0) {
        (void)json_object_set_new(obj, "arch", json_string(cpu_str->arch));
    }

    if (cpu_str->cpuLmt != 0) {
        (void)json_object_set_new(obj, "cpuLmt", json_integer(cpu_str->cpuLmt));
    }
    return VOS_OK;
}

// A.3 �ڴ���Ϣ�ֶ�:mem��֡����
static int json_mem_set_new(json_t *obj, mem_info_s *mem_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    (void)json_object_set_new(obj, "phy", json_integer(mem_str->phy));
    if (mem_str->virt != 0) {
        (void)json_object_set_new(obj, "virt", json_integer(mem_str->virt));
    }

    if (mem_str->memLmt != 0) {
        (void)json_object_set_new(obj, "memLmt", json_integer(mem_str->memLmt));
    }
    return VOS_OK;
}
// A.4 Ӳ����Ϣ�ֶ�:disk��֡����
static int json_disk_set_new(json_t *obj, disk_info_s *disk_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    (void)json_object_set_new(obj, "disk", json_integer(disk_str->disk));
    if (disk_str->diskLmt != 0) {
        (void)json_object_set_new(obj, "diskLmt", json_integer(disk_str->diskLmt));
    }
    return VOS_OK;
}
// A.5 ����豸��Ϣ�ֶ�:links��֡����
static int json_links_set_new(json_t *obj, link_info_s *link_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    if (strlen(link_str->id) != 0) {
        (void)json_object_set_new(obj, "id", json_string(link_str->id));
    }

    if (strlen(link_str->mac) != 0) {
        (void)json_object_set_new(obj, "mac", json_string(link_str->mac));
    }

    (void)json_object_set_new(obj, "name", json_string(link_str->name));
    (void)json_object_set_new(obj, "type", json_string(link_str->type));

    if (link_str == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "json_links_set_new: link_str is NULL. \n");
        return VOS_ERR;
    }

    if (obj == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "json_links_set_new: obj is NULL. \n");
        return VOS_ERR;
    }

    (void)json_object_set_new(obj, "id", json_string(link_str->id));
    (void)json_object_set_new(obj, "mac", json_string(link_str->mac));
    (void)json_object_set_new(obj, "name", json_string(link_str->name));
    (void)json_object_set_new(obj, "type", json_string(link_str->type));
    return VOS_OK;
}
// A.6 ����ϵͳ��Ϣ�ֶ�:os��֡����
static int json_os_set_new(json_t *obj, os_info_s *os_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    (void)json_object_set_new(obj, "distro", json_string(os_str->distro));
    (void)json_object_set_new(obj, "version", json_string(os_str->version));
    (void)json_object_set_new(obj, "kernel", json_string(os_str->kernel));
    (void)json_object_set_new(obj, "softVersion", json_string(os_str->softVersion));
    (void)json_object_set_new(obj, "patchVersion", json_string(os_str->patchVersion));
    return VOS_OK;
}

// temp:�¶ȼ����֡����
static int json_temp_set_new(json_t *obj, temp_info_s *temp_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    (void)json_object_set_new(obj, "temLow", json_integer(temp_str->temLow));
    (void)json_object_set_new(obj, "temHigh", json_integer(temp_str->temHigh));
    return VOS_OK;
}
// ״̬�����ϱ����ϱ�ʱ������֡����
static int json_rep_set_new(json_t *obj, rep_period_s *rep_str)
{
    if (obj == NULL) {
        return VOS_ERR;
    }
    if (rep_str->devPeriod != 0) {
        (void)json_object_set_new(obj, "devPeriod", json_integer(rep_str->devPeriod));
    }

    if (rep_str->conPeriod != 0) {
        (void)json_object_set_new(obj, "conPeriod", json_integer(rep_str->conPeriod));
    }

    if (rep_str->appPeriod != 0) {
        (void)json_object_set_new(obj, "appPeriod", json_integer(rep_str->appPeriod));
    }

    if (rep_str->heartPeriod != 0) {
        (void)json_object_set_new(obj, "heartPeriod", json_integer(rep_str->heartPeriod));
    }
    return VOS_OK;
}

static void sg_pack_dev(json_t *obj, dev_acc_req_s *devaccobj)
{
    json_t *dev_object = NULL;
    json_t *cpu_object = NULL;
    json_t *mem_object = NULL;
    json_t *disk_object = NULL;
    json_t *os_object = NULL;

    dev_object = json_object();
    if (!json_dev_set_new(dev_object, &devaccobj->dev)) {
        (void)json_object_set_new(obj, "dev", dev_object);
    }

    cpu_object = json_object();
    if (!json_cpu_set_new(cpu_object, &devaccobj->cpu)) {
        (void)json_object_set_new(obj, "cpu", cpu_object);
    }

    mem_object = json_object();
    if (!json_mem_set_new(mem_object, &devaccobj->mem)) {
        (void)json_object_set_new(obj, "mem", mem_object);
    }

    disk_object = json_object();
    if (!json_disk_set_new(disk_object, &devaccobj->disk)) {
        (void)json_object_set_new(obj, "disk", disk_object);
    }

    os_object = json_object();
    if (!json_os_set_new(os_object, &devaccobj->os)) {
        (void)json_object_set_new(obj, "os", os_object);
    }
}
/* ****************************************************************************
�� �� ��  : sg_pack_dev_linkup_data
��������  : �豸��������
�������  : linkupobj
�������  : *msg
�� �� ֵ  :
���ú���  :
��������  :
**************************************************************************** */
void sg_pack_dev_linkup_data(dev_acc_req_s *linkupobj, char *msg)
{
    uint16_t i        = 0;
    uint16_t code     = 0;
    int32_t mid       = 0;
    json_t *param     = NULL;
    json_t *link_obj  = NULL;
    json_t *links_obj = NULL;

    mid = (int32_t)VOS_GetRandomNum(0, 2147483647);
    param = json_object();
    links_obj = json_array();
    if (links_obj == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_linkup_data: links_obj is null\n");
    }
    for (i = 0; i < linkupobj->link_len; i++) {
        link_obj = json_object();
        if (!json_links_set_new(link_obj, &linkupobj->links[i])) {
            (void)json_array_append_new(links_obj, link_obj);
        }
    }

    sg_pack_dev(param, linkupobj);
    (void)json_object_set_new(param, "links", links_obj);
    char *mssm = sg_pack_json_msg_header(code, mid, EVENT_LINKUP, NULL, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_linkup_data: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}

// �豸����Ӧ��
void sg_pack_dev_linkup_reply(const char *error_msg, char *msg)
{
    uint16_t code = 0;
    int32_t mid = 0;
    json_t *param = NULL;
    param = json_object();
    char *mssm = sg_pack_json_msg_header(code, mid, EVENT_LINKUP, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_linkup_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }
}

/* ****************************************************************************
�� �� ��  : sg_pack_dev_linkdown_data
��������  : �豸�����Ͽ��ϱ�
�������  : linkdownobj
�������  : *msg
�� �� ֵ  :
���ú���  :
��������  :
**************************************************************************** */
void sg_pack_dev_linkdown_data(char *linkdownobj, const char *error_msg, char *msg)
{
    uint16_t code     = 0;
    int32_t mid       = 0;
    json_t *reason_obj = NULL;

    reason_obj = json_object();
    (void)json_object_set_new(reason_obj, "reason", json_string(linkdownobj));
    char *mssm = sg_pack_json_msg_header(code, mid, EVENT_LINKDOWN, error_msg, reason_obj);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_linkdown_data: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }
}

// �豸��������
int sg_pack_dev_heartbeat_request_data(char *msg)
{
    int ret = VOS_OK;
    time_t now_time;
    now_time = time(NULL);
    json_t *heartbeat_obj = NULL;
    heart_request_s heart_request = { 0 };
    
    if (sprintf_s(heart_request.type, DATA_BUF_F32_SIZE, "%s", EVENT_HEARTBEAT) < 0) {
        return VOS_ERR;
    }

    heartbeat_obj = json_object();
    sg_dev_param_info_s idparam = sg_get_param();
    (void)json_object_set_new(heartbeat_obj, "deviceId", json_string(idparam.devid));
    ret = sg_mqtt_time_str(now_time, heart_request.timestamp, sizeof(heart_request.timestamp), TIME_UTC);  // ʹ��UTCʱ��
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "\nFill json header failed for generate time str.\n");
        return VOS_ERR;
    }

    (void)json_object_set_new(heartbeat_obj, "timestamp", json_string(heart_request.timestamp));
    (void)json_object_set_new(heartbeat_obj, "type", json_string(heart_request.type));
    char *mssm = json_dumps(heartbeat_obj, JSON_PRESERVE_ORDER);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_heartbeat_request_data: msg failed!\n");
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "msg = %s\n", msg);
    if (mssm != NULL) {
        free(mssm);
    }

    json_decref(heartbeat_obj);
    return VOS_OK;
    // deviceId string �� ���豸Ψһ��ʶ
    // timestamp string �� ��Ϣ���͵�ʱ�����CST ʱ��, ���ȵ���
    // type string �� EVENT_HEARTBEAT
    // ����Ҫ���� pack_json_msg_header(code, mid, type, param);
}

// �豸����Ӧ��
int sg_pack_dev_heartbeat_response_data(char *msg)
{
    int ret = VOS_OK;
    time_t now_time;
    now_time = time(NULL);
    json_t *heartbeat_obj = NULL;
    heart_reply_s heart_reply = { 0 };
    heart_reply.code = REQUEST_SUCCESS;
    if (sprintf_s(heart_reply.type, DATA_BUF_F32_SIZE, "%s", EVENT_HEARTBEAT) < 0) {
        return VOS_ERR;
    }

    heartbeat_obj = json_object();
    sg_dev_param_info_s idparam = sg_get_param();
    (void)json_object_set_new(heartbeat_obj, "deviceId", json_string(idparam.devid));
    ret = sg_mqtt_time_str(now_time, heart_reply.timestamp, sizeof(heart_reply.timestamp), 1);    // ʹ��UTCʱ��
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Fill json header failed for generate time str.\n");
        return VOS_ERR;
    }

    (void)json_object_set_new(heartbeat_obj, "timestamp", json_string(heart_reply.timestamp));
    (void)json_object_set_new(heartbeat_obj, "type", json_string(heart_reply.type));
    (void)json_object_set_new(heartbeat_obj, "code", json_integer(heart_reply.code));
    char *mssm = json_dumps(heartbeat_obj, JSON_PRESERVE_ORDER);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_heartbeat_response_data: msg failed!\n");
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "msg = %s\n", msg);
    if (mssm != NULL) {
        free(mssm);
    }

    json_decref(heartbeat_obj);
    return VOS_OK;
}

/*****************************************************************************
�� �� ��  : sg_unpack_dev_install_cmd
��������  : �豸��������
�������  : obj
�������  : *cmd_obj
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
int sg_unpack_dev_install_cmd(json_t *obj, device_upgrade_s *cmd_obj)
{
    json_t* file_info = NULL;
    if (json_into_int32_t(&cmd_obj->jobId, obj, "jobId") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_int32_t(&cmd_obj->jobId, obj, "policy") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_install_cmd:policy get fail!\n");
    }

    if (json_into_string(cmd_obj->version, obj, "version") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_uint8_t(&cmd_obj->upgradeType, obj, "upgradeType") != VOS_OK) {
        return VOS_ERR;
    }

    file_info = json_object_get(obj, "file");
    if (sg_get_file(file_info, &cmd_obj->file) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

// �豸��������Ӧ��  ��param
int sg_pack_dev_install_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_SYS_UPGRADE, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_install_cmd: msg failed!\n");
    }
    free(mssm);
    return VOS_OK;
}
// �豸����״̬��ѯ����   ����Ӧ��Ҳһ��
int32_t sg_unpack_dev_install_query(json_t *obj)
{
    int32_t jobid = 0;

    if (json_into_int32_t(&jobid, obj, "jobId") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "jobid get error\n"); 
    }
    return jobid;
}

/*****************************************************************************
�� �� ��  : sg_pack_dev_install_query
��������  : �豸����״̬��ѯӦ�� (����Ӧ��Ҳһ��)
�������  : code mid *statusobj
�������  : *msg
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
int sg_pack_dev_install_query(uint16_t code, int32_t mid, const char *error_msg,
        dev_status_reply_s statusobj, char *msg)
{
    json_t *param = NULL;

    param = json_object();
    (void)json_object_set_new(param, "jobId", json_integer(statusobj.jobId));
    (void)json_object_set_new(param, "progress", json_integer(statusobj.progress));
    (void)json_object_set_new(param, "state", json_integer(statusobj.state));
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_STATUS_QUERY, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_install_query: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
    return VOS_OK;
}
// �豸��������ϱ� ������Ӧ��Ҳһ��
void sg_pack_dev_install_result(dev_upgrede_res_reply_s statusobj, const char *error_msg, char *msg)
{
    uint16_t code = 0;
    int32_t mid = 0;
    json_t *param = NULL;
    param = json_object();
    (void)json_object_set_new(param, "jobId", json_integer(statusobj.jobId));
    (void)json_object_set_new(param, "code", json_integer(statusobj.code));
    if (strlen(statusobj.msg) != 0) {
        (void)json_object_set_new(param, "msg", json_string(statusobj.msg));
    }

    char *mssm = sg_pack_json_msg_header(code, mid, REP_JOB_RESULT, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_install_result: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}

static int json_fram_mem(json_t *obj, dev_sta_reply_s *devstaobj)
{
    int ret = VOS_OK;
    if (!json_is_object(obj)) {
        return VOS_ERR;
    }
    (void)json_object_set_new(obj, "phy", json_integer(devstaobj->mem_used.phy));
    (void)json_object_set_new(obj, "virt", json_integer(devstaobj->mem_used.virt));
    return ret;
}

// �豸״̬�ϱ� �豸״̬��ѯӦ��
void sg_pack_dev_run_status(dev_reply_info_s *reply_info, dev_sta_reply_s *statusobj, const char *error_msg, char *msg)
{
    int i = 0;
    json_t *link_state_obj = NULL;
    json_t *link_states_obj = json_array();
    json_t *param = json_object();
    json_t *mem_object = json_object();
    if (!json_is_array(link_states_obj)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_run_status: link_states_obj is null\n");
    }

    for (i = 0; i < statusobj->link_len; i++) {
        link_state_obj = json_object();
        if (!json_is_object(link_state_obj)) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_run_status: link_state_obj is null\n");
        }

        (void)json_object_set_new(link_state_obj, "name", json_string(statusobj->linkState[i].name));
        (void)json_object_set_new(link_state_obj, "status", json_string(statusobj->linkState[i].status));
        (void)json_array_append_new(link_states_obj, link_state_obj);
    }

    (void)json_object_set_new(param, "cpuRate", json_integer(statusobj->cpuRate));
    if (json_fram_mem(mem_object, statusobj) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "json_fram_mem error!!!\n");
    }

    (void)json_object_set_new(param, "memUsed", mem_object);
    (void)json_object_set_new(param, "diskUsed", json_integer(statusobj->diskUsed));
    (void)json_object_set_new(param, "tempValue", json_integer(statusobj->tempValue));
    (void)json_object_set_new(param, "devDateTime", json_string(statusobj->devDateTime));
    (void)json_object_set_new(param, "devStDateTime", json_string(statusobj->devStDateTime));
    (void)json_object_set_new(param, "devRunTime", json_integer(statusobj->devRunTime));
    (void)json_object_set_new(param, "linkState", link_states_obj);
    if (strlen(statusobj->longitude) == 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_run_status: longitude is 0\n");
    }

    (void)json_object_set_new(param, "longitude", json_string(statusobj->longitude));
    if (strlen(statusobj->latitude) == 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_run_status: latitude is 0\n");
    }

    (void)json_object_set_new(param, "latitude", json_string(statusobj->latitude));
    char *mssm = sg_pack_json_msg_header(reply_info->code, reply_info->mid, reply_info->type, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_run_status: msg failed!\n");
    }

    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}

static void sg_pack_devinfo(json_t *obj, dev_info_inq_reply_s *devinfoobj)
{
    json_t *dev_object = NULL;
    json_t *cpu_object = NULL;
    json_t *mem_object = NULL;
    json_t *disk_object = NULL;
    json_t *temp_object = NULL;
    json_t *os_object = NULL;

    dev_object = json_object();
    if (!json_dev_set_new(dev_object, &devinfoobj->dev)) {
        (void)json_object_set_new(obj, "dev", dev_object);
    }

    cpu_object = json_object();
    if (!json_cpu_set_new(cpu_object, &devinfoobj->cpu)) {
        (void)json_object_set_new(obj, "cpu", cpu_object);
    }

    mem_object = json_object();
    if (!json_mem_set_new(mem_object, &devinfoobj->mem)) {
        (void)json_object_set_new(obj, "mem", mem_object);
    }

    disk_object = json_object();
    if (!json_disk_set_new(disk_object, &devinfoobj->disk)) {
        (void)json_object_set_new(obj, "disk", disk_object);
    }

    temp_object = json_object();
    if (!json_temp_set_new(temp_object, &devinfoobj->temperature)) {
        (void)json_object_set_new(obj, "temperature", temp_object);
    }

    os_object = json_object();
    if (!json_os_set_new(os_object, &devinfoobj->os)) {
        (void)json_object_set_new(obj, "os", os_object);
    }
}

// �豸��Ϣ��ѯ����Ӧ�� 
int sg_pack_dev_info_reply(uint16_t code, int32_t mid, const char *error_msg,
        dev_info_inq_reply_s *statusobj, char *msg)
{
    uint16_t i = 0;
    json_t *param = NULL;
    json_t *link_obj = NULL;
    json_t *links_obj = NULL;
    json_t *rep_period_obj = NULL;

    param = json_object();
    links_obj = json_array();
    if (links_obj == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_info_reply: links_obj is null\n");
    }
    for (i = 0; i < statusobj->link_len; i++) {
        link_obj = json_object();
        if (!json_links_set_new(link_obj, &statusobj->links[i])) {
            (void)json_array_append_new(links_obj, link_obj);
        }
    }
    sg_pack_devinfo(param, statusobj);
    (void)json_object_set_new(param, "links", links_obj);
    rep_period_obj = json_object();
    if (!json_rep_set_new(rep_period_obj, &statusobj->rep_period)) {
        (void)json_object_set_new(param, "repPeriod", rep_period_obj);
    }

    char *mssm = sg_pack_json_msg_header(code, mid, CMD_INFO_QUERY, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_info_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
    return VOS_OK;
}
// �豸���������޸�����
int sg_unpack_dev_set_para_cmd(json_t *obj, dev_man_conf_command_s *paraobj)
{
    json_t* temp_info = NULL;
    json_t* rep_period_info = NULL;

    if (json_into_string(paraobj->devName, obj, "devName") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:devName get fail!\n");
    }

    if (json_into_uint8_t(&paraobj->cpuLmt, obj, "cpuLmt") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:cpuLmt get fail!\n");
    }

    if (json_into_uint8_t(&paraobj->memLmt, obj, "memLmt") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:memLmt get fail!\n");
    }

    if (json_into_uint8_t(&paraobj->diskLmt, obj, "diskLmt") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:diskLmt get fail!\n");
    }

    temp_info = json_object_get(obj, "temperature");
    if (json_is_object(temp_info)) {
        if (json_into_int32_t(&paraobj->temperature.temLow, temp_info, "temLow") != VOS_OK) {
            return VOS_ERR;
        }

        if (json_into_int32_t(&paraobj->temperature.temHigh, temp_info, "temHigh") != VOS_OK) {
            return VOS_ERR;
        }
    }

    rep_period_info = json_object_get(obj, "repPeriod");
    if (json_is_object(rep_period_info)) {
        if (json_into_uint32_t(&paraobj->rep_period.devPeriod, rep_period_info, "devPeriod") != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:devPeriod get fail!\n");
        }

        if (json_into_uint32_t(&paraobj->rep_period.conPeriod, rep_period_info, "conPeriod") != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:conPeriod get fail!\n");
        }

        if (json_into_uint32_t(&paraobj->rep_period.appPeriod, rep_period_info, "appPeriod") != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:appPeriod get fail!\n");
        }
        
        if (json_into_uint32_t(&paraobj->rep_period.heartPeriod, rep_period_info, "heartPeriod") != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_unpack_dev_set_para_cmd:heartPeriod get fail!\n");
        }
    }
    return VOS_OK;
}

// �豸���������޸�����Ӧ�� ��param
int sg_pack_dev_set_para_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_SYS_SET_CONFIG, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_set_para_reply: msg failed!\n");
    }
    free(mssm);
    return VOS_OK;
}
// �豸ʱ��ͬ������
int sg_unpack_dev_set_time_cmd(json_t *obj, dev_time_command_s *timeobj)
{
    if (json_into_string(timeobj->dateTime, obj, "dateTime") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_string(timeobj->timeZone, obj, "timeZone") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
// �豸ʱ��ͬ������Ӧ�� ��param
int sg_pack_dev_set_time_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_DATETIME_SYN, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_set_time_reply: msg failed!\n");
    }
    free(mssm);
    return VOS_OK;
}
// �豸�¼��ϱ�
void sg_pack_dev_event(dev_thing_reply_s *evenobj, const char *error_msg, char *msg)
{
    char *mssm    = NULL;
    json_t *param = NULL;
    uint16_t code = 0;
    int32_t mid   = 0;

    param = json_object();
    (void)json_object_set_new(param, "event", json_string(evenobj->event));
    if (strlen(evenobj->msg) == 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_event: msg is null\n");
    }
    (void)json_object_set_new(param, "msg", json_string(evenobj->msg));
    mssm = sg_pack_json_msg_header(code, mid, EVENT_SYS_ALARM, NULL, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_event: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}
// �豸��־�ٻ�
int sg_unpack_dev_log_cmd(json_t *obj, dev_log_recall_s *logobj)
{
    if (json_into_string(logobj->url, obj, "url") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_uint8_t(&logobj->logType, obj, "logType") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
// �豸��־�ٻ�Ӧ��
void sg_pack_dev_log_reply(uint16_t code, int32_t mid, const char *error_msg, file_info_s *logobj, char *msg)
{
    json_t *param = NULL;
    json_t *sign_object = NULL;

    param = json_object();
    sign_object = json_object();
    if (sign_object != NULL) {
        (void)json_object_set_new(sign_object, "name", json_string(logobj->sign.name));
        if (strlen(logobj->sign.url) == 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_log_reply: sign.url is null\n");
        }
        (void)json_object_set_new(sign_object, "url", json_string(logobj->sign.url));
        if (logobj->sign.size == 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_log_reply: sign.size is null\n");
        }
        (void)json_object_set_new(sign_object, "size", json_integer(logobj->sign.size));
        if (strlen(logobj->sign.md5) == 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_log_reply: sign.md5 is null\n");
        }
        (void)json_object_set_new(sign_object, "md5", json_string(logobj->sign.md5));
    }
    (void)json_object_set_new(param, "name", json_string(logobj->name));
    if (strlen(logobj->fileType) == 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_log_reply: fileType is null\n");
    }
    (void)json_object_set_new(param, "fileType", json_string(logobj->fileType));

    if (strlen(logobj->url) == 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_log_reply: url is null\n");
    }
    (void)json_object_set_new(param, "url", json_string(logobj->url));
    (void)json_object_set_new(param, "size", json_integer(logobj->size));
    (void)json_object_set_new(param, "md5", json_string(logobj->md5));
    (void)json_object_set_new(param, "sign", sign_object);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_SYS_LOG, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_log_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}
// �豸��������
int sg_unpack_dev_ctrl_cmd(json_t *obj, char *ctrlobj)
{
    if (json_into_string(ctrlobj, obj, "action") != VOS_OK) {
        return VOS_ERR;
    }

    return VOS_OK;
}
// �豸��������Ӧ�� ��param
int sg_pack_dev_ctrl_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_CTRL, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }
    
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_ctrl_reply: msg failed!\n");
    }
    free(mssm);
    return VOS_OK;
}

