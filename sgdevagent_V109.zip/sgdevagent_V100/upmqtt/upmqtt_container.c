#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "sgdev_struct.h"
#include "sgdev_param.h"
#include "sgdev_debug.h"
#include "upmqtt_json.h"
#include "upmqtt_container.h"
#include "vm_public.h"
#include "securec.h"
#include "task_container.h"

// ����withAPP����
static int sg_get_with_app(json_t *obj, with_app_info_s *withappobj)
{
    json_t *withApp_file_info = NULL;
    json_t *withApp_cfgCpu_info = NULL;
    json_t *withApp_cfgMem_info = NULL;
    if (json_is_object(obj)) {
        if (json_into_string(withappobj->version, obj, "version") != VOS_OK) {
            return VOS_ERR;
        }

        if (json_into_string(withappobj->enable, obj, "enable") != VOS_OK) {
            return VOS_ERR;
        }

        withApp_file_info = json_object_get(obj, "file");
        if (sg_get_file(withApp_file_info, &withappobj->file) != VOS_OK) {
            return VOS_ERR;
        }

        withApp_cfgCpu_info = json_object_get(obj, "cfgCpu");
        if (withApp_cfgCpu_info != NULL && json_is_object(withApp_cfgCpu_info)) {
            if (json_into_int32_t(&withappobj->cfgCpu.cpus, withApp_cfgCpu_info, "cpus") != VOS_OK) {
                return VOS_ERR;
            }
            if (json_into_int32_t(&withappobj->cfgCpu.cpuLmt, withApp_cfgCpu_info, "cpuLmt") != VOS_OK) {
                return VOS_ERR;
            }
        }

        withApp_cfgMem_info = json_object_get(obj, "cfgMem");
        if (withApp_cfgMem_info != NULL && json_is_object(withApp_cfgMem_info)) {
            if (json_into_int32_t(&withappobj->cfgMem.memory, withApp_cfgMem_info, "memory") != VOS_OK) {
                return VOS_ERR;
            }
            if (json_into_int32_t(&withappobj->cfgMem.memLmt, withApp_cfgMem_info, "memLmt") != VOS_OK) {
                return VOS_ERR;
            }
        }
    } else {
        return VOS_ERR;
    }
    return VOS_OK;
}
// ����������װ���Ʋ�����Ϣ
static int sg_get_container_info(json_t *obj, container_install_cmd_s *cmd_obj)
{
    size_t i = 0;
    json_t *mount_info = NULL;
    json_t *image_info = NULL;
    json_t *withAPP_info = NULL;

    if (json_into_int32_t(&cmd_obj->jobId, obj, "jobId") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "jobId get failed!\n");
        return VOS_ERR;
    }

    if (json_into_uint32_t(&cmd_obj->policy, obj, "policy") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "policy get failed!\n");
    }

    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->port, obj, "port") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "port get failed!\n");
    }

    mount_info = json_object_get(obj, "mount");
    if (mount_info == NULL) {
        return VOS_ERR;
    }

    cmd_obj->mount_len = json_array_size(mount_info);
    for (i = 0; i < cmd_obj->mount_len; i++) {
        if (json_into_array_string(cmd_obj->mount[i], json_array_get(mount_info, i)) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mount[%d] get failed!\n", i);
        }
    }

    image_info = json_object_get(obj, "image");
    if (image_info == NULL) {
        return VOS_ERR;
    }

    if (sg_get_file(image_info, &cmd_obj->image) != VOS_OK) {
        return VOS_ERR;
    }

    withAPP_info = json_object_get(obj, "withAPP");
    if (withAPP_info == NULL) {
        return VOS_ERR;
    }

    if (sg_get_with_app(withAPP_info, &cmd_obj->withAPP) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
// ������װ���� 
int sg_unpack_container_install_cmd(json_t *obj, container_install_cmd_s *cmd_obj)
{
    size_t i = 0;
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;
    json_t *cfgDisk_info = NULL;
    json_t *dev_info = NULL;

    if (sg_get_container_info(obj, cmd_obj) != VOS_OK) {
        return VOS_ERR;
    }

    dev_info = json_object_get(obj, "dev");
    if (dev_info == NULL) {
        return VOS_ERR;
    }
    cmd_obj->dev_len = json_array_size(dev_info);
    for (i = 0; i < cmd_obj->dev_len; i++) {
        if (json_into_array_string(cmd_obj->dev[i], json_array_get(dev_info, i)) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "dev[%d] get failed!\n", i);
        }
    }
    cfgCpu_info = json_object_get(obj, "cfgCpu");
    if (cfgCpu_info == NULL) {
        return VOS_ERR;
    }
    if (sg_get_cfgcpu(cfgCpu_info, &cmd_obj->cfgCpu) != VOS_OK) {
        return VOS_ERR;
    }

    cfgMem_info = json_object_get(obj, "cfgMem");
    if (cfgMem_info == NULL) {
        return VOS_ERR;
    }
    if (sg_get_cfgmem(cfgMem_info, &cmd_obj->cfgMem) != VOS_OK) {
        return VOS_ERR;
    }

    cfgDisk_info = json_object_get(obj, "cfgDisk");
    if (cfgDisk_info == NULL) {
        return VOS_ERR;
    }
    if (sg_get_cfgdisk(cfgDisk_info, &cmd_obj->cfgDisk) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

// ������װ��������Ӧ�� ��param
int sg_pack_container_install_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;
    mssm = sg_pack_json_msg_header(code, mid, CMD_CON_INSTALL, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_install_cmd: msg failed!\n");
    }
    free(mssm); 
    return VOS_OK;
}
/*****************************************************************************
�� �� ��  : sg_unpack_container_control_cmd
��������  : �������� (����������ֹͣ��ɾ��)
�������  : json_t *obj
�������  : *msg
�� �� ֵ  :
���ú���  :
��������  :
*****************************************************************************/
int sg_unpack_container_control_cmd(json_t *obj, char *msg)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    if (json_into_string(msg, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

// ������������Ӧ�� �������� ֹͣ ɾ��
int sg_pack_container_control_reply(container_reply_info_s *container_reply_info, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(container_reply_info->code, container_reply_info->mid,
                                   container_reply_info->type, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_control_reply: msg failed!\n");
    }
    free(mssm); 
    return VOS_OK;
}

// ���������޸�����
int sg_unpack_container_param_set_cmd(json_t *obj, container_conf_cmd_s *cmd_obj)
{
    size_t i = 0;
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;
    json_t *cfgDisk_info = NULL;
    json_t *mount_info = NULL;
    json_t *dev_info = NULL;
    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->port, obj, "port") != VOS_OK) {
        return VOS_ERR;
    }

    cfgCpu_info = json_object_get(obj, "cfgCpu");
    if (sg_get_cfgcpu(cfgCpu_info, &cmd_obj->cfgCpu) != VOS_OK) {
        return VOS_ERR;
    }

    cfgMem_info = json_object_get(obj, "cfgMem");
    if (sg_get_cfgmem(cfgMem_info, &cmd_obj->cfgMem) != VOS_OK) {
        return VOS_ERR;
    }

    cfgDisk_info = json_object_get(obj, "cfgDisk");
    if (sg_get_cfgdisk(cfgDisk_info, &cmd_obj->cfgDisk) != VOS_OK) {
        return VOS_ERR;
    }

    mount_info = json_object_get(obj, "mount");
    if (mount_info == NULL) {
        return VOS_ERR;
    }
    cmd_obj->mount_len = json_array_size(mount_info);
    for (i = 0; i < cmd_obj->mount_len; i++) {
        (void)json_into_array_string(cmd_obj->mount[i], json_array_get(mount_info, i));
    }

    dev_info = json_object_get(obj, "dev");
    if (dev_info == NULL) {
        return VOS_ERR;
    }
    cmd_obj->dev_len = json_array_size(dev_info);
    for (i = 0; i < cmd_obj->dev_len; i++) {
        (void)json_into_array_string(cmd_obj->dev[i], json_array_get(dev_info, i));
    }
    return VOS_OK;
}

// ���������޸�Ӧ�� ��param
int sg_pack_container_param_set_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_CON_SET_CONFIG, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_param_set_reply: msg failed!\n");
    }
    free(mssm); 
    return VOS_OK;
}

static void sg_set_mount(json_t *mountsobj_s, container_conf_cmd_s *infobj)
{
    uint16_t t = 0;
    json_t *mountobj_s = NULL;

    if (mountsobj_s == NULL) {
        return;
    }
    for (t = 0; t < infobj->mount_len; t++) {
        mountobj_s = json_object();
        if (mountobj_s == NULL) {
            return;
        }
        mountobj_s = json_string(infobj->mount[t]);
        (void)json_array_append_new(mountsobj_s, mountobj_s);
    }
}

static void sg_set_dev(json_t *devsobj_s, container_conf_cmd_s *infobj)
{
    uint16_t t = 0;
    json_t *devobj_s = NULL;

    if (devsobj_s == NULL) {
        return;
    }
    for (t = 0; t < infobj->dev_len; t++) {
        devobj_s = json_object();
        if (devobj_s == NULL) {
            return;
        }
        devobj_s = json_string(infobj->dev[t]);
        (void)json_array_append_new(devsobj_s, devobj_s);
    }
}
// ��container_conf_cmd_s��֡Ϊjson_t
static int sg_pack_container_conf_cmd_s(json_t *contPara_obj, container_conf_cmd_s *contPara)
{
    int ret            = VOS_OK;
    json_t *cfgCpuobj  = NULL;
    json_t *cfgMemobj  = NULL;
    json_t *cfgDiskobj = NULL;
    json_t *mountobj   = NULL;
    json_t *devobj     = NULL;

    cfgCpuobj = json_object();
    cfgMemobj = json_object();
    cfgDiskobj = json_object();
    mountobj = json_array();
    devobj = json_array();
    (void)json_object_set_new(contPara_obj, "container", json_string(contPara->container));
    if (strlen(contPara->port) == 0) {
        ret = VOS_ERR;
    }
    (void)json_object_set_new(contPara_obj, "port", json_string(contPara->port));
    if (cfgCpuobj == NULL) {
        ret = VOS_ERR;
    }
    (void)json_object_set_new(cfgCpuobj, "cpus", json_integer(contPara->cfgCpu.cpus));
    (void)json_object_set_new(cfgCpuobj, "cpuLmt", json_integer(contPara->cfgCpu.cpuLmt));
    (void)json_object_set_new(contPara_obj, "cfgCpu", cfgCpuobj);
    if (cfgMemobj == NULL) {
        ret = VOS_ERR;
    }
    (void)json_object_set_new(cfgMemobj, "memory", json_integer(contPara->cfgMem.memory));
    (void)json_object_set_new(cfgMemobj, "memLmt", json_integer(contPara->cfgMem.memLmt));
    (void)json_object_set_new(contPara_obj, "cfgMem", cfgMemobj);

    if (cfgDiskobj == NULL) {
        ret = VOS_ERR;
    }
    (void)json_object_set_new(cfgDiskobj, "disk", json_integer(contPara->cfgDisk.disk));
    (void)json_object_set_new(cfgDiskobj, "diskLmt", json_integer(contPara->cfgDisk.diskLmt));
    (void)json_object_set_new(contPara_obj, "cfgDisk", cfgDiskobj);
    sg_set_mount(mountobj, contPara);
    (void)json_object_set_new(contPara_obj, "mount", mountobj);
    sg_set_dev(devobj, contPara);
    (void)json_object_set_new(contPara_obj, "dev", devobj);
    return ret;
}

// ��������״̬��ѯӦ��
void sg_pack_container_param_get_reply(uint16_t code, int32_t mid, const char *error_msg,
        container_config_reply_s *statusobj, char *msg)
{
    int i = 0;
    json_t *param = NULL;
    json_t *contPara_obj = NULL;
    json_t *contParas_obj = NULL;

    param = json_object();
    contParas_obj = json_array();
    if (contParas_obj == NULL) {
        return;
    }
    for (i = 0; i < statusobj->contPara_len; i++) {
        contPara_obj = json_object();
        if (contPara_obj == NULL) {
            continue;
        }
        if (sg_pack_container_conf_cmd_s(contPara_obj, &statusobj->contPara[i]) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_conf_cmd_s failed!\n");
        }
    }
    (void)json_array_append_new(contParas_obj, contPara_obj);
    (void)json_object_set_new(param, "contPara", contParas_obj);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_GET_CONFIG, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_param_get_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }
    if (param != NULL) {
        json_decref(param);
    }
}

// ����״̬��ѯӦ��  ����״̬�ϱ�
void sg_pack_container_status_get_reply(char *type, uint16_t code, int32_t mid,
    const char *error_msg, container_status_reply_s *statusobj, char *msg)
{
    int num         = 0;
    char *mssm      = NULL;
    json_t *param   = NULL;
    json_t *params  = NULL;

    if (statusobj == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "statusobj = NULL!\n");
    } else {
        params = json_array();
        for (num = 0; num < statusobj->contPara_len; num++) {
            param = json_object();
            (void)json_object_set_new(param, "container", json_string(statusobj->contPara[num].container));
            (void)json_object_set_new(param, "version", json_string(statusobj->contPara[num].version));
            (void)json_object_set_new(param, "state", json_string(statusobj->contPara[num].state));
            (void)json_object_set_new(param, "cpuRate", json_integer(statusobj->contPara[num].cpuRate));
            (void)json_object_set_new(param, "memUsed", json_integer(statusobj->contPara[num].memUsed));
            (void)json_object_set_new(param, "diskUsed", json_integer(statusobj->contPara[num].diskUsed));
            (void)json_object_set_new(param, "ip", json_string(statusobj->contPara[num].ip));
            (void)json_object_set_new(param, "created", json_string(statusobj->contPara[num].created));
            (void)json_object_set_new(param, "started", json_string(statusobj->contPara[num].started));
            (void)json_object_set_new(param, "lifeTime", json_integer(statusobj->contPara[num].lifeTime));
            (void)json_object_set_new(param, "image", json_string(statusobj->contPara[num].image));
            (void)json_array_append_new(params, param);
        }
    }

    mssm = sg_pack_json_msg_header(code, mid, type, error_msg, params);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_status_get_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}

// �����¼��ϱ�
void sg_pack_container_event_pack(uint16_t code, int32_t mid, const char *error_msg, 
        container_event_report_s *statusobj, char *msg)
{
    json_t *param = NULL;

    param = json_object();
    (void)json_object_set_new(param, "container", json_string(statusobj->container));
    (void)json_object_set_new(param, "event", json_string(statusobj->event));
    if (strlen(statusobj->msg) != 0) {
        (void)json_object_set_new(param, "msg", json_string(statusobj->msg));
    }

    char *mssm = sg_pack_json_msg_header(code, mid, EVENT_CON_ALARM, NULL, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_event_pack: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}
// ������������
int sg_unpack_container_upgrade_cmd(json_t *obj, container_upgrade_cmd_s *cmd_obj)
{
    json_t* file_info = NULL;

    if (json_into_int32_t(&cmd_obj->jobId, obj, "jobId") != VOS_OK) {
        return VOS_ERR;
    }

    (void)json_into_uint32_t(&cmd_obj->policy, obj, "policy");
    if (json_into_string(cmd_obj->version, obj, "version") != VOS_OK) {
        return VOS_ERR;
    }

    file_info = json_object_get(obj, "file");
    if (sg_get_file(file_info, &cmd_obj->file) != VOS_OK) {
        return VOS_ERR;
    }

    return VOS_OK;
}
// ������������Ӧ��
int sg_pack_container_upgrade_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_CON_UPGRADE, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_upgrade_reply: msg failed!\n");
    }
    free(mssm); 
    return VOS_OK;
}

// ������־�ٻ�����
int sg_unpack_container_log_get_cmd(json_t *obj, container_log_recall_cmd_s *cmd_obj)
{
    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "container get fail!\n");
    }
    if (json_into_string(cmd_obj->url, obj, "url") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
// ������־�ٻ�Ӧ��
void sg_pack_container_log_get_reply(uint16_t code, int32_t mid, const char *error_msg, file_info_s *file, char *msg)
{
    json_t *param = NULL;
    json_t *sign_object = NULL;

    param = json_object();
    sign_object = json_object();
    if (sign_object != NULL) {
        (void)json_object_set_new(sign_object, "name", json_string(file->sign.name));
        if (file->sign.size != 0) {
            (void)json_object_set_new(sign_object, "size", json_integer(file->sign.size));
        }

        if (strlen(file->sign.url) != 0) {
            (void)json_object_set_new(sign_object, "url", json_string(file->sign.url));
        }

        if (strlen(file->sign.md5) != 0) {
            (void)json_object_set_new(sign_object, "md5", json_string(file->sign.md5));
        }
    }

    (void)json_object_set_new(param, "name", json_string(file->name));
    if (strlen(file->url) != 0) {
        (void)json_object_set_new(param, "url", json_string(file->url));
    }

    if (strlen(file->fileType) != 0) {
        (void)json_object_set_new(param, "fileType", json_string(file->fileType));
    }

    (void)json_object_set_new(param, "size", json_integer(file->size));
    (void)json_object_set_new(param, "md5", json_string(file->md5));
    (void)json_object_set_new(param, "sign", sign_object);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_CON_LOG, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_log_get_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }
    
    if (param != NULL) {
        json_decref(param);
    }
}

