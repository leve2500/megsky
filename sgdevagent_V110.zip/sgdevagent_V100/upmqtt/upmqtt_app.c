#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"

#include "sgdev_struct.h"
#include "sgdev_param.h"
#include "sgdev_debug.h"
#include "upmqtt_json.h"
#include "upmqtt_app.h"
#include "app_management_service_api.h"
#include "task_app.h"

// Ӧ�ð�װ��������
int sg_unpack_app_install_cmd(json_t *obj, app_install_cmd_s *cmd_obj)
{
    json_t *file_info = NULL;
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;

    if (json_into_int32_t(&cmd_obj->jobId, obj, "jobId") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "jobId get fail!\n");
        return VOS_ERR;
    }

    if (json_into_uint32_t(&cmd_obj->policy, obj, "policy") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "policy get fail!\n");
    }

    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "container get fail!\n");
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->version, obj, "version") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "version get fail!\n");
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->enable, obj, "enable") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "enable get fail!\n");
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->app, obj, "app") != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "app get fail!\n");
        return VOS_ERR;
    }

    file_info = json_object_get(obj, "file");
    if (sg_get_file(file_info, &cmd_obj->file) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "file get fail!\n");
        return VOS_ERR;
    }

    cfgCpu_info = json_object_get(obj, "cfgCpu");
    if (sg_get_cfgcpu(cfgCpu_info, &cmd_obj->cfgCpu) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "cfgCpu get fail!\n");
    }

    cfgMem_info = json_object_get(obj, "cfgMem");
    if (sg_get_cfgmem(cfgMem_info, &cmd_obj->cfgMem) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "cfgMem get fail!\n");
    }
    return VOS_OK;
}

// Ӧ�ð�װ��������Ӧ��
int sg_pack_app_install_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_APP_INSTALL, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_install_cmd: msg failed!\n");
    }
    free(mssm); 
    return VOS_OK;
}

// Ӧ�ÿ������� ���� ֹͣ ж�� ʹ�� ȥʹ�� �ϳ�һ��
int sg_unpack_app_control_cmd(json_t *obj, app_control_cmd_s *cmd_obj)
{
    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->app, obj, "app") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
// Ӧ�ÿ���Ӧ�� �������� ֹͣ ж�� ʹ�� ȥʹ�� �ϳ�һ��
int sg_pack_app_control_reply(app_reply_info_s *app_reply_info, const char *error_msg, char *msg)
{
    char *mssm = NULL;
    mssm = sg_pack_json_msg_header(app_reply_info->code, app_reply_info->mid, app_reply_info->type, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_control_reply: msg failed!\n");
    }
    free(mssm);
    return VOS_OK;
}

// Ӧ�������޸�����
int sg_unpack_app_param_set_cmd(json_t *obj, app_conf_cmd_s *cmd_obj)
{
    json_t *cfgCpu_info = NULL;
    json_t *cfgMem_info = NULL;
    
    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->app, obj, "app") != VOS_OK) {
        return VOS_ERR;
    }

    cfgCpu_info = json_object_get(obj, "cfgCpu");
    if (json_is_object(cfgCpu_info)) {
        if (json_into_int32_t(&cmd_obj->cfgCpu.cpus, cfgCpu_info, "cpus") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_int32_t(&cmd_obj->cfgCpu.cpuLmt, cfgCpu_info, "cpuLmt") != VOS_OK) {
            return VOS_ERR;
        }
    }

    cfgMem_info = json_object_get(obj, "cfgMem");
    if (json_is_object(cfgMem_info)) {
        if (json_into_int32_t(&cmd_obj->cfgMem.memory, cfgMem_info, "memory") != VOS_OK) {
            return VOS_ERR;
        }
        if (json_into_int32_t(&cmd_obj->cfgMem.memLmt, cfgMem_info, "memLmt") != VOS_OK) {
            return VOS_ERR;
        }
    }

    return VOS_OK;
}
// Ӧ�������޸�Ӧ�� ��param
int sg_pack_app_param_set_reply(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_APP_SET_CONFIG, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_param_set_reply: msg failed!\n");
    }
    free(mssm);
    return VOS_OK;
}

// Ӧ������״̬��ѯ����
int sg_unpack_app_param_get(json_t *obj, char *msg)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    if (json_into_string(msg, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

// Ӧ�����ò�ѯӦ��
void sg_pack_app_param_get_reply(uint16_t code, int32_t mid, const char *error_msg,
        app_conf_reply_s *statusobj, char *msg)
{
    int i = 0;
    json_t *param = NULL;
    json_t *app_cfgs_obj = NULL;
    json_t *app_cfgs_objs = NULL;
    json_t *cfg_cpu_obj = NULL;
    json_t *cfg_mem_obj = NULL;

    param = json_object();
    app_cfgs_objs = json_array();
    if (app_cfgs_objs == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_param_get_reply: app_cfgs_objs is null\n");
    }
    for (i = 0; i < statusobj->app_num; i++) {
        app_cfgs_obj = json_object();
        cfg_cpu_obj = json_object();
        cfg_mem_obj = json_object();
        if (app_cfgs_obj != NULL) {
            (void)json_object_set_new(app_cfgs_obj, "app", json_string(statusobj->appCfgs[i].app));
            if (cfg_cpu_obj != NULL) {
                (void)json_object_set_new(cfg_cpu_obj, "cpus", json_integer(statusobj->appCfgs[i].cfgCpu.cpus));
                (void)json_object_set_new(cfg_cpu_obj, "cpuLmt", json_integer(statusobj->appCfgs[i].cfgCpu.cpuLmt));
            }
            (void)json_object_set_new(app_cfgs_obj, "cfgCpu", cfg_cpu_obj);
            if (cfg_mem_obj != NULL) {
                (void)json_object_set_new(cfg_mem_obj, "memory", json_integer(statusobj->appCfgs[i].cfgMem.memory));
                (void)json_object_set_new(cfg_mem_obj, "memLmt", json_integer(statusobj->appCfgs[i].cfgMem.memLmt));
            }
            (void)json_object_set_new(app_cfgs_obj, "cfgMem", cfg_mem_obj);
            (void)json_array_append_new(app_cfgs_objs, app_cfgs_obj);
        }
    }
    (void)json_object_set_new(param, "container", json_string(statusobj->container));
    (void)json_object_set_new(param, "appCfgs", app_cfgs_objs);
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_GET_CONFIG, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_param_get_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}

// Ӧ��״̬��ѯ����
int sg_unpack_app_status_get(json_t *obj, char *msg)
{
    if (obj == NULL) {
        return VOS_ERR;
    }

    if (json_into_string(msg, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}

// ��ȡapps�ṹ�������е�process�ṹ����������
static void sg_get_process(json_t *appsobj_s, process_info_s *infobj, uint32_t process_num)
{
    uint16_t t = 0;
    json_t *appsobj = NULL;

    if (infobj == NULL) {
        return;
    }
    if (appsobj_s != NULL) {
        for (t = 0; t < process_num; t++) {
            appsobj = json_object();
            if (appsobj != NULL) {
                (void)json_object_set_new(appsobj, "srvIndex", json_integer(infobj[t].srvIndex));
                (void)json_object_set_new(appsobj, "srvName", json_string(infobj[t].srvName));
                (void)json_object_set_new(appsobj, "srvEnable", json_string(infobj[t].srvEnable));
                (void)json_object_set_new(appsobj, "srvStatus", json_string(infobj[t].srvStatus));
                (void)json_object_set_new(appsobj, "cpuLmt", json_integer(infobj[t].cpuLmt));
                (void)json_object_set_new(appsobj, "cpuRate", json_integer(infobj[t].cpuRate));
                (void)json_object_set_new(appsobj, "memLmt", json_integer(infobj[t].memLmt));
                (void)json_object_set_new(appsobj, "memUsed", json_integer(infobj[t].memUsed));
                (void)json_object_set_new(appsobj, "startTime", json_string(infobj[t].startTime));
                (void)json_array_append_new(appsobj_s, appsobj);
            }
        }
    }
}
// Ӧ��״̬��ѯӦ�� Ӧ��״̬�ϱ�
void sg_pack_app_status_get_reply(char *type, uint16_t code, int32_t mid, const char *error_msg,
        app_inq_reply_s *statusobj, char *msg)
{
    int i = 0;
    int len = 0;
    json_t *param = NULL;
    json_t *app_obj = NULL;
    json_t *app_objs = NULL;
    json_t *get_process_objs = NULL;

    param = json_object();
    app_objs = json_array();
    if (app_objs != NULL) {
        len = statusobj->apps_num;
        for (i = 0; i < len; i++) {
            app_obj = json_object();
            get_process_objs = json_array();
            if (app_obj != NULL) {
                (void)json_object_set_new(app_obj, "app", json_string(statusobj->apps[i].app));
                (void)json_object_set_new(app_obj, "version", json_string(statusobj->apps[i].version));
                (void)json_object_set_new(app_obj, "appHash", json_string(statusobj->apps[i].appHash));
                (void)json_object_set_new(app_obj, "srvNumber", json_integer(statusobj->apps[i].srvNumber));
                sg_get_process(get_process_objs, statusobj->apps[i].process, statusobj->apps[i].srvNumber);
                (void)json_object_set_new(app_obj, "process", get_process_objs);
                (void)json_array_append_new(app_objs, app_obj);
            }
        }
    }

    (void)json_object_set_new(param, "container", json_string(statusobj->container));
    (void)json_object_set_new(param, "apps", app_objs);
    char *mssm = sg_pack_json_msg_header(code, mid, type, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_status_get_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}

// Ӧ���¼��ϱ�
void sg_pack_app_event_pack(uint16_t code, int32_t mid, const char *error_msg, app_event_reply_s *statusobj, char *msg)
{
    char *mssm = NULL;
    json_t *param = NULL;

    param = json_object();
    (void)json_object_set_new(param, "container", json_string(statusobj->container));
    if (strlen(statusobj->app) != 0) {
        (void)json_object_set_new(param, "app", json_string(statusobj->app));
    }

    (void)json_object_set_new(param, "event", json_string(statusobj->event));
    if (strlen(statusobj->msg) != 0) {
        (void)json_object_set_new(param, "msg", json_string(statusobj->msg));
    }

    mssm = sg_pack_json_msg_header(code, mid, EVENT_APP_ALARM, NULL, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_event_pack: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}
// Ӧ����������
int sg_unpack_app_upgrade_cmd(json_t *obj, app_upgrade_cmd_s *cmd_obj)
{
    json_t* file_info = NULL;
    if (json_into_int32_t(&cmd_obj->jobId, obj, "jobId") != VOS_OK) {
        return VOS_ERR;
    }

    (void)json_into_uint32_t(&cmd_obj->policy, obj, "policy");
    if (json_into_string(cmd_obj->version, obj, "version") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }

    file_info = json_object_get(obj, "file");
    if (sg_get_file(file_info, &cmd_obj->file) != VOS_OK) {
        return VOS_ERR;
    }
    return VOS_OK;
}
// Ӧ����������Ӧ�� ��param
int sg_pack_app_upgrade_cmd(uint16_t code, int32_t mid, const char *error_msg, char *msg)
{
    char *mssm = NULL;

    mssm = sg_pack_json_msg_header(code, mid, CMD_APP_UPGRADE, error_msg, NULL);
    if (mssm == NULL) {
        return VOS_ERR;
    }

    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_upgrade_cmd: msg failed!\n");
    }
    free(mssm);
    return VOS_OK;
}
// Ӧ����־�ٻ�����
int sg_unpack_app_log_get_cmd(json_t *obj, app_log_recall_cmd_s *cmd_obj)
{
    if (json_into_string(cmd_obj->container, obj, "container") != VOS_OK) {
        return VOS_ERR;
    }

    if (json_into_string(cmd_obj->url, obj, "url") != VOS_OK) {
        return VOS_ERR;
    }

    (void)json_into_string(cmd_obj->app, obj, "app");
    return VOS_OK;
}
// Ӧ����־�ٻ�Ӧ��
void sg_pack_app_log_get_reply(uint16_t code, int32_t mid, const char *error_msg, file_info_s *file, char *msg)
{
    json_t *sign_object = NULL;
    json_t *param = NULL;
    sign_object = json_object();
    param = json_object();

    if (sign_object != NULL) {
        (void)json_object_set_new(sign_object, "name", json_string(file->sign.name));
        if (strlen(file->sign.url) != 0) {
            (void)json_object_set_new(sign_object, "url", json_string(file->sign.url));
        }

        if (file->sign.size != 0) {
            (void)json_object_set_new(sign_object, "size", json_integer(file->sign.size));
        }

        if (strlen(file->sign.md5) != 0) {
            (void)json_object_set_new(sign_object, "md5", json_string(file->sign.md5));
        }
    }

    (void)json_object_set_new(param, "name", json_string(file->name));
    if (strlen(file->fileType) != 0) {
        (void)json_object_set_new(param, "fileType", json_string(file->fileType));
    }

    if (strlen(file->url) != 0) {
        (void)json_object_set_new(param, "url", json_string(file->url));
    }

    (void)json_object_set_new(param, "sign", sign_object);
    (void)json_object_set_new(param, "size", json_integer(file->size));
    (void)json_object_set_new(param, "md5", json_string(file->md5));
    char *mssm = sg_pack_json_msg_header(code, mid, CMD_APP_LOG, error_msg, param);
    if (memcpy_s(msg, MSG_ARRVD_MAX_LEN, mssm, strlen(mssm) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_app_log_get_reply: msg failed!\n");
    }
    if (mssm != NULL) {
        free(mssm);
    }

    if (param != NULL) {
        json_decref(param);
    }
}

