/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent queue header file
*/

#ifndef __SGDEV_QUEUE_H__
#define __SGDEV_QUEUE_H__

#include "sgdev_struct.h"

#ifdef __cplusplus
extern "C" {
#endif

#define QUEUE_DEPTH_LEN (512)
#define QUEUE_UNPACK_NAME "unpa"
#define QUEUE_PACK_NAME "pack"
#define QUEUE_DEV_NAME "pdev"
#define QUEUE_CONTAINER_NAME "pcon"
#define QUEUE_APP_NAME "papp"
#define QUEUE_RESULT_NAME "prel"
#define MSG_ORDER_NUM_ZERO (0)
#define MSG_ORDER_NUM_FIRST (1)
#define MSG_ORDER_NUM_SECOND (2)
#define MSG_ORDER_NUM_THIRD (3)

// ��������
void sg_que_unpack_create(void);
void sg_que_pack_create(void);
void sg_que_task_create(void);
void sg_que_result_create(void);

// ɾ������
void sg_que_unpack_destroy(void);
void sg_que_pack_destroy(void);
void sg_que_task_destroy(void);
void sg_que_result_destroy(void);

uint32_t sg_get_que_pack_id(void);
uint32_t sg_get_que_unpack_id(void);
uint32_t sg_get_que_dev_id(void);
uint32_t sg_get_que_container_id(void);
uint32_t sg_get_que_app_id(void);

void sg_push_pack_item(mqtt_data_info_s *item);
void sg_push_unpack_item(mqtt_data_info_s *item);
void sg_push_dev_item(uint32_t type, int32_t mid, char *param);
void sg_push_container_item(uint32_t type, int32_t mid, char *param);
void sg_push_app_item(uint32_t type, int32_t mid, char *param);

#ifdef __cplusplus
}
#endif

#endif
