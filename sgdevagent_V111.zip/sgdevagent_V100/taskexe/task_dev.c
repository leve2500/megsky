#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include "ssp_mid.h"
#include "vm_public.h"
#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"

#include "vm_public.h"
#include "vm_rpc_api.h"
#include "sysman_rpc_api.h"
#include "app_management_service_api.h"
#include "securec.h"
#include <glib-object.h>
#include <thrift/c_glib/thrift.h>

#include "upmqtt_json.h"
#include "upmqtt_dev.h"
#include "sgdev_queue.h"
#include "sgdev_param.h"
#include "sgdev_curl.h"
#include "sgdev_struct.h"
#include "sgdev_debug.h"
#include "sgdev_debug.h"
#include "thread_interact.h"
#include "task_link.h"
#include "timer_pack.h"
#include "task_dev.h"

int sg_dev_install(device_upgrade_s *cmd_obj, char *errmsg)
{
    int ret = VOS_OK;
    dev_status_reply_s status = { 0 };
    status.state = STATUS_EXE_INSTALL;
    (void)set_device_upgrade_status(status);
    if (cmd_obj->upgradeType == UPGRADEPACH) {    // �жϲ�������
        ret = VOS_OK;   // �����
    } else if (cmd_obj->upgradeType == UPGRADEHOST) {
        ret = VOS_OK;   // �����
    }
    return ret;
}
// ��ȡCPU���� �ڴ�ʹ����Ϣ ����ռ����
int sg_devusage_status_call_get_threshold(dev_usage_status_s *dev_status, int *storage_usage_out)
{
    int ret = VOS_OK;
    uint32_t infoNum = 0;
    uint32_t num = 0;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX]  = { 0 };
    container_install_dir_info container_install_dir;
    (void)memset_s(&container_install_dir, sizeof(container_install_dir_info), 0, sizeof(container_install_dir_info));
    storageusage_s *storage_usage_in = NULL;

    storage_usage_in = (storageusage_s*)VOS_Malloc(MID_SGDEV, sizeof(storageusage_s) * STORAGE_PARTITION_MAX_NUM);
    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_devusage_status_call_get_threshold:rpc_transport_open error\n");
        ret = VOS_ERR;
    }

    ret = cpuusage_status_call_get_threshold(&dev_status->cpuoutput_value, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "cpuusage_status_call_get_threshold error\n");
    }

    ret = memoryusage_status_call_get_threshold(&dev_status->memoutput_value, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "memoryusage_status_call_get_threshold error\n");
    } else {
        ret = storageusage_status_call_get_threshold(&infoNum, storage_usage_in, errmsg, SYSMAN_RPC_ERRMSG_MAX);
        if (ret != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "storageusage_status_call_get_threshold error\n");
        }
    }
    sysman_rpc_transport_close();

    if (vm_rpc_get_install_dir_info(&container_install_dir, errmsg, SYSMAN_RPC_ERRMSG_MAX) != true) { // ��ȡ��ǰ����·��
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "vm_rpc_get_install_dir_info error!\n");
        ret = VOS_ERR;
    }

    for (num = 0; num < infoNum; num++) {
        if (0 == strncmp(storage_usage_in[num].path, container_install_dir.current_dir.dir_path,
            strlen(container_install_dir.current_dir.dir_path))) {
            *storage_usage_out = storage_usage_in[num].usage;
            break;
        } else {
            *storage_usage_out = 100;
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get_storageoutput_usage_value_fail\n");
        }
    }
    (void)VOS_Free(storage_usage_in);
    storage_usage_in = NULL;
    return ret;
}

// ��ȡ��γ��
int sg_devusage_status_call_get_location(dev_sta_reply_s *dev_sta_rep_item)
{
    int ret                             = VOS_OK;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX]  = { 0 };
    GNSS_CMD_LOCATION_S gnss_location   = { 0 };

    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_devusage_status_call_get_location:rpc_transport_open error\n");
        ret = VOS_ERR;
    }

    ret = gnss_status_call_get_gnss_location(&gnss_location, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "gnss_status_call_get_gnss_location error\n");
    }
    sysman_rpc_transport_close();

    if (sprintf_s(dev_sta_rep_item->longitude, DATA_BUF_F64_SIZE, "%.5f", gnss_location.longitude) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "dev_sta_rep_item.longitude get error!\n");
    }

    if (sprintf_s(dev_sta_rep_item->latitude, DATA_BUF_F64_SIZE, "%.5f", gnss_location.latitude) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "dev_sta_rep_item.latitude get error!\n");
    }

    return ret;
}
// �豸״̬����ϱ�
void sg_dev_status_result_reply(dev_reply_info_s *dev_reply_item, dev_sta_reply_s *dev_sta_rep_item, char *errormsg)
{
    mqtt_data_info_s *item = NULL;

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_dev_status_result_reply:item is NULL!\n");
        return;
    }
    
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error!\n");
    }

    sg_pack_dev_run_status(dev_reply_item, dev_sta_rep_item, errormsg, item->msg_send);
    sg_push_pack_item(item);
}

// �豸��Ϣ����ϱ�
void sg_dev_info_result_reply(uint16_t code, int32_t mid, dev_info_inq_reply_s *dev_info_inq_item, char *errormsg)
{
    mqtt_data_info_s *item = NULL;

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_dev_info_result_reply item malloc failed!\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s topic_device_reply failed!\n");
    }

    if (sg_pack_dev_info_reply(code, mid, errormsg, dev_info_inq_item, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_dev_info_reply failed!\n");
    }

    sg_push_pack_item(item);
}

// ����cpu�����ֵ
int sg_set_cpu_usage_threshold(dev_man_conf_command_s *paraobj)
{
    int ret                            = VOS_OK;
    int cpu_alert                      = 0;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };

    if (sg_get_devusage_threshold(&cpu_alert, CPU_USAGE) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_CPU_USAGE_threshold error!\n");
        ret = VOS_ERR;
    }

    if (paraobj->cpuLmt >= SG_HW_LIMIT_U50_VALUE && paraobj->cpuLmt <= (cpu_alert - 1)) {
        if (sysman_rpc_transport_open() != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
            return VOS_ERR;
        }

        if (cpuusage_config_call_set_threshold(paraobj->cpuLmt, errmsg, SYSMAN_RPC_ERRMSG_MAX) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "cpuusage_config_call_set_threshold error!\n");
            ret = VOS_ERR;
        }
        sysman_rpc_transport_close();
    } else {
        return VOS_ERR;
    }

    return ret;
}

// ����mem�����ֵ
int sg_set_mem_usage_threshold(dev_man_conf_command_s *paraobj)
{
    int ret                            = VOS_OK;
    int mem_alert                      = 0;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };

    if (sg_get_devusage_threshold(&mem_alert, MEM_USAGE) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_MEM_USAGE_threshold error!\n");
        ret = VOS_ERR;
    }
    if (paraobj->memLmt >= SG_HW_LIMIT_U50_VALUE && paraobj->memLmt <= (mem_alert - 1)) {
        if (sysman_rpc_transport_open() != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
            return VOS_ERR;
        }
        if (memoryusage_config_call_set_threshold(paraobj->memLmt, errmsg, SYSMAN_RPC_ERRMSG_MAX) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "memoryusage_config_call_set_threshold error!\n");
            ret = VOS_ERR;
        }

        sysman_rpc_transport_close();
    }
    return ret;
}

// ���ô��̼����ֵ
int sg_set_disk_usage_threshold(dev_man_conf_command_s *paraobj)
{
    int ret = VOS_OK;
    int disk_alert = 0;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };

    if (sg_get_devusage_threshold(&disk_alert, STORAGE_USAGE) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_STORAGE_USAGE_threshold error!\n");
        ret = VOS_ERR;
    }
    if (paraobj->diskLmt >= SG_HW_LIMIT_U50_VALUE && paraobj->diskLmt <= (disk_alert - 1)) {
        if (sysman_rpc_transport_open() != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
            return VOS_ERR;
        }
        if (storageusage_config_call_set_threshold(paraobj->diskLmt, errmsg, SYSMAN_RPC_ERRMSG_MAX) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "storageusage_config_call_set_threshold error!\n");
            ret = VOS_ERR;
        }

        sysman_rpc_transport_close();
    }
    return ret;
}

// �����¶ȼ����Ϣ
int sg_set_temperature_threshold(dev_man_conf_command_s *paraobj)
{
    int ret                                            = VOS_OK;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX]                 = { 0 };
    temperature_threshold_config_s *temp_threshold_set = NULL;

    temp_threshold_set = (temperature_threshold_config_s*)VOS_Malloc(MID_SGDEV, sizeof(temperature_threshold_config_s) *
            STORAGE_PARTITION_MAX_NUM);
    if (temp_threshold_set == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "temp_threshold_set = NULL\n");
        return VOS_ERR;
    }

    (void)memset_s(temp_threshold_set, sizeof(temperature_threshold_config_s) *
            STORAGE_PARTITION_MAX_NUM, 0, sizeof(temperature_threshold_config_s) * STORAGE_PARTITION_MAX_NUM);
    if (memcpy_s(temp_threshold_set->moduleName, TEMP_NAME_LEN, TEMPERATURE_MODULE_NAME_MAINBOARD,
        strlen(TEMPERATURE_MODULE_NAME_MAINBOARD) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_log_get_cmd: moduleName failed!\n");
    }

    temp_threshold_set->temType = TEMP_MONITOR_TEMP_ALL;
    temp_threshold_set->temLow = paraobj->temperature.temLow;
    temp_threshold_set->temHigh = paraobj->temperature.temHigh;
    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        return VOS_ERR;
    }

    if (temperature_config_call_set_monitor_threshold(temp_threshold_set,
        errmsg, SYSMAN_RPC_ERRMSG_MAX) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "temperature_config_call_set_monitor_threshold error!\n");
        ret = VOS_ERR;
    }

    sysman_rpc_transport_close();
    (void)VOS_Free(temp_threshold_set);
    temp_threshold_set = NULL;
    return ret;
}

int sg_device_copy_all(dev_sta_reply_s *dev_sta_rep_item, dev_usage_status_s *devusage, char *errormsg)
{
    int ret = VOS_OK;
    char timestamp[DATA_BUF_F32_SIZE] = { 0 };
    time_t now_time = time(NULL);
    long run_ltime = 0;
    if (errormsg == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_device_copy_all:errormsg is null.\n");
        return VOS_ERR;
    }
    dev_sta_rep_item->cpuRate = devusage->cpuoutput_value.usage;
    dev_sta_rep_item->mem_used.phy = devusage->memoutput_value.usage;                 // �����ڴ�
    dev_sta_rep_item->mem_used.virt = (int32_t)sg_memvirt_used();                             // �����ڴ�

    ret = sg_mqtt_time_str(now_time, timestamp, sizeof(timestamp), TIME_UTC);               // ʹ��UTCʱ��
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_device_copy_all sg_mqtt_time_str error.\n");
        return VOS_ERR;
    }

    if (memcpy_s(dev_sta_rep_item->devDateTime, DATA_BUF_F64_SIZE, timestamp, strlen(timestamp) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: devDateTime failed!\n");
    }                                                                               // �豸��ǰʱ��

    if (sg_get_dev_date_time(dev_sta_rep_item->devStDateTime, &run_ltime) != VOS_OK) { // ��ȡ�豸���һ������ʱ��
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "dev_date_time failed", strlen("dev_date_time failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_inquire_reply: dev_date_time failed!\n");
        }
        return VOS_ERR;
    }
    dev_sta_rep_item->devRunTime = (uint32_t)run_ltime;                                // ��ȡ�豸����ʱ��
    return VOS_OK;
}

int sg_get_dev_link_and_period_param(dev_info_inq_reply_s *dev_info_inq_reply_item, char *errormsg)
{
    int ret = VOS_OK;
    sg_period_info_s sg_period_info = { 0 };
    if (sgcc_get_links_info(&dev_info_inq_reply_item->links, &dev_info_inq_reply_item->link_len) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "get links info failed", strlen("get links info failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: links info failed!\n");
        }
        ret = VOS_ERR;
    }

    if (sg_get_period_file(&sg_period_info) != VOS_OK) {
        if (memcpy_s(errormsg, DATA_BUF_F256_SIZE, "period_file failed", strlen("period_file failed") + 1) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_dev_info_cmd: period_file failed!\n");
        }
        ret = VOS_ERR;
    }

    dev_info_inq_reply_item->rep_period.appPeriod = sg_period_info.app_period;
    dev_info_inq_reply_item->rep_period.conPeriod = sg_period_info.container_period;
    dev_info_inq_reply_item->rep_period.devPeriod = sg_period_info.dev_period;
    dev_info_inq_reply_item->rep_period.heartPeriod = sg_period_info.dev_heartbeat_period;
    return ret;
}

