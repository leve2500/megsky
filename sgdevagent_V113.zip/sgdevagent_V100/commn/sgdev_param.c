#include <stdio.h>
#include <string.h>
#include <linux/limits.h>
#include <limits.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "ssp_mid.h"
#include "sgdev_common.h"
#include "sgdev_debug.h"
#include "upmqtt_json.h"
#include "sgdev_param.h"

sg_dev_param_info_s g_devParam;
sg_dev_section_info_s g_devSection;
sg_period_info_s g_devperiod;

int sg_getfilesize(char *strFileName)
{
    FILE *fp = NULL;
    char real_path[SG_DEV_PATH_MAX] = { 0 };
    int size = 0;

    if (strFileName == NULL) {
        return -1;
    }

    if (access(strFileName, 0) == -1) {
        return -1;
    }

    fp = fopen(real_path, "r");
    if (fp == NULL) {
        return -1;
    }

    (void)fseek(fp, 0L, SEEK_END);
    size = ftell(fp);
    (void)fseek(fp, 0L, SEEK_SET);
    (void)fclose(fp);
    return size;
}

// 读取断面文件
int sg_read_section_file(sg_dev_section_info_s *info)
{
    int ret = VOS_OK;
    json_t *json_data = NULL;
    json_error_t error;
    json_data = json_load_file(PERIOD_PARAMS_FILEPATH, 0, &error);
    if (json_into_uint8_t(&info->reboot_reason, json_data, "rebootReason") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_int32_t(&info->jobId, json_data, "jobId") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_int32_t(&info->midId, json_data, "midId") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_string(info->version, json_data, "version") != VOS_OK) {
        ret = VOS_ERR;
    }

    json_decref(json_data);
    return ret;
}
// 写断面文件
void sg_write_section_file(uint8_t reboot_reason, int32_t jobId, int32_t midId, char *version)
{
    int result = 0;
    json_t *json_data = json_object();

    if (!json_is_object(json_data)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "json_data memory failed");
        return;
    }

    (void)json_object_set_new(json_data, "rebootReason", json_integer(reboot_reason));
    (void)json_object_set_new(json_data, "jobid", json_integer(jobId));
    (void)json_object_set_new(json_data, "midid", json_integer(midId));
    (void)json_object_set_new(json_data, "version", json_string(version));

    result = json_dump_file(json_data, DEV_SECTION_FILEPATH, 0);
    if (result != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Failed to write the file(%s).\n", DEV_SECTION_FILEPATH);
    }

    json_decref(json_data);
}

// 读周期参数文件
int sg_read_period_file(void)
{
    int ret = VOS_OK;
    json_t *json_data = NULL;
    json_error_t error;

    json_data = json_load_file(PERIOD_PARAMS_FILEPATH, 0, &error);
    if (!json_is_object(json_data)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "file(%s) error %s,%d\n", PERIOD_PARAMS_FILEPATH, __FILE__, __LINE__);
        return VOS_ERR;
    }

    if (json_into_uint32_t(&g_devperiod.app_period, json_data, "app_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_uint32_t(&g_devperiod.container_period, json_data, "container_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_uint32_t(&g_devperiod.dev_period, json_data, "dev_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_uint32_t(&g_devperiod.dev_heartbeat_period, json_data, "dev_heartbeat_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    json_decref(json_data);
    return ret;
}

// 写周期参数文件
void sg_write_period_file(rep_period_s *paraobj)
{
    int result = 0;

    json_t *json_data = json_object();
    if (!json_is_object(json_data)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "json_data memory failed");
        return;
    }
    (void)json_object_set_new(json_data, "app_period", json_integer(paraobj->appPeriod));
    (void)json_object_set_new(json_data, "container_period", json_integer(paraobj->conPeriod));
    (void)json_object_set_new(json_data, "dev_period", json_integer(paraobj->devPeriod));
    (void)json_object_set_new(json_data, "dev_heartbeat_period", json_integer(paraobj->heartPeriod));

    result = json_dump_file(json_data, DEV_PARAMS_FILEPATH, 0);
    if (result != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Failed to write the file(%s).\n", DEV_PARAMS_FILEPATH);
    }

    json_decref(json_data);
}

// 读专检参数文件
int sg_read_param_file(void)
{
    int ret = VOS_OK;
    json_t *json_data = NULL;
    json_error_t error;
    json_data = json_load_file(DEV_PARAMS_FILEPATH, 0, &error);
    uint32_t iport = 1883;
    if (!json_is_object(json_data)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "file(%s) error %s,%d\n", DEV_PARAMS_FILEPATH, __FILE__, __LINE__);
        return VOS_ERR;
    }

    if (json_into_uint8_t(&g_devParam.startmode, json_data, "startmode") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_string(g_devParam.mqtttopicversion, json_data, "mqtttopicversion") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_string(g_devParam.devid, json_data, "devid") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_string(g_devParam.ip, json_data, "ip") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_uint32_t(&iport, json_data, "port") != VOS_OK) {
        ret = VOS_ERR;
    }
    g_devParam.port = (uint16_t)iport;
    if (json_into_string(g_devParam.clientid, json_data, "clientid") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_string(g_devParam.user, json_data, "user") != VOS_OK) {
        ret = VOS_ERR;
    }

    if (json_into_string(g_devParam.password, json_data, "password") != VOS_OK) {
        ret = VOS_ERR;
    }

    json_decref(json_data);
    return ret;
}
// 返回设备参数
void sg_get_param(sg_dev_param_info_s *devParam)
{
    *devParam = g_devParam;
}
// 返回周期参数
void sg_get_period(sg_period_info_s *devperiod)
{
    *devperiod = g_devperiod;
}

