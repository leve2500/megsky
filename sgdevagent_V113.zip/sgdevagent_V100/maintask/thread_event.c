#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "vrp_task.h"
#include "vrp_queue.h"
#include "ssp_mid.h"

#include "msgq_subpub.h"
#include "alarm_def.h"
#include "securec.h"

#include "sgdev_struct.h"
#include "sgdev_param.h"
#include "sgdev_queue.h"
#include "sgdev_debug.h"
#include "upmqtt_json.h"
#include "upmqtt_pub.h"
#include "upmqtt_dev.h"
#include "upmqtt_container.h"
#include "upmqtt_app.h"

#include "task_deal.h"
#include "thread_dev_insert.h"
#include "thread_task_exe.h"
#include "thread_event.h"

unsigned int g_create_event_id = 0;
int g_event_fd;

void sg_alarm_topic_pro(char *msg_buf, size_t msg_len);
int sg_event_deal_thread(void);
void sg_pro_event_dev(AlarmInfoType *info);

int sg_init_event_thread(void)
{
    int ret;
    ret = (int)VOS_T_Create(SG_EVENT_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
        (TaskStartAddress_PF)sg_event_deal_thread, &g_create_event_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) creat failed ret:%u.\n", SG_EVENT_TASK_NAME, ret);
        return VOS_ERR;
    }

    return VOS_OK;
}

int sg_exit_event_thread(void)
{
    int ret;
    ret = (int)VOS_T_Delete(g_create_event_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%d.\n", SG_EVENT_TASK_NAME, ret);
        return VOS_ERR;
    }
    (void)kmsg_sub_close(g_event_fd);
    return VOS_OK;
}

void sg_pro_event_dev(AlarmInfoType *info)
{
    dev_thing_reply_s evenobj;
    mqtt_data_info_s *item = NULL;
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_alarm_topic_pro:item is NULL!\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_data_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get error!\n");
    }

    if (strncmp(info->type, "CpuUtilizationRising", strlen("CpuUtilizationRising")) == 0) {
        if (info->indication == ALARM_GENERATE) {
            if (sprintf_s(evenobj.event, DATA_BUF_F64_SIZE, "1001") < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s evenobj.event!\n");
            }
            if (sprintf_s(evenobj.msg, DATA_BUF_F256_SIZE, "CPU ") < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s evenobj.msg!\n");
            }
        } else if (info->indication == ALARM_RESTORE) {
            if (sprintf_s(evenobj.event, DATA_BUF_F64_SIZE, "1002") < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s evenobj.event!\n");
            }
            if (sprintf_s(evenobj.msg, DATA_BUF_F256_SIZE, "CPU ") < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s evenobj.msg!\n");
            }
        }
    }

    sg_pack_dev_event(&evenobj, "", item->msg_send);
    sg_push_pack_item(item);
}

void sg_alarm_topic_pro(char *msg_buf, size_t msg_len)
{
    AlarmInfoStatusType *alarm_status = NULL;

    if (msg_len < sizeof(AlarmInfoStatusType)) {
        return;
    }

    alarm_status = (AlarmInfoStatusType *)msg_buf;
    if (strncmp(alarm_status->exInfo.info.function, "device", strlen("device")) == 0) {
        sg_pro_event_dev(&alarm_status->exInfo.info);
    }
}

// 事件线程
int sg_event_deal_thread(void)
{
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_event_deal_thread start.\n");
    int ret;

    char *msg_buf = NULL;
    size_t msg_len;
    msg_buf = (char *)VOS_Malloc(MID_SGDEV, SG_MSGPROC_MSG_LENGTH_MAX);
    if (msg_buf == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "event buf malloc failed.\n");
        return VOS_ERR;
    }

    g_event_fd = kmsg_sub_open(SG_ALARM_TOPIC, 0);
    if (g_event_fd < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "kmsg_sub_open failed.\n");
        (void)VOS_Free(msg_buf);
        return VOS_ERR;
    }

    for (;;) {
        msg_len = SG_MSGPROC_MSG_LENGTH_MAX;
        (void)memset_s(msg_buf, SG_MSGPROC_MSG_LENGTH_MAX, 0, SG_MSGPROC_MSG_LENGTH_MAX);
        ret = kmsg_subpub_consume_block(&g_event_fd, NULL, 0, msg_buf, &msg_len);           // 获取告警信息
        if (ret < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "kmsg_subpub_consume_block failed.\n");
        }

        sg_alarm_topic_pro(msg_buf, msg_len);
    }
}

