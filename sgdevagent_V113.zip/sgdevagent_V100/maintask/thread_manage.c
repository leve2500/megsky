#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "vrp_queue.h"
#include "vrp_task.h"
#include "ssp_mid.h"

#include "securec.h"

#include "sgdev_struct.h"
#include "sgdev_queue.h"
#include "sgdev_param.h"
#include "sgdev_debug.h"

#include "upmqtt_json.h"
#include "upmqtt_pub.h"
#include "thread_dev_insert.h"
#include "thread_manage.h"
#include "rmt_socket.h"
#include "rmt_frame.h"

char g_by_recv[DEV_INFO_MSG_BUFFER_LEN * DEV_INFO_MSG_BUFFER_NUM];
char g_by_send[DEV_INFO_MSG_BUFFER_LEN * DEV_INFO_MSG_BUFFER_NUM];
unsigned int g_create_mqt_pub_id = 0;
unsigned int g_create_socket_read_id = 0;
unsigned int g_create_socket_write_id = 0;

int g_rmt_connect_flag = 0;

int sg_mqtt_pub_thread(void);
int sg_rpc_read_data_thread(void);
int sg_rpc_write_data_thread(void);

int sg_get_link_connect_flag(void)
{
    int connect_flag = 0;
    sg_dev_param_info_s dev_param;
    (void)memset_s(&param, sizeof(sg_dev_param_info_s), 0, sizeof(sg_dev_param_info_s));
    sg_get_param(&param);
    if (dev_param.startmode == MODE_RMTMAN) {
        connect_flag = sg_get_rmt_connect_flag();
    } else {
        connect_flag = sg_get_mqtt_connect_flag();
    }
    return connect_flag;
}
int sg_init_data_manager_thread(void)
{
    int i_ret = VOS_OK;
    unsigned int ret = 0;
    sg_dev_param_info_s param;
    (void)memset_s(&param, sizeof(sg_dev_param_info_s), 0, sizeof(sg_dev_param_info_s));
    sg_get_param(&param);
    if (param.startmode == MODE_RMTMAN) {
        ret = VOS_T_Create(SG_RPC_READ_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
            (TaskStartAddress_PF)sg_rpc_read_data_thread, &g_create_socket_read_id);
        if (ret != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) create failed ret:%u.\n", SG_RPC_READ_TASK_NAME, ret);
            i_ret = VOS_ERR;
        }
        ret = VOS_T_Create(SG_RPC_WRITE_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
            (TaskStartAddress_PF)sg_rpc_write_data_thread, &g_create_socket_write_id);
        if (ret != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) create failed ret:%u.\n", SG_RPC_WRITE_TASK_NAME, ret);
            i_ret = VOS_ERR;
        }
    } else {
        ret = VOS_T_Create(SG_MQTT_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
            (TaskStartAddress_PF)sg_mqtt_pub_thread, &g_create_mqt_pub_id);
        if (ret != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) create failed ret:%u.\n", SG_MQTT_TASK_NAME, ret);
            return VOS_ERR;
        }
    }

    return i_ret;
}

int sg_exit_data_manager_thread(void)
{
    int i_ret = VOS_OK;
    unsigned int ret = 0;
    sg_dev_param_info_s param;
    (void)memset_s(&param, sizeof(sg_dev_param_info_s), 0, sizeof(sg_dev_param_info_s));
    sg_get_param(&param);
    if (param.startmode == MODE_RMTMAN) {
        ret = VOS_T_Delete(g_create_socket_read_id);
        if (ret != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%d.\n", SG_RPC_READ_TASK_NAME, ret);
            i_ret = VOS_ERR;
        }
        ret = VOS_T_Delete(g_create_socket_write_id);
        if (ret != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%d.\n", SG_RPC_WRITE_TASK_NAME, ret);
            i_ret = VOS_ERR;
        }
    } else {
        ret = VOS_T_Delete(g_create_mqt_pub_id);
        if (ret != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%d.\n", SG_MQTT_TASK_NAME, ret);
            return VOS_ERR;
        }
    }

    return i_ret;
}

static int sg_get_continue_send(char *buf)
{
    int len = 0;
    uint32_t pack_queue_id = sg_get_que_pack_id();
    VOS_UINTPTR msg[VOS_QUEUE_MSG_NUM] = { 0 };
    mqtt_data_info_s* info = NULL;
    if (buf != NULL) {
        return 0;
    }

    if (VOS_Que_Read(pack_queue_id, msg, VOS_WAIT, 0) == VOS_OK) {
        info = (mqtt_data_info_s*)msg[1];
        len = sg_packframe(buf, info);        // 组帧
        if (info != NULL) {
            (void)VOS_Free(info);
        }
    }

    return len;
}

int sg_rpc_read_data_thread(void)
{
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_rpc_read_data_thread start.\n");
    int us_pos = 0;
    int maxlen = DEV_INFO_MSG_BUFFER_LEN * DEV_INFO_MSG_BUFFER_NUM;
    int n_ret_state = 0;
    int n_tmp_count = 0;
    int by_state1 = SOCKET_CONNECTNORMAL;
    s_socket_param sock_param = { 0, 0, {0} };
    sock_param.type = TCP_TYPE; // TCP客户端
    sock_param.port_number = 2406;
    if (sprintf_s(sock_param.ip_address, SOCKET16_LEN, "%s", "192.169.11.100") < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_rpc_read_data_thread start.\n");
        return VOS_ERR;
    }

    sg_set_socket_param(sock_param, 0);
    for (;;) {
        VOS_T_Delay(MS_HUNDRED_INTERVAL);
        by_state1 = sg_get_connect_state();
        if (SOCKET_CONNECTNORMAL != by_state1) {
            VOS_T_Delay(MS_MGR_THREAD_CONNECT_WAIT); // 重连时间
            n_ret_state = sg_connect_socket();
            if (n_ret_state == SOCKET_CONNECTNORMAL) {
                sg_set_rmt_connect_flag(DEVICE_ONLINE);
            }
        }
        by_state1 = sg_get_connect_state();
        if (by_state1 == SOCKET_CONNECTNORMAL) {
            n_tmp_count = sg_read_data(g_by_recv, maxlen);
            if (n_tmp_count > 0) {
                sg_recvive((uint8_t *)g_by_recv, (uint32_t)n_tmp_count, (uint16_t)us_pos);
                us_pos = n_tmp_count;
                sg_set_recv_cnt((uint16_t)us_pos);
                us_pos = 0;
                sg_unpack_frame();
            }
            if (n_tmp_count > 0 && sg_get_recvive_num() <= 0) {
                continue;
            }
            if (sg_get_connect_state() != SOCKET_CONNECTNORMAL) {
                sg_set_rmt_connect_flag(DEVICE_OFFLINE);                // sg_cloese_socket();
            }
        }
    }
}

int sg_rpc_write_data_thread(void)
{
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_rpc_write_data_thread start.\n");
    int n_tmp_count = 0;
    int maxlen = DEV_INFO_MSG_BUFFER_LEN * DEV_INFO_MSG_BUFFER_NUM;
    unsigned char by_state1 = SOCKET_CONNECTNORMAL;
    int ul_req_send_num = 0;
    int maxnum = DEV_INFO_MSG_BUFFER_LEN * DEV_INFO_MSG_BUFFER_NUM;
    for (;;) {
        VOS_T_Delay(MS_HUNDRED_INTERVAL);
        by_state1 = (unsigned char)sg_get_connect_state();
        if (by_state1 != SOCKET_CONNECTNORMAL) {
            continue;
        }
        ul_req_send_num = sg_get_continue_send(g_by_send);
        if (ul_req_send_num > 0) {
            if (ul_req_send_num > maxlen) {
                continue;
            }

            n_tmp_count = sg_write_data(g_by_send, (int)(ul_req_send_num));
            if (n_tmp_count > 0) {
                (void)memset_s(g_by_send, (size_t)maxnum, 0, (size_t)maxnum);
            }
        }

        if (sg_get_connect_state() != SOCKET_CONNECTNORMAL) {
            sg_set_rmt_connect_flag(DEVICE_OFFLINE);
        }
    }
}

int sg_mqtt_pub_thread(void)
{
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_pub_thread start.\n");
    int send_flag = 0;
    uint32_t pack_queue_id = sg_get_que_pack_id();
    VOS_UINTPTR msg[VOS_QUEUE_MSG_NUM] = { 0 };
    mqtt_data_info_s *info = NULL;
    for (;;) {
        if (sg_get_mqtt_connect_flag() == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_MGR_THREAD_CONNECT_WAIT);
            continue;
        }

        if (VOS_Que_Read(pack_queue_id, msg, VOS_WAIT, 0) == VOS_OK) {
            info = (mqtt_data_info_s*)msg[MSG_ORDER_NUM_FIRST];
            send_flag = sg_mqtt_msg_publish(info->msg_send, info->pub_topic);                // 发送失败之后
            if (send_flag != VOS_OK) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_msg_publish error.\n");
            }
            if (info != NULL) {
                (void)VOS_Free(info);
            }
        }
        
        VOS_T_Delay(MS_HUNDRED_INTERVAL);
    }
}
void sg_set_rmt_connect_flag(int flag)
{
    g_rmt_connect_flag = flag;
    if (g_rmt_connect_flag == DEVICE_OFFLINE) {
        sg_set_dev_ins_flag(DEVICE_OFFLINE);
    }
}

int sg_get_rmt_connect_flag(void)
{
    return g_rmt_connect_flag;
}
