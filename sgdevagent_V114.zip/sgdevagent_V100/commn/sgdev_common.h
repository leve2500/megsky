/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent common header file
*/

#ifndef __SGDEV_COMMON_H__
#define __SGDEV_COMMON_H__

#ifdef __cplusplus
extern "C" {  // only need to export C interface if used by C++ source code
#endif

int sg_hamming_weight(unsigned long long number);    // ͳ���޷��ų����������Ʊ�ʾ��1�ĸ���
int sg_find(char *m_pbuf, int m_nlen, const char *i_pstr, int i_nnum, int i_nindex);
int sg_str_left(char *p_data, int m_nlen, char *d_data, int i_nlen);
int sg_str_mid(char *p_data, int m_nlen, int i_nindex, char *d_data, int i_nlen);
int sg_str_right(char *p_data, int m_nlen, char *d_data, int i_nlen);
int sg_str_colon(char *p_data, int m_nlen, char *ld_datal, char *rd_data);// ð�ŷָ������ַ�
int sg_cmd_common_get(const char *p, char *desp);
int sg_read_file_get(const char *p, char *desp);
int sg_file_common_get(const char *p, char *desp);

#ifdef __cplusplus
}
#endif

#endif
