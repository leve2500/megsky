/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2021. All rights reserved.
 * Description : sgdevagent timer header file
*/

#ifndef __TIMER_PACK_H__
#define __TIMER_PACK_H__

#ifdef __cplusplus
extern "C" {
#endif

int sg_timer_pre_create(void);
// ������ʱ��
int sg_timer_heart_create(uint32_t timeout);
int sg_timer_dev_create(uint32_t timeout);
int sg_timer_container_create(uint32_t timeout);
int sg_timer_app_create(uint32_t timeout);

// ɾ����ʱ��
void sg_timer_heart_delete(void);
void sg_timer_dev_delete(void);
void sg_timer_container_deletee(void);
void sg_timer_app_delete(void);

int sg_get_dev_heart_flag(void);
void sg_set_dev_heart_flag(int flag);

#ifdef __cplusplus
}
#endif

#endif
