#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <sys/sysinfo.h>
#include <sys/time.h>

#include "securec.h"

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "ssp_mid.h"
#include "sgdev_struct.h"
#include "sgdev_debug.h"
#include "sgdev_param.h"
#include "sgdev_common.h"


#define  STR_ERROR_NEG_TWO (-2)

// ͳ���޷��ų����������Ʊ�ʾ��1�ĸ��� Hamming_weight�㷨��---ֻ����1��λ��
int sg_hamming_weight(unsigned long long number)
{
    int count = 0;
    while (number != 0) {
        number &= number - 1;
        count++;
    }

    return count;
}

// ��Index����ʼ������num�γ����ַ���i_pstr��λ��
int sg_find(char *m_pbuf, int m_nlen, const char *i_pstr, int i_nnum, int i_nindex)
{
    char *pos = NULL;
    char *old_pos = NULL;
    int new_pos = 0;
    int i = 0;
    if (i_pstr == NULL || m_pbuf == NULL) {
        return -1;
    }

    if (i_nindex > m_nlen - 1 || i_nindex < 0) {
        return -1;
    }

    old_pos = m_pbuf + i_nindex;

    for (i = 0; i < i_nnum; ++i) {
        pos = strstr(old_pos, i_pstr);
        if (pos == NULL) {
            return STR_ERROR_NEG_TWO;
        }

        old_pos = pos + strlen(i_pstr);
    }
    if (pos != NULL) {
        new_pos = (int)(pos - m_pbuf);
    }
    return new_pos;
}

// ���ַ�����ʼ����ȡi_nlen���ȵ��ַ���
// �������  : char *p_data  : Ҫ�������ݵ��׵�ַ
// m_nlen :���볤��
// d_data :���ָ��
// i_nlen :��ȡ����
int sg_str_left(char *p_data, int m_nlen, char *d_data, int i_nlen)
{
    int t_nLen = 0;
    if (d_data == NULL || p_data == NULL) {
        return 0;
    }

    if (i_nlen <= 0 || m_nlen <= 0) {
        return 0;
    } else if (i_nlen > m_nlen) {
        t_nLen = m_nlen;
    } else {
        t_nLen = i_nlen;
    }

    if (strncpy_s(d_data, (size_t)m_nlen, p_data, (size_t)t_nLen) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_left error.des =%s ,sor = %s\n", d_data, p_data);
        return 0;
    }

    return t_nLen;
}
// �������: char *p_data  : Ҫ�������ݵ��׵�ַ
// m_nlen :���볤��
// d_data :���ָ��
// i_nlen :��ȡ����
// i_nindex �ӵڼ�λ��ʼ

int sg_str_mid(char *p_data, int m_nlen, int i_nindex, char *d_data, int i_nlen)
{
    int t_nLen = 0;
    if (d_data == NULL || p_data == NULL) {
        return 0;
    }

    if (i_nindex < 0 || i_nindex >= m_nlen || m_nlen <= 0) {    // i_nlen ������ʾȡ���������ַ�
        return 0;
    } else if (i_nlen > m_nlen - i_nindex || i_nlen < 0) {
        t_nLen = m_nlen - i_nindex;
    } else {
        t_nLen = i_nlen;
    }

    if (strncpy_s(d_data, (size_t)m_nlen, p_data + i_nindex, (size_t)t_nLen) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid error.des =%s ,sor = %s\n", d_data, p_data + i_nindex);
        return 0;
    }

    return t_nLen;
}
// �������  : char *p_data  : Ҫ�������ݵ��׵�ַ
// m_nlen :���볤��
// d_data :���ָ��
// i_nlen :��ȡ����
// i_nindex �ӵڼ�λ��ʼ
// ���ַ����ҿ�ʼ����ȡi_nlen���ȵ��ַ���
int sg_str_right(char *p_data, int m_nlen, char *d_data, int i_nlen)
{
    if (d_data == NULL || p_data == NULL) {
        return 0;
    }

    int t_nLen = 0;

    if (i_nlen <= 0 || m_nlen <= 0) {
        return 0;
    } else if (i_nlen > m_nlen) {
        t_nLen = m_nlen;
    } else {
        t_nLen = i_nlen;
    }

    if (strncpy_s(d_data, (size_t)m_nlen, p_data + m_nlen - t_nLen, (size_t)t_nLen) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "strcpy_s error.des =%s ,sor = %s\n", d_data, p_data + m_nlen - t_nLen);
        return 0;
    }

    return t_nLen;
}
int sg_str_colon(char *p_data, int m_nlen, char *ld_datal, char *rd_data)
{
    int pos = 0;
    if (ld_datal == NULL || rd_data == NULL) {
        return VOS_ERR;
    }

    pos = sg_find(p_data, m_nlen, ":", 1, 0);
    if (pos > 0) {
        if (sg_str_left(p_data, m_nlen, ld_datal, pos) <= 0) {
            return VOS_ERR;
        }
        if (sg_str_right(p_data, m_nlen, rd_data, m_nlen - pos - 1) <= 0) {
            return VOS_ERR;
        }
    } else {
        if (strcpy_s(ld_datal, DATA_BUF_F64_SIZE, p_data) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "strncpy_s p_data =  %s.\n", p_data);
            return VOS_ERR;
        }
    }

    return VOS_OK;
}

// ��ָ��ͨ�ýӿ�
int sg_cmd_common_get(const char *p, char* desp)
{
    char buf[DEV_INFO_MSG_BUFFER_LEN] = { 0 };
    char cmd_buf[DEV_INFO_MSG_BUFFER_LEN] = { 0 };
    FILE *p_file = NULL;

    if (desp == NULL || p == NULL) {
        return VOS_ERR;
    }

    if (sprintf_s(cmd_buf, DEV_INFO_MSG_BUFFER_LEN, p) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s error cmd_buf", p);
        return VOS_ERR;
    }

    p_file = popen(cmd_buf, "r");
    if (p_file == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "popen cmd(%s) failed.\n", p);
        return VOS_ERR;
    }

    while (fgets(buf, DEV_INFO_MSG_BUFFER_LEN, p_file) != NULL) {
        if (memcpy_s(desp, DEV_INFO_MSG_BUFFER_LEN, buf, strlen(buf) - 1) != 0) {    //strlen(buf) - 1��Ϊ��ȥ��\n
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "popen cmd(%s) failed.\n", p);
            return VOS_ERR;
        }
    }
    (void)pclose(p_file);
    return VOS_OK;
}

// �������ļ��ӿ�
int sg_read_file_get(const char *p, char *desp)
{
    int filesize = 0;
    FILE *fp = NULL;
    char *buf = NULL;
    char real_path[PATH_MAX] = { 0 };
    char cmd_buf[DEV_INFO_MSG_BUFFER_LEN] = { 0 };

    if (desp == NULL || p == NULL) {
        return VOS_ERR;
    }

    if (sprintf_s(cmd_buf, DEV_INFO_MSG_BUFFER_LEN, p) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_read_file_get sprintf_s error cmd_buf", p);
        return VOS_ERR;
    }

    char filename[DATA_BUF_F512_SIZE];
    if (sprintf_s(filename, DATA_BUF_F512_SIZE, "%s", p) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_read_file_get sprintf_s file.name failed.\n");
    }

    filesize = sg_getfilesize(filename);
    if (filesize <= 0) {
        return VOS_ERR;
    }

    buf = (char *)VOS_Malloc(MID_SGDEV, sizeof(char) * (size_t)filesize);
    if (buf == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_read_file_get: unable to allocate required memory.\n");
        return VOS_ERR;
    }

    (void)memset_s(buf, (size_t)filesize, 0, (size_t)filesize);

    if (realpath(filename, real_path) == NULL) {
        return VOS_ERR;
    }

    fp = fopen(real_path, "r");
    if (fp == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "open file(%s) failed.\n", real_path);
        (void)VOS_Free(buf);
        return VOS_ERR;
    }

    if (!fread(buf, (size_t)filesize, 1, fp)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "read file(%s) failed.\n", real_path);
        (void)fclose(fp);
        (void)VOS_Free(buf);
        return VOS_ERR;
    }

    if (memcpy_s(desp, strlen(buf), buf, strlen(buf)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_read_file_get:memcpy_s failed\n");
    }
    (void)VOS_Free(buf);
    return VOS_OK;
}

// �������ļ�����ͨ�ýӿ�
int sg_file_common_get(const char *p, char *desp)
{
    FILE *fp = NULL;
    char buf[DEV_INFO_MSG_BUFFER_LEN] = { 0 };
    char cmd_buf[DEV_INFO_MSG_BUFFER_LEN] = { 0 };
    if (desp == NULL || p == NULL) {
        return VOS_ERR;
    }

    if (sprintf_s(cmd_buf, DEV_INFO_MSG_BUFFER_LEN, p) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s error cmd_buf", p);
        return VOS_ERR;
    }

    if ((fp = fopen(cmd_buf, "r")) == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "open file(%s) failed.\n", cmd_buf);
        return VOS_ERR;
    }

    while (!feof(fp)) {
        if (fgets(buf, DEV_INFO_MSG_BUFFER_LEN, fp) != NULL) {
            if (sprintf_s(desp, DEV_INFO_MSG_BUFFER_LEN, "%s", buf) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_file_common_get:sprintf_s desp failed.\n", p);
                return VOS_ERR;
            }
        }
    }
    (void)fclose(fp);
    return VOS_OK;
}
