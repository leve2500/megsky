/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent mutex header file
*/

#ifndef __SGDEV_MUTEX_H__
#define __SGDEV_MUTEX_H__

#ifdef __cplusplus
extern "C" {
#endif

void sg_mutex_init(void);
void sg_mutex_exit(void);
bool sg_try_lock(void);
void sg_lock(void);
void sg_unlock(void);

#ifdef __cplusplus
}
#endif

#endif