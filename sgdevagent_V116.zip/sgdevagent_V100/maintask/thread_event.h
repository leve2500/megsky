/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2020. All rights reserved.
 * Description : sgdevagent task event running header file
*/

#ifndef __TASK_EVENT_H__
#define __TASK_EVENT_H__

#ifdef __cplusplus
extern "C" {
#endif

#define SG_ALARM_TOPIC "ALARM"
#define SG_EVENT_TASK_NAME "skmg"
#define SG_MSGPROC_MSG_LENGTH_MAX 191000

int sg_init_event_thread(void);
int sg_exit_event_thread(void);

#ifdef __cplusplus
}
#endif

#endif
