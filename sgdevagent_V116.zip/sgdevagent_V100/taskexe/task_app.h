/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent app header file
*/

#ifndef __TASK_APP_H__
#define __TASK_APP_H__


#ifdef __cplusplus
extern "C" {
#endif

int sg_app_install(app_install_cmd_s *cmd_obj, char *errmsg);
int sg_app_update(app_upgrade_cmd_s *cmd_obj, char *errmsg);
int sg_container_with_app_install(container_install_cmd_s *cmd_obj, char *errmsg);
void sg_app_config_result_reply(uint16_t code, int32_t mid, app_conf_reply_s *app_conf_reply_item, char *errormsg);
int sg_appm_modify_app_info_cmd(APPM_OPERATION_PARA *para);
int sg_get_apps_process(process_info_s *process, uint32_t process_count, app_service_info *services);
int sg_get_apps_array(apps_info_s **app_max, int app_cnt, app_info_t *app_info);
void sg_app_install_reply_frame(uint16_t code, int32_t mid, char* errormsg);
void sg_app_update_reply_frame(uint16_t code, int32_t mid, char* errormsg);
int sg_app_select_control(char *type, APPM_OPERATION_PARA *para);
// app״̬��ѯ����ϱ�
void sg_push_item_app_status(char *type, uint16_t code, int32_t mid, const char *error_msg,
    app_inq_reply_s *statusobj);
#ifdef __cplusplus
}
#endif

#endif

