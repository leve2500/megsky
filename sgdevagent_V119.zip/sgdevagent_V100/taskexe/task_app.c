#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include "ssp_mid.h"
#include "ssp_misc.h"
#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "securec.h"
#include "vm_public.h"
#include "sysman_rpc_api.h"
#include "app_management_service_api.h"

#include <glib-object.h>
#include <thrift/c_glib/thrift.h>

#include "upmqtt_json.h"
#include "upmqtt_app.h"
#include "upmqtt_dev.h"
#include "upmqtt_json.h"
#include "upmqtt_pub.h"
#include "sgdev_queue.h"
#include "sgdev_param.h"
#include "sgdev_struct.h"
#include "sgdev_curl.h"
#include "sgdev_debug.h"
#include "sgdev_common.h"
#include "timer_pack.h"
#include "thread_interact.h"
#include "task_link.h"
#include "task_app.h"

static int sg_set_app_install_param(APPM_OPERATION_PARA *para, app_install_cmd_s *cmd_obj, char *errmsg)
{
    uint32_t cpus = 0;
    unsigned long long i = 0;
    if (memcpy_s(para->lxc_name, DATA_BUF_F64_SIZE, cmd_obj->container, strlen(cmd_obj->container) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_app_install_param:memcpy_s failed\n");
    }

    if (memcpy_s(para->app_name, DATA_BUF_F64_SIZE, cmd_obj->app, strlen(cmd_obj->app) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_app_install_param:memcpy_s failed\n");
    }

    if (sprintf_s(para->app_file, DATA_BUF_F128_SIZE, "%s/%s", DEFAULT_FILE_PATH, cmd_obj->file.name) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_app_install_param sprintf_s(%s)failed .\n", DEFAULT_FILE_PATH);
    }

    if (ssp_calculate_sha256_of_file(para->app_file, para->app_hash, APP_MANAGEMENT_APP_HASH_MAX_LEN + 1)) {
        if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "ssp_calculate_sha256 permission denied") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_app_install_param sprintf_s(%s)failed .\n", "errmsg");
        }
        return VOS_ERR;
    }

    cpus = (uint32_t)(cmd_obj->cfgCpu.cpus);
    para->cpu_mask = 0;
    for (i = 0; i < cpus; i++) {
        para->cpu_mask |= i;
    }

    para->cpu_threshold = cmd_obj->cfgCpu.cpuLmt;
    para->memory_limit = cmd_obj->cfgMem.memory;
    para->memory_threshold = cmd_obj->cfgMem.memLmt;
    if (cmd_obj->file.sign.size != 0 || strlen(cmd_obj->file.sign.name) != 0) { // ��Ҫǩ��
        para->verify = 1;
    }

    return VOS_OK;
}

static int sg_set_app_with_install_param(APPM_OPERATION_PARA *para, with_app_info_s *with_obj, char *errmsg)
{
    uint32_t cpus = 0;
    unsigned long long i = 0;
    if (sprintf_s(para->app_file, DATA_BUF_F128_SIZE, "%s/%s", DEFAULT_FILE_PATH, with_obj->file.name) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_app_install_param sprintf_s(%s)failed .\n", DEFAULT_FILE_PATH);
    }

    cpus = (uint32_t)(with_obj->cfgCpu.cpus);
    para->cpu_mask = 0;
    for (i = 0; i < cpus; i++) {
        para->cpu_mask |= i;
    }

    para->cpu_threshold = with_obj->cfgCpu.cpuLmt;
    para->memory_limit = with_obj->cfgMem.memory;
    para->memory_threshold = with_obj->cfgMem.memLmt;
    if (with_obj->file.sign.size != 0 || strlen(with_obj->file.sign.name) != 0) { //��Ҫǩ��
        para->verify = 1;
    }

    if (ssp_calculate_sha256_of_file(para->app_file, para->app_hash, APP_MANAGEMENT_APP_HASH_MAX_LEN + 1)) {
        if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "ssp_calculate_sha256 permission denied") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_set_app_with_install_param sprintf_s(%s)failed .\n", "errmsg");
        }

        return VOS_ERR;
    }

    return VOS_OK;
}

// Ӧ�ð�װ����Ӧ�������֡
void sg_app_install_reply_frame(uint16_t code, int32_t mid, char* errormsg)
{
    mqtt_data_info_s *item = NULL;
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_reply_frame memory.\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_install_reply_frame sprintf_s pub_topic failed .\n");
    }

    if (sg_pack_app_install_cmd(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_pack_container_install_cmd failed .\n");
    }

    sg_push_pack_item(item);
}

// Ӧ����������Ӧ�������֡
void sg_app_update_reply_frame(uint16_t code, int32_t mid, char* errormsg)
{
    mqtt_data_info_s *item = NULL;
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_update_reply_frame memory.\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_update_reply_frame sprintf_s pub_topic failed .\n");
    }

    if (sg_pack_app_upgrade_cmd(code, mid, errormsg, item->msg_send) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_update_reply_frame failed .\n");
    }

    sg_push_pack_item(item);
}

int sg_app_update(app_upgrade_cmd_s *cmd_obj, char *errmsg)
{
    int ret = VOS_OK;
    dev_status_reply_s status = { 0 };
    APPM_OPERATION_PARA para;
    (void)memset_s(&para, sizeof(APPM_OPERATION_PARA), 0, sizeof(APPM_OPERATION_PARA));
    appm_error_message err_msg;
    (void)memset_s(&err_msg, sizeof(appm_error_message), 0, sizeof(appm_error_message));

    status.jobId = cmd_obj->jobId;
    status.state = STATUS_EXE_INSTALL;
    set_app_install_status(status);

    if (memcpy_s(para.lxc_name, DATA_BUF_F64_SIZE, cmd_obj->container, strlen(cmd_obj->container) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_update memcpy_s failed\n");
    }

    if (sprintf_s(para.app_file, DATA_BUF_F128_SIZE, "%s/%s", DEFAULT_FILE_PATH, cmd_obj->file.name) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_update sprintf_s(%s)failed .\n", DEFAULT_FILE_PATH);
    }

    if (ssp_calculate_sha256_of_file(para.app_file, para.app_hash, APP_MANAGEMENT_APP_HASH_MAX_LEN + 1)) {
        if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "permission denied") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_update sprintf_s(%s)failed .\n", "errmsg");
        }
        return VOS_ERR;
    }

    if (cmd_obj->file.sign.size != 0 || strlen(cmd_obj->file.sign.name) != 0) { //��Ҫǩ��
        para.verify = 1;
    }

    if (appm_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_update appm_rpc_transport_open failed.\n");
        return VOS_ERR;
    }

    if (app_management_action_call_app_install(&para, &err_msg) != VOS_OK) {
        if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "app_install:%s", err_msg.errMsg) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_install sprintf_s app_install errmsg failed.\n");
        }
        ret = VOS_ERR;
    }

    appm_rpc_transport_close();    // �汾���
    return ret;
}

int sg_app_install(app_install_cmd_s *cmd_obj, char *errmsg)
{
    int ret = VOS_OK;
    dev_status_reply_s status;
    (void)memset_s(&status, sizeof(dev_status_reply_s), 0, sizeof(dev_status_reply_s));
    APPM_OPERATION_PARA para;

    (void)memset_s(&para, sizeof(APPM_OPERATION_PARA), 0, sizeof(APPM_OPERATION_PARA));
    appm_error_message err_msg;

    (void)memset_s(&err_msg, sizeof(appm_error_message), 0, sizeof(appm_error_message));
    status.jobId = cmd_obj->jobId;
    status.state = STATUS_EXE_INSTALL;
    set_app_install_status(status);

    if (sg_set_app_install_param(&para, cmd_obj, errmsg) != VOS_OK) {
        return VOS_ERR;
    }

    if (appm_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_install appm_rpc_transport_open failed.\n");
        return VOS_ERR;
    }
    if (app_management_action_call_app_install(&para, &err_msg) != VOS_OK) {
        if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "app_install:%s", err_msg.errMsg) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_install sprintf_s app_install errmsg failed.\n");
        }

        ret = VOS_ERR;
    }
    if (strncmp(cmd_obj->enable, "1", strlen(cmd_obj->enable)) == 0) {
        if (app_management_action_call_app_enable(&para, &err_msg) != VOS_OK) {
            if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "enable:%s", err_msg.errMsg) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_install sprintf_s enable errmsg failed.\n");
            }
            ret = VOS_ERR;
        }
    } else {
        if (app_management_action_call_app_disable(&para, &err_msg) != VOS_OK) {
            if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "disable:%s", err_msg.errMsg) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_app_install sprintf_s disable errmsg failed.\n");
            }
            ret = VOS_ERR;
        }
    }

    appm_rpc_transport_close();
    return ret;
}
// withapp��file->name���н�ȡ��ȡ��Ӧ����.��׺ǰ������
// char *name ����
// char *out_app_name ���
static int sg_get_withapp_filename(char *name, char *out_app_name)
{
    char app_name[DATA_BUF_F64_SIZE];
    if (out_app_name == NULL) {
        return VOS_ERR;
    }

    if (sg_str_point(name, (int)strlen(name), app_name) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_point failed.\n");
        return VOS_ERR;
    }

    if (memcpy_s(out_app_name, DATA_BUF_F64_SIZE, app_name, strlen(app_name) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "memcpy_s failed\n");
    }
    return VOS_OK;
}
// �����е�Ӧ�ð�װ
int sg_container_with_app_install(container_install_cmd_s *cmd_obj, char *errmsg)
{
    int ret = VOS_OK;
    appm_error_message err_msg;
    (void)memset_s(&err_msg, sizeof(appm_error_message), 0, sizeof(appm_error_message));
    dev_status_reply_s status;
    (void)memset_s(&status, sizeof(dev_status_reply_s), 0, sizeof(dev_status_reply_s));
    APPM_OPERATION_PARA para;
    (void)memset_s(&para, sizeof(APPM_OPERATION_PARA), 0, sizeof(APPM_OPERATION_PARA));

    status.jobId = cmd_obj->jobId;
    status.state = STATUS_EXE_INSTALL;
    set_app_install_status(status);

    if (memcpy_s(para.lxc_name, DATA_BUF_F64_SIZE, cmd_obj->container, strlen(cmd_obj->container) + 1) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_with_app_install memcpy_s failed.\n");
    }
    if (sg_get_withapp_filename(cmd_obj->withAPP.file.name, para.app_name) != VOS_OK) {
        return VOS_ERR;
    }

    if (sg_set_app_with_install_param(&para, &cmd_obj->withAPP, errmsg) != VOS_OK) {
        return VOS_ERR;
    }
    
    if (appm_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_with_app_install appm_rpc_transport_open failed.\n");
        return VOS_ERR;
    }

    if (app_management_action_call_app_install(&para, &err_msg) != VOS_OK) {
        if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "app_install:%s", err_msg.errMsg) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_container_with_app_install sprintf app_install err failed.\n");
        }

        ret = VOS_ERR;
    }

    if (strncmp(cmd_obj->withAPP.enable, "1", strlen(cmd_obj->withAPP.enable)) == 0) {
        if (app_management_action_call_app_enable(&para, &err_msg) != VOS_OK) {
            if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "enable:%s", err_msg.errMsg) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "container_with_app_install sprintf_s enable errmsg failed.\n");
            }

            ret = VOS_ERR;
        }
    } else {
        if (app_management_action_call_app_disable(&para, &err_msg) != VOS_OK) {
            if (sprintf_s(errmsg, APP_MANAGEMENT_ERRMSG_MAX_LEN, "disable:%s", err_msg.errMsg) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "container_with_app_install sprintf_s disable errmsg failed.\n");
            }

            ret = VOS_ERR;
        }
    }

    appm_rpc_transport_close();
    return ret;
}

// Ӧ������״̬����ϱ�
void sg_app_config_result_reply(uint16_t code, int32_t mid, app_conf_reply_s *app_conf_reply_item, char *errormsg)
{
    mqtt_data_info_s *item = NULL;

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_param_get:item is NULL\n");
        return;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic get failed\n");
    } 

    sg_pack_app_param_get_reply(code, mid, errormsg, app_conf_reply_item, item->msg_send);
    sg_push_pack_item(item);
}


int sg_appm_modify_app_info_cmd(APPM_OPERATION_PARA *para)
{
    appm_error_message err_msg;
    (void)memset_s(&err_msg, sizeof(appm_error_message), 0, sizeof(appm_error_message));
    if (para == NULL || para->lxc_name == NULL || para->app_name == NULL) {
        return VOS_ERR;
    }

    if (appm_rpc_transport_open()) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Connect to rpc server error.!\n");
        return VOS_ERR;
    }

    if (app_management_action_call_app_set_config(para, &err_msg)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "app_management_action_call_app_set_config error.!\n");
        return VOS_ERR;
    }
    appm_rpc_transport_close();
    return VOS_OK;
}

// ��ȡӦ��״̬��ѯ�е�ǰAPP�Ľ������� if ̫��
int sg_get_apps_process(process_info_s *process, uint32_t process_count, app_service_info *services)
{
    uint32_t num_process = 0;

    process = (process_info_s*)VOS_Malloc(MID_SGDEV, sizeof(process_info_s) * process_count);            // �ǵ��ͷ�
    if (process == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "malloc use failure!\n");
        return VOS_ERR;
    }
    (void)memset_s(process, sizeof(process_info_s) * process_count, 0, sizeof(process_info_s) * process_count);

    for (num_process = 0; num_process < process_count; num_process++) {                 // ������Ϣ��ȡ
        process[num_process].srvIndex = num_process;                                    // ��������
        if (memcpy_s(process[num_process].srvName, DATA_BUF_F64_SIZE,                   // ��������
            services[num_process].name, strlen(services[num_process].name)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_process: name failed!\n");
        }
        if (services[num_process].enable == 1) {                                         // ����ʹ��״̬,yes �� no
            if (memcpy_s(process[num_process].srvEnable, DATA_BUF_F64_SIZE, "yes", strlen("yes")) != 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_process: srvEnable failed!\n");
            }
        } else {
            if (memcpy_s(process[num_process].srvEnable, DATA_BUF_F64_SIZE, "no", strlen("no")) != 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_process: srvEnable failed!\n");
            }
        }
        if (services[num_process].status == 0) {      // ����״̬, running �� stopped
            if (memcpy_s(process[num_process].srvStatus, DATA_BUF_F64_SIZE, "running", strlen("running")) != 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_process: srvStatus failed!\n");
            }
        } else {
            if (memcpy_s(process[num_process].srvStatus, DATA_BUF_F64_SIZE, "stopped", strlen("stopped")) != 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_process: srvStatus failed!\n");
            }
        }
        process[num_process].cpuLmt = services[num_process].cpu_usage_threshold;        // CPU �����ֵ���ٷֱ�����
        process[num_process].cpuRate = services[num_process].cpu_usage_current;         // ��ǰ CPU ʹ���ʣ��ٷֱ�����
        process[num_process].memLmt = services[num_process].memory_usage_threshold;     // �ڴ�����ֵ���ٷֱ�����
        process[num_process].memUsed = services[num_process].memory_usage_current;      // ��ǰ�ڴ�ʹ�ÿռ�Ĵ�С
        if (sprintf_s(process[num_process].startTime, DATA_BUF_F64_SIZE, "%04d-%02d-%02d %02d:%02d:%02d",
            services[num_process].start_time.year, services[num_process].start_time.month,
            services[num_process].start_time.day, services[num_process].start_time.hour,
            services[num_process].start_time.minute, services[num_process].start_time.second) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_process: sprintf_s failed!\n");
        }
    }
    return VOS_OK;
}

// ��ȡӦ��״̬��ѯ�е�ǰAPP
int sg_get_apps_array(apps_info_s **app_max, int app_cnt, app_info_t *app_info)
{
    int i                   = 0;
    int ret                 = VOS_OK;
    uint32_t process_count  = 0;
    uint16_t num            = 0;
    size_t app_all_num = (size_t)app_cnt;
    apps_info_s *apps = NULL;
    apps = (apps_info_s *)VOS_Malloc(MID_SGDEV, sizeof(apps_info_s) * app_all_num);
    if (apps == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "malloc use failure\n");
        return VOS_ERR;
    }
    (void)memset_s(apps, sizeof(apps_info_s) * app_all_num, 0, sizeof(apps_info_s) * app_all_num);
    for (num = 0; num < app_all_num; num++) {               // ���������ж��ٸ�APP��ÿ��APP�����Ӧ�ľ��Ƕ��ٸ�����
        process_count = 0;
        if (memcpy_s(apps[num].app, DATA_BUF_F64_SIZE, app_info[num].name, strlen(app_info[num].name)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_array: app failed!\n");
        }
        if (memcpy_s(apps[num].version, DATA_BUF_F32_SIZE, app_info[num].version, strlen(app_info[num].version)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_array: version failed!\n");
        }
        if (memcpy_s(apps[num].appHash, DATA_BUF_F64_SIZE, app_info[num].hash, strlen(app_info[num].hash)) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_array: appHash failed!\n");
        }
        for (i = 0; i < APP_MANAGEMENT_APP_SERVICE_MAX; i++) {  // ��Ҫ����ʵ�ʽ��������ǲ������������жϻ�ȡ������
            if (strlen(app_info[num].services[i].name) != 0) {
                process_count++;
            } else {
                break;
            }
        }
        apps[num].srvNumber = process_count;     // ��ǰAPP�Ľ�������
        if (sg_get_apps_process(apps[num].process, process_count, app_info[num].services) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_apps_process failed!\n");
            ret = VOS_ERR;
        }
    }
    *app_max = apps;
    return ret;
}

// Ӧ�ÿ���ѡ��
int sg_app_select_control(char *type, APPM_OPERATION_PARA *para)
{
    int ret = VOS_OK;
    appm_error_message errmsg;
    (void)memset_s(&errmsg, sizeof(appm_error_message), 0, sizeof(appm_error_message));
    if (strncmp(type, CMD_APP_START, strlen(CMD_APP_START)) == 0) {
        ret = app_management_action_call_app_start(para, &errmsg);
    } else if (strncmp(type, CMD_APP_STOP, strlen(CMD_APP_STOP)) == 0) {
        ret = app_management_action_call_app_stop(para, &errmsg);
    } else if (strncmp(type, CMD_APP_REMOVE, strlen(CMD_APP_REMOVE)) == 0) {
        ret = app_management_action_call_app_uninstall(para, &errmsg);
    } else if (strncmp(type, CMD_APP_ENABLE, strlen(CMD_APP_ENABLE)) == 0) {
        ret = app_management_action_call_app_enable(para, &errmsg);
    } else if (strncmp(type, CMD_APP_UNENABLE, strlen(CMD_APP_UNENABLE)) == 0) {
        ret = app_management_action_call_app_disable(para, &errmsg);
    }
    return ret;
}
// app״̬��ѯ����ϱ�
void sg_push_item_app_status(char *type, uint16_t code, int32_t mid, const char *errormsg,
    app_inq_reply_s *statusobj)
{
    mqtt_data_info_s *item = NULL;
    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_handle_app_status_get:item is NULL\n");
        return;
    }
    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));

    if (strncmp(type, REP_APP_STATUS, strlen(REP_APP_STATUS)) == 0) {            // �豸״̬�ϱ�
        if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_data_pub()) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic error.\n");
        }
    } else if (strncmp(type, CMD_APP_STATUS, strlen(CMD_APP_STATUS)) == 0) {            // �豸״̬��ѯ����
        if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_reply_pub()) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "item->pub_topic error.\n");
        }
    }

    sg_pack_app_status_get_reply(type, code, mid, errormsg, statusobj, item->msg_send);
    sg_push_pack_item(item);
}

