#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "errno.h"

#include "securec.h"
#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "ssp_mid.h"
#include "sgdev_struct.h"
#include "sgdev_debug.h"
#include "sgdev_list.h"

sgdevagent_install_list_s **g_node_install_list = NULL;
unsigned int g_node_install_total_number = 0;

#define MAX_CONTAINER_INSTALL_HASH_NUMS 10

int sg_node_list_init(void)
{
    if (g_node_install_list == NULL) {
        g_node_install_list = (sgdevagent_install_list_s **)VOS_Malloc(MID_SGDEV,
            MAX_CONTAINER_INSTALL_HASH_NUMS * sizeof(sgdevagent_install_list_s *));
    }

    if (g_node_install_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "failed to init container list.\n");
        return VOS_ERR;
    }

    (void)memset_s(g_node_install_list, MAX_CONTAINER_INSTALL_HASH_NUMS * sizeof(sgdevagent_install_list_s *),
        0, MAX_CONTAINER_INSTALL_HASH_NUMS * sizeof(sgdevagent_install_list_s *));
    return VOS_OK;
}

void sg_node_list_exit(void)
{
    unsigned int idx = 0;
    sgdevagent_install_list_s *curhash = NULL;
    sgdevagent_install_list_s *nexthash = NULL;
    if (g_node_install_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid container status list parameter.\n");
        return;
    }

    for (idx = 0; idx < MAX_CONTAINER_INSTALL_HASH_NUMS; idx++) {
        curhash = g_node_install_list[idx];
        while (curhash != NULL) {
            nexthash = curhash->next;
            (void)VOS_Free((void *)curhash);
            curhash = nexthash;
        }
        g_node_install_list[idx] = NULL;
    }

    (void)VOS_Free((void *)g_node_install_list);
    g_node_install_list = NULL;
}

// ���� keyֵ
// �����±�
unsigned int sg_node_list_callhash(const unsigned char *key)
{
    unsigned int seed = 131;
    unsigned int hash = 0;
    while (*key) {
        hash = hash * seed + (*key++);
    }

    return (hash & 0x7FFFFFFF) % MAX_CONTAINER_INSTALL_HASH_NUMS;
}

sgdevagent_install_list_s *sg_node_list_findhash(const unsigned char *key)
{
    unsigned int idx;
    sgdevagent_install_list_s *entry = NULL;
    if (key == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid input hash key parameter.\n");
        return NULL;
    }

    if (g_node_install_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid container status list parameter.\n");
        return NULL;
    }

    idx = sg_node_list_callhash(key);
    entry = g_node_install_list[idx];
    while (entry) {
        if (strcmp((char *)entry->info_item.seriaNumber, (char *)key) == 0) {
            return entry;
        }
        entry = entry->next;
    }
    return NULL;
}

int sg_node_list_add_install(sgdevagent_install_list_s *devNode)
{
    unsigned int idx = 0;
    sgdevagent_install_list_s *entry = NULL;
    sgdevagent_install_list_s *node = NULL;
    sgdevagent_install_list_s *newhash = NULL;

    errno_t err = EOK;

    if (devNode == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid node parameter.\n");
        return VOS_ERR;
    }

    if (g_node_install_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid container status list parameter.\n");
        return VOS_ERR;
    }

    node = sg_node_list_findhash(devNode->info_item.seriaNumber);
    if (node == NULL) {
        newhash = (sgdevagent_install_list_s*)VOS_Malloc(MID_SGDEV, sizeof(sgdevagent_install_list_s));
        if (newhash == NULL) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "failed to create new hash.\n");
            return VOS_ERR;
        }
        err = memcpy_s(&newhash->info_item, sizeof(sgdevagent_info_list_s), devNode, sizeof(sgdevagent_info_list_s));
        if (err != EOK) {
            (void)VOS_Free(newhash);
            return VOS_ERR;
        }
        idx = sg_node_list_callhash(newhash->info_item.seriaNumber);
        entry = g_node_install_list[idx];
        newhash->next = entry;
        g_node_install_list[idx] = newhash;
        g_node_install_total_number++;
    } else {
        err = memcpy_s(&node->info_item, sizeof(sgdevagent_info_list_s), devNode, sizeof(sgdevagent_info_list_s));
        if (err != EOK) {
            return VOS_ERR;
        }
    }

    return VOS_OK;
}

int sg_node_list_delete_install(const unsigned char *nodeId, sgdevagent_install_list_s *devNode)
{
    unsigned int idx;
    sgdevagent_install_list_s *node = NULL;
    sgdevagent_install_list_s *entry = NULL;
    errno_t err = EOK;

    if (nodeId == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid input hash key parameter.\n");
        return VOS_ERR;
    }

    if (g_node_install_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid container status list parameter.\n");
        return VOS_ERR;
    }

    node = sg_node_list_findhash(nodeId);
    if (node == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sgdevagent not find nodeId = %s.\n", nodeId);
        return VOS_ERR;
    }
    idx = sg_node_list_callhash(nodeId);
    entry = g_node_install_list[idx];
    if (node == entry) {
        if (devNode != NULL) {
            err = memcpy_s(devNode, sizeof(sgdevagent_info_list_s), &entry->info_item, sizeof(sgdevagent_info_list_s));
            if (err != EOK) {
                return VOS_ERR;
            }
        }

        g_node_install_list[idx] = node->next;
        g_node_install_total_number--;
        (void)VOS_Free(entry);
        return VOS_OK;
    }

    while (node != entry->next) {
        entry = entry->next;
    }

    entry->next = node->next;
    if (devNode != NULL) {
        err = memcpy_s(devNode, sizeof(sgdevagent_info_list_s), &node->info_item, sizeof(sgdevagent_info_list_s));
        if (err != EOK) {
            return VOS_ERR;
        }
    }
    g_node_install_total_number--;
    (void)VOS_Free(node);
    return VOS_OK;
}
unsigned int sg_node_list_get_all_item(sgdevagent_install_list_s *devNode, unsigned int nodeNum)
{
    unsigned int nodeidx = 0;
    unsigned int idx = 0;
    errno_t err = EOK;
    sgdevagent_install_list_s *entry = NULL;
    if (devNode == NULL || nodeNum == 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid input get all item parameter.\n");
        return VOS_ERR;
    }

    if (g_node_install_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid container status list parameter.\n");
        return VOS_ERR;
    }

    for (idx = 0; idx < MAX_CONTAINER_INSTALL_HASH_NUMS; idx++) {
        entry = g_node_install_list[idx];
        while ((entry != NULL) && (nodeNum > 0)) {
            err = memcpy_s(&devNode[nodeidx], sizeof(sgdevagent_info_list_s),
                &entry->info_item, sizeof(sgdevagent_info_list_s));
            if (err != EOK) {
                return VOS_ERR;
            }
            nodeidx++;
            entry = entry->next;
            nodeNum--;
        }
    }
    return nodeidx;
}

int sg_node_list_get_item_by_nodeId(const unsigned char *nodeId, sgdevagent_install_list_s* devNode)
{
    unsigned int idx;
    sgdevagent_install_list_s *entry = NULL;
    if (nodeId == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid input hash key parameter.\n");
        return VOS_ERR;
    }

    if (g_node_install_list == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "invalid container status list parameter.\n");
        return VOS_ERR;
    }

    idx = sg_node_list_callhash(nodeId);
    entry = g_node_install_list[idx];
    while (entry != NULL) {
        if (strcmp((char *)entry->info_item.seriaNumber, (char *)nodeId) == 0) {
            err = memcpy_s((void *)devNode, sizeof(sgdevagent_info_list_s),
                &entry->info_item, sizeof(entry->info_item));
            if (err != EOK) {
                return VOS_ERR;
            }
            return VOS_OK;
        }
        entry = entry->next;
    }
    return VOS_ERR;
}

unsigned int sg_node_list_get_item_number(void)
{
    return g_node_install_total_number;
}

int sg_node_list_add_install_app(app_install_cmd_s *cmd, char *errmsg)
{
    sgdevagent_info_list_s devNode;
    (void)memset_s(&devNode, sizeof(sgdevagent_info_list_s), 0, sizeof(sgdevagent_info_list_s));
    devNode.type = LIST_APP_INSTALL;
    devNode.app_install_info = *cmd;
    if (sprintf_s((char *)devNode.seriaNumber, DATA_BUF_F32_SIZE, "%d", cmd->jobId)) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s jobid to temp err.\n");
        return VOS_ERR;
    }
    
    if (sg_node_list_add_install(&devNode) != VOS_OK) {
        if (sprintf_s(errmsg, DATA_BUF_F256_SIZE, "%s", "app install policy failed") < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s policy err.\n");
        }
        return VOS_ERR;
    }
    return VOS_OK;
}

