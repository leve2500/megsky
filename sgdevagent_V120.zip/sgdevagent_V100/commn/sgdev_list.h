/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent list header file
*/

#ifndef __SGDEV_LIST_H__
#define __SGDEV_LIST_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    LIST_NULL = 0,
    LIST_CONTINER_INSTALL = 1,
    LIST_CONTINER_UPGRADE = 2,
    LIST_DEVICE_UPGRADE = 3,
    LIST_APP_INSTALL = 4,
    LIST_APP_UPGRADE = 5,
    LIST_NUM
} install_list_type_t;

typedef struct sgdevagent_info_list {
    int             type;
    unsigned char seriaNumber[DATA_BUF_F32_SIZE + 1];
    container_install_cmd_s    sgdevagent_install_list_s;
    container_upgrade_cmd_s    container_upgrade_info;
    device_upgrade_s           device_upgrade_info;
    app_install_cmd_s          app_install_info;
    app_upgrade_cmd_s          app_upgrade_info;
}sgdevagent_info_list_s;

typedef struct sgdevagent_install_list {
    sgdevagent_info_list_s        info_item;
    struct sgdevagent_install_list *next;
}sgdevagent_install_list_s;

int sg_node_list_init(void);
void sg_node_list_exit(void);
unsigned int sg_node_list_callhash(const unsigned char *key);
sgdevagent_install_list_s *sg_node_list_findhash(const unsigned char *key);
int sg_node_list_add_install(sgdevagent_install_list_s *devnode);
int sg_node_list_delete_install(const unsigned char *nodeId, sgdevagent_install_list_s *devNode);
unsigned int  sg_node_list_get_all_item(sgdevagent_install_list_s *devNode, unsigned int nodeNum);
int sg_node_list_get_item_by_nodeId(const unsigned char *nodeId, sgdevagent_install_list_s *devNode);
unsigned int sg_node_list_get_item_number(void);
int sg_node_list_add_install_app(app_install_cmd_s *cmd, char *errmsg);

#ifdef __cplusplus
}
#endif

#endif