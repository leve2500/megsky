#include <sys/times.h>
#include <unistd.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "vrp_task.h"
#include "ssp_mid.h"
#include "net_common.h"
#include "ifm_status.h"

#include "sysman_devinfo_def.h"
#include "sysman_rpc_api.h"
#include "securec.h"

#include "sgdev_struct.h"
#include "sgdev_queue.h"
#include "sgdev_mutex.h"
#include "sgdev_debug.h"
#include "sgdev_param.h"
#include "upmqtt_dev.h"
#include "upmqtt_json.h"
#include "upmqtt_pub.h"
#include "task_link.h"
#include "task_dev.h"
#include "task_deal.h"
#include "thread_manage.h"
#include "thread_interact.h"
#include "thread_dev_insert.h"

int g_dev_access_flag = 0;
unsigned int  g_create_dev_ins_id = 0;
unsigned int  g_create_poly_ins_id = 0;
list_dev_upgrade_info_s g_dev_info = { 0 };

int sg_poly_thread(void);           // 延时任务处理
int sg_dev_insert_thread(void);     // 设备接入线程


void sg_set_list_dev_upgrade_info(int32_t mid, device_upgrade_s *info)
{
    g_dev_info.mid = mid;
    g_dev_info.dev_flag = 1;
    g_dev_info.info = *info;
    g_dev_info.time_info.m_dw_diff_param = info->policy * MS_CONVERSION_INTERNAL;
}

static void sg_poly_dev_install_cmd(int32_t mid)
{
    char errormsg[DATA_BUF_F256_SIZE] = { 0 };
    dev_status_reply_s status;
    (void)memset_s(&status, sizeof(dev_status_reply_s), 0, sizeof(dev_status_reply_s));
    dev_upgrede_res_reply_s reply_status;
    (void)memset_s(&reply_status, sizeof(dev_upgrede_res_reply_s), 0, sizeof(dev_upgrede_res_reply_s));

    reply_status.code = REQUEST_SUCCESS;
    reply_status.jobId = g_dev_info.info.jobId;
    status.state = STATUS_EXE_INSTALL;
    set_device_upgrade_status(status); // 设置开始状态

    if (sg_dev_install(&g_dev_info.info, errormsg) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "device upgrade failed.\n");
        sg_execute_result_report(TAG_CMD_SYS_UPGRADE, errormsg, reply_status);
    }

    sg_write_section_file(1, g_dev_info.info.jobId, mid, g_dev_info.info.version);
}

int sg_init_insert_thread(void)
{
    int i_ret = VOS_OK;
    unsigned int ret = 0;
    ret = VOS_T_Create(SG_DEVICE_INSERT_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
        (TaskStartAddress_PF)sg_dev_insert_thread, &g_create_dev_ins_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) create failed ret:%d.\n", SG_DEVICE_INSERT_NAME, ret);
        i_ret = VOS_ERR;
    }

    ret = VOS_T_Create(SG_POLY_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
        (TaskStartAddress_PF)sg_poly_thread, &g_create_poly_ins_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) creat failed ret:%d.\n", SG_POLY_TASK_NAME, ret);
        return VOS_ERR;
    }

    return i_ret;
}

int sg_exit_insert_thread(void)
{
    int i_ret = VOS_OK;
    unsigned int ret = 0;
    ret = VOS_T_Delete(g_create_dev_ins_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%d.\n", SG_DEVICE_INSERT_NAME, ret);
        i_ret = VOS_ERR;
    }

    ret = VOS_T_Delete(g_create_poly_ins_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%d.\n", SG_POLY_TASK_NAME, ret);
        return VOS_ERR;
    }

    return i_ret;
}

// g_dev_access_flag 的判断 如果是rmtman 则增加判断其是否与平台已经连接,未连接则continue
// 检测到离线就发送上线
int sg_dev_insert_thread(void)
{
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_dev_insert_thread start.\n");
    int ret                 = VOS_OK;
    int connect_flag        = 0;
    mqtt_data_info_s *item  = NULL;
    dev_acc_req_s devinfo;
    (void)memset_s(&devinfo, sizeof(dev_acc_req_s), 0, sizeof(dev_acc_req_s));
    sg_dev_param_info_s param;
    (void)memset_s(&param, sizeof(sg_dev_param_info_s), 0, sizeof(sg_dev_param_info_s));
    sg_get_param(&param);

    for (;;) {
        if (param.startmode == MODE_RMTMAN) {
            connect_flag = sg_get_rmt_connect_flag();
        } else {
            connect_flag = sg_get_mqtt_connect_flag();
        }

        if (connect_flag == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_THREAD_CONNECT_WAIT);
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt or socket link not connect.\n");
            continue;
        }
        if (g_dev_access_flag != DEVICE_ONLINE) {
            item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
            if (item == NULL) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_dev_insert_thread:mqtt_data_info_s malloc failed.\n");
                break;
            }

            (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
            if (sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_request_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_dev_insert_thread:sprintf_s, pub topic failed.\n");
                break;
            }

            if (sg_get_dev_insert_info(&devinfo) != VOS_OK) {                      // 获取设备接入信息
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get device info failed.\n");
            }

            sg_pack_dev_linkup_data(&devinfo, item->msg_send);              // 将设备接入信息打包为json格式
            sg_push_pack_item(item);              // 入列
        }

        VOS_T_Delay(MS_THREAD_CONNECT_WAIT);        // 延时10秒
    }
    return ret;
}
// 设备升级
// 容器安装
// 容器升级
// app安装
// app升级
int sg_poly_thread(void)
{
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_poly_thread start.\n");
    time_cnt_info_s info = { 0 };
    (void)memset_s(&info, sizeof(time_cnt_info_s), 0, sizeof(time_cnt_info_s));
    size_t i = 0;

    for (;;) {
        if (sg_calover_time(&g_dev_info.time_info)) {
            g_dev_info.dev_flag = 0;
            sg_poly_dev_install_cmd(g_dev_info.mid);
        }

        for (i = 0; i < 1; i++) {       // 获取表中的参数
            if (sg_calover_time(&info)) {             // info.m_dw_diff_param = 20;
                // 执行
            }
        }

        VOS_T_Delay(MS_CONVERSION_INTERNAL);        // 延时1秒
    }
}

int sg_get_dev_ins_flag(void)
{
    return g_dev_access_flag;
}

void sg_set_dev_ins_flag(int flag)
{
    g_dev_access_flag = flag;    // 上线、离线通知   发socket通知
    SGDEV_INFO (SYSLOG_LOG, SGDEV_MODULE, "device online flag = %d.\n", g_dev_access_flag);
}

void sg_start_count(time_cnt_info_s *info)
{
    struct tms ctm;
    info->m_b_valid_flag = true;
    info->m_dw_last_count = times(&ctm);
}

void sg_stop_count(time_cnt_info_s *info)
{
    info->m_b_valid_flag = false;
}

bool sg_calover_time(time_cnt_info_s *info)
{
    bool ret = false;
    if (info->m_b_valid_flag) {
        long clktck = sysconf(_SC_CLK_TCK);
        struct tms ctm;
        clock_t dw_cur_cnt = times(&ctm);
        if (clktck == 0) {
            return false;
        }
        unsigned long tmp_inter = (unsigned long)(dw_cur_cnt - info->m_dw_last_count);
        uint32_t dw_span = (uint32_t)((tmp_inter * MS_CONVERSION_INTERNAL) / ((uint32_t)clktck));
        if (dw_span >= info->m_dw_diff_param) {
            ret = true;
        }
    }

    return ret;
}
