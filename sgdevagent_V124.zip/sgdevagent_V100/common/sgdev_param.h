/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent param header file
*/

#ifndef __SGDEV_PARAM_H__
#define __SGDEV_PARAM_H__

#include "sgdev_struct.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PERIOD_PARAMS_FILEPATH "/mnt/internal_storage/sg_period_params"
#define DEV_SECTION_FILEPATH "/mnt/internal_storage/sg_devagentsection"
#define DEV_PARAMS_FILEPATH "/mnt/internal_storage/sg_devagentparams"

int sg_get_file_size(char *strFileName);
int sg_read_section_file(sg_dev_section_info_s *info);
void sg_write_section_file(uint8_t reboot_reason, int32_t jobId, int32_t midId, char *version);
int sg_read_period_file(void);
void sg_write_period_file(rep_period_s *paraobj);
int sg_read_param_file(void);

void sg_get_param(sg_dev_param_info_s *devParam);
void sg_get_period(sg_period_info_s *devperiod);

#ifdef __cplusplus
}
#endif

#endif
