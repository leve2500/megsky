#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "vrp_queue.h"
#include "vrp_task.h"

#include "securec.h"
#include "ssp_mid.h"

#include "sgdev_struct.h"
#include "sgdev_param.h"
#include "sgdev_queue.h"
#include "sgdev_debug.h"
#include "upmqtt_json.h"
#include "upmqtt_json.h"
#include "upmqtt_app.h"
#include "upmqtt_dev.h"
#include "upmqtt_container.h"
#include "task_deal.h"
#include "thread_manage.h"
#include "thread_dev_insert.h"
#include "thread_task_exe.h"


unsigned int g_create_tsk_exe_dev_id = 0;
unsigned int g_create_tsk_exe_con_id = 0;
unsigned int g_create_tsk_exe_app_id = 0;

int sg_task_execution_dev_thread(void);
int sg_task_execution_container_thread(void);
int sg_task_execution_app_thread(void);

// 设备升级
static void sg_deal_dev_install_cmd(int32_t mid, char *param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load equipment upgrade json(%s) failed.\n", param);
        return;
    }

    device_upgrade_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(device_upgrade_s), 0, sizeof(device_upgrade_s));
    if (sg_unpack_dev_install_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_dev_install_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 设备管理参数修改命令
static void sg_deal_dev_set_para_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load equipment parameters modification json(%s) failed.\n", param);
        return;
    }

    dev_man_conf_command_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(dev_man_conf_command_s), 0, sizeof(dev_man_conf_command_s));
    if (VOS_OK == sg_unpack_dev_set_para_cmd(json_param, &cmd_obj)) {
        sg_handle_dev_set_para_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 设备时间同步命令
static void sg_deal_dev_set_time_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load device time synchronization cmd json(%s) failed.\n", param);
        return;
    }

    dev_time_command_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(dev_time_command_s), 0, sizeof(dev_time_command_s));
    if (sg_unpack_dev_set_time_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_dev_set_time_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 设备日志召回
static void sg_deal_dev_log_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load equipment log recall json(%s) failed.\n", param);
        return;
    }

    dev_log_recall_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(dev_log_recall_s), 0, sizeof(dev_log_recall_s));
    if (sg_unpack_dev_log_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_dev_log_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 设备控制命令
static void sg_deal_dev_ctrl_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load device control commands json(%s) failed.\n", param);
        return;
    }

    char cmd_obj[DATA_BUF_F128_SIZE] = {0};
    if (sg_unpack_dev_ctrl_cmd(json_param, cmd_obj) == VOS_OK) {
        sg_handle_dev_ctrl_cmd(mid, cmd_obj);
    }
    json_decref(json_param);
}

// 容器安装控制
static void sg_deal_container_install_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load container installation control json(%s) failed.\n", param);
        return;
    }

    container_install_cmd_s cmd_obj = { 0 };
    (void)memset_s(&cmd_obj, sizeof(container_install_cmd_s), 0, sizeof(container_install_cmd_s));
    if (sg_unpack_container_install_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_container_install_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 容器启动
static void sg_deal_container_start_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load container start json(%s) failed.\n", param);
        return;
    }

    char container_name[DATA_BUF_F128_SIZE] = { 0 };
    if (sg_unpack_container_control_cmd(json_param, container_name) == VOS_OK) {
        sg_handle_container_control_cmd(CMD_CON_START, mid, container_name);
    }
    json_decref(json_param);
}

// 容器停止
static void sg_deal_container_stop_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load container stop json(%s) failed.\n", param);
        return;
    }

    char container_name[DATA_BUF_F128_SIZE] = { 0 };
    if (sg_unpack_container_control_cmd(json_param, container_name) == VOS_OK) {
        sg_handle_container_control_cmd(CMD_CON_STOP, mid, container_name);
    }
    json_decref(json_param);
}

// 容器删除
static void sg_deal_container_remove_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load container remove json(%s) failed.\n", param);
        return;
    }

    char container_name[DATA_BUF_F128_SIZE] = { 0 };
    if (sg_unpack_container_control_cmd(json_param, container_name) == VOS_OK) {
        sg_handle_container_control_cmd(CMD_CON_REMOVE, mid, container_name);
    }
    json_decref(json_param);
}

// 容器配置修改
static void sg_deal_container_param_set_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load container configuration modification json(%s) failed.\n", param);
        return;
    }

    container_conf_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(container_conf_cmd_s), 0, sizeof(container_conf_cmd_s));
    if (sg_unpack_container_param_set_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_container_param_set_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 容器升级
static void sg_deal_container_upgrade_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load container upgrade json(%s) failed.\n", param);
        return;
    }
    container_upgrade_cmd_s cmd_obj = { 0 };
    (void)memset_s(&cmd_obj, sizeof(container_upgrade_cmd_s), 0, sizeof(container_upgrade_cmd_s));
    if (sg_unpack_container_upgrade_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_container_upgrade_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 容器日志召回命令
static void sg_deal_container_log_get_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load container log recall json(%s) failed.\n", param);
        return;
    }

    container_log_recall_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(container_log_recall_cmd_s), 0, sizeof(container_log_recall_cmd_s));
    if (sg_unpack_container_log_get_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_container_log_get_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 应用安装
static void sg_deal_app_install_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app install json(%s) failed.\n", param);
        return;
    }

    app_install_cmd_s cmd_obj = { 0 };
    (void)memset_s(&cmd_obj, sizeof(app_install_cmd_s), 0, sizeof(app_install_cmd_s));
    if (sg_unpack_app_install_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_install_cmd(mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 应用启动
static void sg_deal_app_start_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app start json(%s) failed.\n", param);
        return;
    }
    
    app_control_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(app_control_cmd_s), 0, sizeof(app_control_cmd_s));
    if (sg_unpack_app_control_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_control_cmd(CMD_APP_START, mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 应用停止
static void sg_deal_app_stop_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app stop json(%s) failed.\n", param);
        return;
    }

    app_control_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(app_control_cmd_s), 0, sizeof(app_control_cmd_s));
    if (sg_unpack_app_control_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_control_cmd(CMD_APP_STOP, mid, &cmd_obj);
    }

    json_decref(json_param);
}

// 应用卸载
static void sg_deal_app_uninstall_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app uninstall json(%s) failed.\n", param);
        return;
    }

    app_control_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(app_control_cmd_s), 0, sizeof(app_control_cmd_s));
    if (sg_unpack_app_control_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_control_cmd(CMD_APP_REMOVE, mid, &cmd_obj);
    }
    json_decref(json_param);
}

// 应用使能
static void sg_deal_app_enble_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app enble json(%s) failed.\n", param);
        return;
    }

    app_control_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(app_control_cmd_s), 0, sizeof(app_control_cmd_s));
    if (sg_unpack_app_control_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_control_cmd(CMD_APP_ENABLE, mid, &cmd_obj);
    }

    json_decref(json_param);
}

// 应用去使能
static void sg_deal_app_unenble_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app unenble json(%s) failed.\n", param);
        return;
    }

    app_control_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(app_control_cmd_s), 0, sizeof(app_control_cmd_s));
    if (sg_unpack_app_control_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_control_cmd(CMD_APP_UNENABLE, mid, &cmd_obj);
    }

    json_decref(json_param);
}

// 应用配置修改命令
static void sg_deal_app_param_set_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app param set json(%s) failed.\n", param);
        return;
    }

    app_conf_cmd_s cmd_obj;
    (void)memset_s(&cmd_obj, sizeof(app_conf_cmd_s), 0, sizeof(app_conf_cmd_s));
    if (sg_unpack_app_param_set_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_param_set_cmd(mid, &cmd_obj);
    }

    json_decref(json_param);
}

// 应用配置状态查询命令
static void sg_deal_app_param_config_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app param inquire json(%s) failed.\n", param);
        return;
    }

    char container_name[DATA_BUF_F128_SIZE] = { 0 };
    if (sg_unpack_app_param_get(json_param, container_name) == VOS_OK) {
        sg_handle_app_param_get(mid, container_name);
    }

    json_decref(json_param);
}

// 应用状态查询命令
static void sg_deal_app_param_status_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app status inquire json(%s) failed.\n", param);
        return;
    }

    char container_name[DATA_BUF_F128_SIZE] = { 0 };
    if (sg_unpack_app_status_get(json_param, container_name) == VOS_OK) {
        sg_handle_app_status_get(CMD_APP_STATUS, mid, container_name);
    }

    json_decref(json_param);
}

// app升级命令
static void sg_deal_app_upgrade_cmd(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app upgrade json(%s) failed.\n", param);
        return;
    }

    app_upgrade_cmd_s cmd_obj = { 0 };
    if (sg_unpack_app_upgrade_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_upgrade_cmd(mid, &cmd_obj);
    }

    json_decref(json_param);
}

// 应用日志召回命令
static void sg_deal_app_log_get_reply(int32_t mid, char* param)
{
    json_t *json_param = NULL;
    if (param == NULL) {
        return;
    }

    json_param = load_json(param);
    if (json_param == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "load app log recall json(%s) failed.\n", param);
        return;
    }
    app_log_recall_cmd_s cmd_obj;
    if (sg_unpack_app_log_get_cmd(json_param, &cmd_obj) == VOS_OK) {
        sg_handle_app_log_get_cmd(mid, &cmd_obj);
    }

    json_decref(json_param);
}

static void sg_task_pro_dev(uint32_t type, int32_t mid, char* param)
{
    switch (type) {
        case TAG_CMD_SYS_UPGRADE:       //设备升级
            sg_deal_dev_install_cmd(mid, param);
            break;
        case TAG_CMD_SYS_STATUS:			//设备状态查询命令
            sg_handle_dev_inquire_reply(CMD_SYS_STATUS, 0);
            break;
        case TAG_CMD_INFO_QUERY:        //设备信息查询命令
            sg_handle_dev_info_cmd(mid);
            break;
        case TAG_CMD_SYS_SET_CONFIG:        //设备管理参数修改命令
            sg_deal_dev_set_para_cmd(mid, param);
            break;
        case TAG_CMD_DATETIME_SYN:      //设备时间同步命令
            sg_deal_dev_set_time_cmd(mid, param);
            break;
        case TAG_CMD_SYS_LOG:               //设备日志召回
            sg_deal_dev_log_cmd(mid, param);
            break;
        case TAG_CMD_CTRL:      //设备控制命令
            sg_deal_dev_ctrl_cmd(mid, param);
            break;
        case TAG_CMD_CON_GET_CONFIG:        //容器配置查询命令
            sg_handle_container_param_get(mid);
            break;
        case TAG_CMD_CON_STATUS:        //容器状态查询命令
            sg_handle_container_status_get(CMD_CON_STATUS, mid);
            break;
        case TAG_CMD_APP_GET_CONFIG:        //应用配置查询命令
            sg_deal_app_param_config_cmd(mid, param);
            break;
        case TAG_CMD_APP_STATUS:        //应用状态查询命令
            sg_deal_app_param_status_cmd(mid, param);
            break;
        default:
            break;
    }
}

static void sg_task_pro_container(uint32_t type, int32_t mid, char* param)
{
    switch (type) {
        case TAG_CMD_CON_INSTALL:          //容器安装控制命令
            sg_deal_container_install_cmd(mid, param);
            break;
        case TAG_CMD_CON_START:             //容器启动控制命令
            sg_deal_container_start_cmd(mid, param);
            break;
        case TAG_CMD_CON_STOP:              //容器停止控制命令
            sg_deal_container_stop_cmd(mid, param);
            break;
        case TAG_CMD_CON_REMOVE:            //容器删除控制
            sg_deal_container_remove_cmd(mid, param);
            break;
        case TAG_CMD_CON_SET_CONFIG:        //容器配置修改命令
            sg_deal_container_param_set_cmd(mid, param);
            break;
        case TAG_CMD_CON_UPGRADE:           //容器升级命令
            sg_deal_container_upgrade_cmd(mid, param);
            break;
        case TAG_CMD_CON_LOG:               //容器日志召回命令
            sg_deal_container_log_get_cmd(mid, param);
            break;
        default:
            break;
    }
}

static void sg_task_pro_app(uint32_t type, int32_t mid, char* param)
{
    switch (type) {
        case TAG_CMD_CON_LOG:               //应用安装控制命令
            sg_deal_app_install_cmd(mid, param);
            break;
        case TAG_CMD_APP_START:             //应用启动
            sg_deal_app_start_cmd(mid, param);
            break;
        case TAG_CMD_APP_STOP:              //应用停止
            sg_deal_app_stop_cmd(mid, param);
            break;
        case TAG_CMD_APP_REMOVE:            //应用卸载
            sg_deal_app_uninstall_cmd(mid, param);
            break;
        case TAG_CMD_APP_ENABLE:            //应用使能
            sg_deal_app_enble_cmd(mid, param);
            break;
        case TAG_CMD_APP_UNENABLE:          //去使能
            sg_deal_app_unenble_cmd(mid, param);
            break;
        case TAG_CMD_APP_SET_CONFIG:        //应用配置修改命令
            sg_deal_app_param_set_cmd(mid, param);
            break;
        case TAG_CMD_APP_UPGRADE:           //app升级命令
            sg_deal_app_upgrade_cmd(mid, param);
            break;
        case TAG_CMD_APP_LOG:               //应用日志召回命令
            sg_deal_app_log_get_reply(mid, param);
            break;
        default:
            break;
    }
}

int sg_init_exe_thread(void)
{
    int i_ret = VOS_OK;
    unsigned int ret = 0;
    ret = VOS_T_Create(SG_DEVICE_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
        (TaskStartAddress_PF)sg_task_execution_dev_thread, &g_create_tsk_exe_dev_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) creat failed ret:%u.\n", SG_DEVICE_TASK_NAME, ret);
        i_ret = VOS_ERR;
    }

    ret = VOS_T_Create(SG_CONTAINER_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
        (TaskStartAddress_PF)sg_task_execution_container_thread, &g_create_tsk_exe_con_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) creat failed ret:%u.\n", SG_CONTAINER_TASK_NAME, ret);
        i_ret = VOS_ERR;
    }

    ret = VOS_T_Create(SG_APP_TASK_NAME, VOS_T_PRIORITY_NORMAL, 0, 0, NULL,
        (TaskStartAddress_PF)sg_task_execution_app_thread, &g_create_tsk_exe_app_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) creat failed ret:%u.\n", SG_APP_TASK_NAME, ret);
        return VOS_ERR;
    }

    return i_ret;
}

int sg_exit_exe_thread(void)
{
    int i_ret = VOS_OK;
    unsigned int ret = 0;
    ret = VOS_T_Delete(g_create_tsk_exe_dev_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%u.\n", SG_DEVICE_TASK_NAME, ret);
        i_ret = VOS_ERR;
    }

    ret = VOS_T_Delete(g_create_tsk_exe_con_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%u.\n", SG_CONTAINER_TASK_NAME, ret);
        i_ret = VOS_ERR;
    }

    ret = VOS_T_Delete(g_create_tsk_exe_app_id);
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "task(%s) destroy failed ret:%u.\n", SG_APP_TASK_NAME, ret);
        return VOS_ERR;
    }

    return i_ret;
}

// 任务执行线程 设备及查询类线程函数
int sg_task_execution_dev_thread(void)
{
    int connect_flag = 0;
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_task_execution_dev_thread start.\n");
    uint32_t dev_queue_id = sg_get_que_dev_id();
    VOS_UINTPTR msg[VOS_QUEUE_MSG_NUM] = { 0 };
    sg_dev_section_info_s paramcfg;

    char* param = NULL;
    for (;;) {
        connect_flag = sg_get_link_connect_flag();
        if (connect_flag == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_EXECUTE_THREAD_CONNECT_WAIT);
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_task_execution_dev_thread :link disconnected.\n");
            continue;
        }

        if (sg_get_dev_ins_flag() == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_EXECUTE_THREAD_CONNECT_WAIT);
            continue;
        }

        if (sg_read_section_file(&paramcfg) != VOS_OK) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "read section file failed.\n");
        } else if (paramcfg.reboot_reason == SG_DEV_UPDATE_SECTION_FLAG) {
            sg_handle_dev_install_section(&paramcfg);
            VOS_T_Delay(MS_EXECUTE_THREAD_CONNECT_WAIT);
            continue;
        }

        if (VOS_OK == VOS_Que_Read(dev_queue_id, msg, VOS_WAIT, 0)) {
            param = (char*)msg[VOS_QUEUE_MSG_INDEX_1];
            if (msg[VOS_QUEUE_MSG_INDEX_0] == QUEUE_DEVTASK) {
                sg_task_pro_dev(msg[VOS_QUEUE_MSG_INDEX_2], (int32_t)msg[VOS_QUEUE_MSG_INDEX_3], param);
            }
            if (param != NULL) {
                free(param);
            }
        }

        VOS_T_Delay(MS_HUNDRED_INTERVAL);
    }
}

// 容器操作类线程函数
int sg_task_execution_container_thread(void)
{
    int connect_flag = 0;
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_task_execution_container_thread start.\n");
    uint32_t container_queue_id = sg_get_que_container_id();      // 获取队列id
    VOS_UINTPTR msg[VOS_QUEUE_MSG_NUM] = { 0 };
    char* param = NULL;

    for (;;) {
        connect_flag = sg_get_link_connect_flag();
        if (connect_flag == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_EXECUTE_THREAD_CONNECT_WAIT);
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_task_execution_container_thread: link disconnected.\n");
            continue;
        }

        if (sg_get_dev_ins_flag() == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_EXECUTE_THREAD_CONNECT_WAIT);
            continue;
        }
        if (VOS_Que_Read(container_queue_id, msg, VOS_WAIT, 0) == VOS_OK) {
            param = (char*)msg[VOS_QUEUE_MSG_INDEX_1];
            if (msg[VOS_QUEUE_MSG_INDEX_0] == QUEUE_CONTAINERTASK) {
                sg_task_pro_container(msg[VOS_QUEUE_MSG_INDEX_2], (int32_t)msg[VOS_QUEUE_MSG_INDEX_3], param);
            }

            if (param != NULL) {
                free(param);
            }
        }

        VOS_T_Delay(MS_HUNDRED_INTERVAL);
    }
}

// app操作类线程函数
int sg_task_execution_app_thread(void)
{
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_task_execution_app_thread start.\n");
    uint32_t app_queue_id = sg_get_que_app_id();      // 获取队列id
    VOS_UINTPTR msg[VOS_QUEUE_MSG_NUM] = { 0 };
    char* param = NULL;
    int connect_flag = 0;

    for (;;) {
        connect_flag = sg_get_link_connect_flag();
        if (connect_flag == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_EXECUTE_THREAD_CONNECT_WAIT);
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_task_execution_app_thread: link disconnected .\n");
            continue;
        }

        if (sg_get_dev_ins_flag() == DEVICE_OFFLINE) {
            VOS_T_Delay(MS_EXECUTE_THREAD_CONNECT_WAIT);
            continue;
        }

        if (VOS_Que_Read(app_queue_id, msg, VOS_WAIT, 0) == VOS_OK) {
            param = (char*)msg[VOS_QUEUE_MSG_INDEX_1];
            if (msg[VOS_QUEUE_MSG_INDEX_0] == QUEUE_APPTASK) {
                sg_task_pro_app(msg[VOS_QUEUE_MSG_INDEX_2], (int32_t)msg[VOS_QUEUE_MSG_INDEX_3], param);
            }

            if (param != NULL) {
                free(param);
            }
        }

        VOS_T_Delay(MS_HUNDRED_INTERVAL);
    }
}
