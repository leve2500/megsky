
/*
 * Copyright��c��Huawei Technologies Co.,Ltd.2019-2020.All rights reserved
 * Description : sgdevagent container header file
*/


#ifndef __TASK_CONTAINER_H__
#define __TASK_CONTAINER_H__


#ifdef __cplusplus
extern "C" {
#endif

void sg_vos_free_container_info(INSTALL_OVA_PARA_NORTH_SG_S *install_info);
void sg_container_install_reply_frame(uint16_t code, int32_t mid, char *errormsg);
void sg_container_modify_reply_frame(uint16_t code, int32_t mid, char *errormsg);
int sg_container_install(container_install_cmd_s *cmd_obj, char *errmsg);
int sg_container_update(container_upgrade_cmd_s *cmd_obj, char *errmsg);
int sg_container_modify_north(container_conf_cmd_s *cmd_obj, char *errmsg);
int sg_set_container_modify_mount(char mount[][DATA_BUF_F256_SIZE], size_t mount_len,
    container_mount_dir_add_s *mount_info);
int sg_set_container_modify_dev(char dev[][DATA_BUF_F256_SIZE], size_t dev_len,
    install_map_dev *dev_info);
void sg_container_cpumask_to_cpucore(char *cpucore, unsigned len, long long cpu_mask);
int sg_get_port_map_info(container_conf_cmd_s *container_conf_cmd);
int sg_get_mount_dir(container_conf_cmd_s *container_conf_cmd);
int sg_get_container_device_list(container_conf_cmd_s *container_conf_cmd);
int sg_container_config_to_reply(container_config_reply_s *contiainer_config_reply, int container_num, 
        CONTAINER_INFO_S *container_list);
int sg_container_status_to_reply(container_status_reply_s *contiainer_status_reply, int container_num, 
        CONTAINER_INFO_S *container_list);
bool sg_container_select_control(char *type, char *container_name, char *errormsg);
// ����״̬��ѯ����ϱ�
void sg_push_item_container_status(char *type, uint16_t code, int32_t mid, const char *errormsg,
    container_status_reply_s *status);
void sg_policy_container_install(int32_t mid, container_install_cmd_s *obj);
#ifdef __cplusplus
}
#endif

#endif

