#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <limits.h>
#include <sys/sysinfo.h>
#include <sys/time.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "ssp_mid.h"
#include "ssp_syslog.h"
#include "net_common.h"
#include "ifm_status.h"
#include "vm_public.h"
#include "sysman_devinfo_def.h"
#include "sysman_rpc_api.h"
#include "securec.h"
#include "public_struct.h"
#include "sgdev_common.h"
#include "sgdev_struct.h"
#include "sgdev_debug.h"
#include "sgdev_param.h"
#include "sgdev_common.h"
#include "sgdev_curl.h"
#include "timer_pack.h"
#include "upmqtt_json.h"
#include "upmqtt_pub.h"
#include "upmqtt_dev.h"
#include "task_link.h"

int edge_reboot_flag = REBOOT_EDGE_RESET;

// ����ϱ�
void sg_execute_result_report(int type, char *errormsg, dev_upgrede_res_reply_s statusobj)
{
    mqtt_data_info_s *sitem = NULL;
    sitem = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    (void)memset_s(sitem, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (memcpy_s(statusobj.msg, DATA_BUF_F256_SIZE, errormsg, DATA_BUF_F256_SIZE) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_execute_result_report: msg failed!\n");
    }
    switch (type) {
        case TAG_CMD_SYS_UPGRADE:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_device_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_CON_INSTALL:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_CON_UPGRADE:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_container_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_APP_INSTALL:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        case TAG_CMD_APP_UPGRADE:
            if (sprintf_s(sitem->pub_topic, DATA_BUF_F256_SIZE, "%s", get_topic_app_data_pub()) < 0) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s pub_topic device_data_pub failed.\n");
            }
            break;
        default:
            break;
    }

    sg_pack_dev_install_result(statusobj, errormsg, sitem->msg_send);
    sg_push_pack_item(sitem);
}

// ��ȡ�ն�����
static int sg_get_devname(char *devName)
{
    int pos = 0;
    char Temp_str[DATA_BUF_F64_SIZE] = { 0 };

    if (sg_file_common_get(HOSTNAME_FILE, Temp_str) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get devName error!\n");
        return VOS_ERR;
    }

    pos = sg_find(Temp_str, (int)strlen(Temp_str), "\n", 1, 0);
    if (pos <= 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get pos error!\n");
        return VOS_ERR;
    }

    if (sg_str_left(Temp_str, (int)strlen(Temp_str), devName, pos) > 0) {
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "devName in = %s\n", devName);
    } else {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_left error!\n");
        return VOS_ERR;
    }
    return VOS_OK;
}

// ��ȡ�ն�����
static int sg_get_devtype(char *devType)
{
    int pos = 0;
    char Temp_str[1500] = { 0 };

    if (sg_read_file_get(SG_DEVICE_TYPE_FILE, Temp_str) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get devType error!\n");
        return VOS_ERR;
    }

    pos = sg_find(Temp_str, (int)strlen(Temp_str), "XXX", 1, 0);
    if (pos <= 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get pos error!\n");
        return VOS_ERR;
    }

    if (sg_str_mid(Temp_str, (int)strlen(Temp_str), pos - 3, devType, 3)) {
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "devType in = %s\n", devType);
    } else {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid error!\n");
        return VOS_ERR;
    }
    return VOS_OK;
}
// ��ȡ�ն�Ӳ���汾��
static int sg_get_hardware_version(char *Version)
{
    int pos = 0;
    char Temp_str[DATA_BUF_F64_SIZE] = { 0 };

    if (sg_file_common_get(DEVICE_HARDWARE_VERSION, Temp_str) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get Version error!\n");
        return VOS_ERR;
    }

    pos = sg_find(Temp_str, (int)strlen(Temp_str), "H", 1, 0);
    if (pos <= 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get pos error!\n");
        return VOS_ERR;
    }

    if (sg_str_mid(Temp_str, (int)strlen(Temp_str), pos, Version, 7)) {
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "Version in = %s\n", Version);
    } else {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid error!\n");
        return VOS_ERR;
    }
    return VOS_OK;
}

// ��ȡ�豸��Ϣ�ֶ�
int sg_get_dev_devinfo(dev_info_s *info)
{
    if (info == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "\nsg_get_dev_devinfo :info is NULL.\n");
        return VOS_ERR;
    }

    if (sg_get_devname(info->devName) != VOS_OK) {                              // ��ȡ�ն�����
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get_devName error!\n");
        return VOS_ERR;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "devName out = %s\n", info->devName);

    if (sg_get_devtype(info->devType) != VOS_OK) {                              // ��ȡ�ն����� �ն�IDǰ�����ֽ�
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get_devType error!\n");
        return VOS_ERR;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "devType out = %s\n", info->devType);

    if (sg_file_common_get(VENDOR_FILE, info->mfgInfo) != VOS_OK) {              // ��ȡ�ն˳�����Ϣ
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get mfgInfo error!\n");
        return VOS_ERR;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "info->mfgInfo = %s \n", info->mfgInfo);

    if (sprintf_s(info->devStatus, DATA_BUF_F64_SIZE, "%s", "online") < 0) {     // ��ȡ�ն�״̬
        return VOS_ERR;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "syslog_info->devStatus = %s\n", info->devStatus);

    if (sg_get_hardware_version(info->hardVersion) != VOS_OK) {                 // ��ȡ�ն�Ӳ���汾��
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get_Version error!\n");
        if (memcpy_s(info->hardVersion, DATA_BUF_F64_SIZE, "HV01.01", strlen("HV01.01")) != 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_get_dev_devinfo: hardVersion failed!\n");
        }                                                                       // ���û�о�Ĭ��Ϊ"HV01.01"
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Version out = %s\n", info->hardVersion);
        return VOS_ERR;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "Version out = %s\n", info->hardVersion);
    return VOS_OK;
}

int sg_get_cpu_devinfo(cpu_info_s *info)
{
    FILE *fp = NULL;
    int ret = VOS_OK;
    int frequency = SG_SECOND;
    int dstbuflen = 0;
    char errmsg[DATA_BUF_F256_SIZE]      = { 0 };
    char buf[DEV_INFO_MSG_BUFFER_LEN]    = { 0 };
    char dstbuf[DEV_INFO_MSG_BUFFER_LEN] = { 0 };
    struct sysinfo si                    = { 0 };
    cpuusage_s output_value              = { 0 };

    info->cpus = sysconf(_SC_NPROCESSORS_ONLN);             // cpu����
    if ((fp = fopen(CPU_FREQUENCY_PATH, "r")) == NULL) {    // cpu��Ƶ
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "\nfile open cpu devinfo failed.\n");
        return VOS_ERR;
    }

    while (!feof(fp)) {
        if (fgets(buf, DEV_INFO_MSG_BUFFER_LEN, fp) != NULL) {
            ret = VOS_OK;
        }
    }

    (void)fclose(fp);
    dstbuflen = sg_str_right(buf, (int)strlen(buf), dstbuf, (int)(strlen(buf) - strlen("cpu MHz :")));
    if (dstbuflen > 0) {
        frequency = atoi(dstbuf);
    }

    info->frequency = frequency / 1024.0;
    (void)sysinfo(&si);
    info->cache = si.bufferram / (1024 * 1024);             // cpu����
    if (sysman_rpc_transport_open() != VOS_OK) {            // cpu�澯��ֵ
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        ret = VOS_ERR;
    }

    ret = cpuusage_status_call_get_threshold(&output_value, errmsg, DATA_BUF_F256_SIZE);
    sysman_rpc_transport_close();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "cpuusage_status_call_get_threshold error!\n");
        ret = VOS_ERR;
    }

    info->cpuLmt = output_value.warning;  // �澯��ֵȡ output_value.warning���澯��ֵ�ָ�ȡ output_value.warning - 10
    if (sg_cmd_common_get("uname -m", info->arch) != VOS_OK) { // cpu�ܹ�
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_cmd_common_get uname error!\n");
        ret = VOS_ERR;
    }

    return ret;
}

int sg_get_mem_devinfo(mem_info_s *info)
{
    int ret = VOS_OK;
    struct sysinfo si               = { 0 };
    memoryusage_s output_value      = { 0 };
    char errmsg[DATA_BUF_F256_SIZE] = { 0 };

    info->virt = sg_memvirt_total();             // �����ڴ棬��MΪ��λ
    (void)sysinfo(&si);
    info->phy = si.totalram / (1024 * 1024);     // �����ڴ棬��MΪ��λ
    if (sysman_rpc_transport_open() != VOS_OK) { // �ڴ�����ֵ������50��ʾ50% 
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        ret = VOS_ERR;
    }

    ret = memoryusage_status_call_get_threshold(&output_value, errmsg, DATA_BUF_F256_SIZE);
    sysman_rpc_transport_close();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "memoryusage_status_call_get_threshold error!\n");
        ret = VOS_ERR;
    }
    info->memLmt = output_value.warning;
    return ret;
}

int sg_get_disk_devinfo(disk_info_s *info)
{
    int ret = VOS_OK;
    int pos = 0;
    uint32_t infoNum = 0;
    char buf[DATA_BUF_F256_SIZE]    = { 0 };
    char dstbuf[DATA_BUF_F256_SIZE] = { 0 };
    char errmsg[DATA_BUF_F256_SIZE] = { 0 };
    storageusage_s *output_value    = NULL;

    if (sg_file_common_get(STORAGE_SIZE_FILE, buf) != VOS_OK) { // #define STORAGE_SIZE_FILE "/etc/devinfo/storage-size"
        return VOS_ERR;
    }

    pos = sg_find(buf, (int)strlen(buf), " M", 1, 0);
    if (pos <= 0) {
        return VOS_ERR;
    }

    if (sg_str_left(buf, (int)strlen(buf), dstbuf, pos) > 0) {
        info->disk = atoi(dstbuf);
    } else {
        return VOS_ERR;
    }

    output_value = (storageusage_s*)VOS_Malloc(MID_SGDEV, sizeof(storageusage_s) * STORAGE_PARTITION_MAX_NUM);
    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        ret = VOS_ERR;
    }

    ret = storageusage_status_call_get_threshold(&infoNum, output_value, errmsg, DATA_BUF_F256_SIZE);
    sysman_rpc_transport_close();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "storageusage_status_call_get_threshold error!\n");
    }

    info->diskLmt = output_value[0].warning;
    (void)VOS_Free(output_value);
    output_value = NULL;
    return ret;
}

int sg_get_os_devinfo(os_info_s *info)    // 2020.12.15 ���:��Ҫ����
{
    char buf[DATA_BUF_F256_SIZE] = { 0 };

    if (sg_cmd_common_get("uname -s", info->distro) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "megsky test uname -s fail \n");
    }

    if (sg_cmd_common_get("uname -v", info->version) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "megsky test uname -v fail \n");
    }

    if (sg_cmd_common_get("uname -r", info->kernel) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "megsky test uname -r fail \n");
    }

    if (sg_file_common_get(CUSTOM_SOFTWARE_VERSION_FILE, buf) == VOS_OK) {
        if (sprintf_s(info->softVersion, DATA_BUF_F256_SIZE, "%s", buf) < 0) {
            return VOS_ERR;
        }
    } else if (sg_file_common_get(SOFTWARE_VERSION_FILE, buf) == VOS_OK) {
        if (sprintf_s(info->softVersion, DATA_BUF_F256_SIZE, "%s", buf) < 0) {
            return VOS_ERR;
        }
    } else {
        return VOS_ERR;
    }

    if (sg_file_common_get(CUSTOM_PATCH_VERSION_FILE, buf) == VOS_OK) {
        if (sprintf_s(info->patchVersion, DATA_BUF_F256_SIZE, "%s", buf) < 0) {
            return VOS_ERR;
        }
    } else if (sg_file_common_get(PATCH_VERSION_FILE, buf) == VOS_OK) {
        if (sprintf_s(info->patchVersion, DATA_BUF_F256_SIZE, "%s", buf) < 0) {
            return VOS_ERR;
        }
    } else {
        return VOS_ERR;
    }

    return VOS_OK;
}

static gint links_comp(gconstpointer a, gconstpointer b)
{
    ifm_link_info_t *ifm_link_info1 = *(ifm_link_info_t **)a;
    ifm_link_info_t *ifm_link_info2 = *(ifm_link_info_t **)b;
    return (gint)(ifm_link_info1->if_index - ifm_link_info2->if_index);
}

// ��������links��Ϣ
static int sg_analyze_links_info(GPtrArray *ret_entry, link_info_s *links, int *num_out)
{
    unsigned int i = 0;
    int num = 0;
    int ret_spr = 0;
    ifm_link_info_t *ifm_link_info = NULL;

    for (i = 0; i < ret_entry->len; i++) {                    // ����
        ifm_link_info = (ifm_link_info_t *)g_ptr_array_index(ret_entry, i);
        if (ifm_link_info->if_index < 0 || ifm_link_info->mtu == 0) {
            continue;
        }
        if (strcmp(ifm_link_info->type, "Eth") != 0 &&
            strcmp(ifm_link_info->type, "LTE") != 0 &&
            strcmp(ifm_link_info->type, "plc") != 0 &&
            strcmp(ifm_link_info->type, "rf") != 0) {
            continue;
        }
        if (strcmp(ifm_link_info->name, "br0") == 0 ||
            strcmp(ifm_link_info->name, "br_lsw") == 0 ||
            strcmp(ifm_link_info->name, "br_docker0") == 0) {
            continue;
        }
        if (sprintf_s(links[num].type, DATA_BUF_F32_SIZE, "%s", ifm_link_info->type) < 0) {
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_info links[%d].type get error\n", num);
            return VOS_ERR;
        }
        if (sprintf_s(links[num].id, DATA_BUF_F32_SIZE, "%d", ifm_link_info->if_index) < 0) {
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_info links[%d].id get error\n", num);
            return VOS_ERR;
        }
        if (strncmp(ifm_link_info->vlan_master, "NO", strlen(ifm_link_info->vlan_master)) != 0) {
            ret_spr = sprintf_s(links[num].name, DATA_BUF_F32_SIZE, "%s@%s",
                ifm_link_info->name, ifm_link_info->vlan_master);
        } else {
            ret_spr = sprintf_s(links[num].name, DATA_BUF_F32_SIZE, "%s", ifm_link_info->name);
        }
        if (ret_spr < 0) {
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_info ret_spr get error\n");
            return VOS_ERR;
        }
        if (sprintf_s(links[num].mac, DATA_BUF_F32_SIZE, "%s", ifm_link_info->mac_addr) < 0) {
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_info links[%d].mac get error\n", num);
            return VOS_ERR;
        }

        num++;
    }
    *num_out = num;
    return VOS_OK;
}

// ��ȡ����������Ϣ  ��ȡtype  id  name  mac
int sgcc_get_links_info(link_info_s **links_info_out, int *links_num)
{
    int num = 0;
    GError *error = NULL;
    GPtrArray *ret_entry = NULL;
    ifm_statusIf *ifm_status_client_info = NULL;
    link_info_s *links = NULL;

    ifm_status_client_info = (ifm_statusIf *)create_rpc_client((GType)TYPE_IFM_STATUS_CLIENT,
                                                               (GType)SERVICE_TAG_IFM_STATUS);
    if (ifm_status_client_info == NULL) {
        return -1;
    }
    ret_entry = g_ptr_array_new();
    if (ret_entry == NULL) {
        free_rpc_client(ifm_status_client_info);
        return -1;
    }
    g_ptr_array_set_free_func(ret_entry, g_object_unref);

    bool rpc_call_return = ifm_status_if_get_link_info(ifm_status_client_info, &ret_entry, "",
        IF_SHOW_INFO_E_IFM_NO_DEV_AND_UP, &error);            // ��ȡ
    free_rpc_client(ifm_status_client_info);
    if (!rpc_call_return) {
        g_ptr_array_unref(ret_entry);
        return -1;
    }
    g_ptr_array_sort(ret_entry, (GCompareFunc)links_comp);    // ����

    links = (link_info_s *)VOS_Malloc(MID_SGDEV, sizeof(link_info_s) * ret_entry->len);
    if (links == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Error - unable to allocate required memory\n");
        return VOS_ERR;
    }
    (void)memset_s(links, sizeof(link_info_s) * ret_entry->len, 0, sizeof(link_info_s) * ret_entry->len);

    if (sg_analyze_links_info(ret_entry, links, &num) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_info get error!\n");
    }

    *links_num = num;
    *links_info_out = links;
    g_ptr_array_unref(ret_entry);
    (void)VOS_Free(links);
    links = NULL;
    return VOS_OK;
}
// ��������links��Ϣ ������status
static int sg_analyze_links_status(GPtrArray *ret_entry, link_dev_info_s *links, int *num_out)
{
    unsigned int i = 0;
    int num = 0;
    int ret_spr = 0;
    ifm_link_info_t *ifm_link_status = NULL;

    for (i = 0; i < ret_entry->len; i++) {                   // ����
        ifm_link_status = (ifm_link_info_t *)g_ptr_array_index(ret_entry, i);
        if (ifm_link_status->if_index < 0 || ifm_link_status->mtu == 0) {
            continue;
        }
        if (strcmp(ifm_link_status->type, "Eth") != 0 &&
            strcmp(ifm_link_status->type, "LTE") != 0 &&
            strcmp(ifm_link_status->type, "plc") != 0 &&
            strcmp(ifm_link_status->type, "rf") != 0) {
            continue;
        }
        if (strcmp(ifm_link_status->name, "br0") == 0 ||
            strcmp(ifm_link_status->name, "br_lsw") == 0 ||
            strcmp(ifm_link_status->name, "br_docker0") == 0) {
            continue;
        }
        if (strncmp(ifm_link_status->vlan_master, "NO", strlen(ifm_link_status->vlan_master)) != 0) {
            ret_spr = sprintf_s(links[num].name, DATA_BUF_F32_SIZE, "%s@%s",
                                ifm_link_status->name, ifm_link_status->vlan_master);
        } else {
            ret_spr = sprintf_s(links[num].name, DATA_BUF_F32_SIZE, "%s", ifm_link_status->name);
        }
        if (ret_spr < 0) {
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_status name get error\n");
            return VOS_ERR;
        }
        if ((strncmp(ifm_link_status->name, "plc", strlen("plc")) == 0 ||
            strncmp(ifm_link_status->name, "rf", strlen("rf")) == 0) &&
            strncmp(ifm_link_status->oper_status, "unknown", strlen(ifm_link_status->oper_status)) == 0) {
            ret_spr = sprintf_s(links[num].status, DATA_BUF_F64_SIZE, "%s", "up");
        } else {
            ret_spr = sprintf_s(links[num].status, DATA_BUF_F64_SIZE, "%s", ifm_link_status->oper_status);
        }
        if (ret_spr < 0) {
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_status status get error\n");
            return VOS_ERR;
        }
        num++;
    }
    *num_out = num;
    return VOS_OK;
}

// ��ȡ����������Ϣ ��ȡstatus
int sgcc_get_links_status(link_dev_info_s **links_info_out, int *links_num)
{
    int num = 0;
    GError *error = NULL;
    GPtrArray *ret_entry = NULL;
    ifm_statusIf *ifm_status_client = NULL;
    link_dev_info_s *links = NULL;

    ifm_status_client = (ifm_statusIf *)create_rpc_client((GType)TYPE_IFM_STATUS_CLIENT, (GType)SERVICE_TAG_IFM_STATUS);
    if (ifm_status_client == NULL) {
        return -1;
    }
    ret_entry = g_ptr_array_new();
    if (ret_entry == NULL) {
        free_rpc_client(ifm_status_client);
        return -1;
    }
    g_ptr_array_set_free_func(ret_entry, g_object_unref);

    bool rpc_call_return = ifm_status_if_get_link_info(ifm_status_client, &ret_entry, "",
        IF_SHOW_INFO_E_IFM_NO_DEV_AND_UP, &error);            // ��ȡ
    free_rpc_client(ifm_status_client);
    if (!rpc_call_return) {
        g_ptr_array_unref(ret_entry);
        return -1;
    }
    g_ptr_array_sort(ret_entry, (GCompareFunc)links_comp);    // ����
    links = (link_dev_info_s *)VOS_Malloc(MID_SGDEV, sizeof(link_dev_info_s) * ret_entry->len);
    if (links == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Error - unable to allocate required memory\n");
        return VOS_ERR;
    }
    (void)memset_s(links, sizeof(link_dev_info_s) * ret_entry->len, 0, sizeof(link_dev_info_s) * ret_entry->len);

    if (sg_analyze_links_status(ret_entry, links, &num) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_analyze_links_status get error!\n");
    }
    *links_num = num;
    *links_info_out = links;
    g_ptr_array_unref(ret_entry);
    (void)VOS_Free(links);
    links = NULL;
    return VOS_OK;
}
// ��ȡ�豸������Ϣ
int sg_get_dev_insert_info(dev_acc_req_s *devinfo)
{
    int ret = VOS_OK;
    if (sg_get_dev_devinfo(&devinfo->dev) == VOS_ERR) {
        ret = VOS_ERR;
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get device infomation fail. \n");
    }
    if (sg_get_cpu_devinfo(&devinfo->cpu) == VOS_ERR) {
        ret = VOS_ERR;
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get cpu infomation fail. \n");
    }
    if (sg_get_mem_devinfo(&devinfo->mem) == VOS_ERR) {
        ret = VOS_ERR;
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get memory infomation fail. \n");
    }
    if (sg_get_disk_devinfo(&devinfo->disk) == VOS_ERR) {
        ret = VOS_ERR;
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get disk infomation fail. \n");
    }
    if (sg_get_os_devinfo(&devinfo->os) == VOS_ERR) {
        ret = VOS_ERR;
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get os infomation fail. \n");
    }
    if (sgcc_get_links_info(&devinfo->links, &devinfo->link_len) == VOS_ERR) {
        ret = VOS_ERR;
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "get links infomation fail. \n");
    }
    return ret;
}

int sg_down_update_host(device_upgrade_s *cmd_obj, char *errormsg)
{
    int ret = VOS_OK;
    char filepath[DATA_BUF_F256_SIZE]  = { 0 };
    char signature[DATA_BUF_F256_SIZE] = { 0 };
    if (errormsg == NULL) {
        return VOS_ERR;
    }
    if (sprintf_s(filepath, DATA_BUF_F256_SIZE, "/mnt/internal/internal_storage/%s", cmd_obj->file.name) < 0) {
        ret = VOS_ERR;
    }

    if (sprintf_s(signature, DATA_BUF_F256_SIZE, "/mnt/internal/internal_storage/%s", cmd_obj->file.sign.name) < 0) {
        ret = VOS_ERR;
    }

    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        if (sprintf_s(errormsg, DATA_BUF_F256_SIZE, "%s", "sysman_rpc_transport_open error!\n") < 0) {
            ret = VOS_ERR;
        }
        return VOS_ERR;
    }
    ret = software_management_action_call_load_software(filepath, signature, errormsg, DATA_BUF_F256_SIZE);
    sysman_rpc_transport_close();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        return VOS_ERR;
    }
    return ret;
}

int sg_down_update_patch(device_upgrade_s *cmd_obj, char *errormsg)
{
    int ret = VOS_OK;
    char file_buf[DATA_BUF_F256_SIZE] = { 0 };
    patch_status_s patch_status;

    if (errormsg == NULL) {
        return VOS_ERR;
    }

    (void)memset_s(&patch_status, sizeof(patch_status_s), 0, sizeof(patch_status_s));
    if (sysman_rpc_transport_open() != VOS_OK) {
        if (sprintf_s(errormsg, DATA_BUF_F256_SIZE, "%s", "rpc_transport_open failed!\n") < 0) {
            ret = VOS_ERR;
        }
        return VOS_ERR;
    }

    if (sprintf_s(file_buf, DATA_BUF_F256_SIZE, "%s/%s", DEFAULT_FILE_PATH, cmd_obj->file.name) < 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sprintf_s error file_buf");
        return VOS_ERR;
    }

    ret = software_management_action_call_install_patch(DEFAULT_FILE_PATH, NULL, true, errormsg, SYSMAN_RPC_ERRMSG_MAX);
    sysman_rpc_transport_close();

    if (sysman_rpc_transport_open() != VOS_OK) {
        if (sprintf_s(errormsg, DATA_BUF_F256_SIZE, "%s", "sysman_rpc_transport_open failed!\n") < 0) {
            ret = VOS_ERR;
        }
        return VOS_ERR;
    }
    ret = software_management_status_call_get_patch_status(&patch_status, errormsg, SYSMAN_RPC_ERRMSG_MAX);
    sysman_rpc_transport_close();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open failed!\n");
        return VOS_ERR;
    }
    return ret;
}

// ��ȡ�豸���һ������ʱ��
int sg_get_dev_date_time(char *timeBuf, long *timenum)
{
    time_t cur_time = 0;
    time_t boot_time = 0;
    struct tm format_time       = { 0 };
    struct sysinfo Information  = { 0 };
    if (sysinfo(&Information)) {
        return VOS_ERR;
    }
    *timenum = Information.uptime;
    cur_time = time(0);
    if (cur_time > Information.uptime) {
        boot_time = cur_time - Information.uptime;
    } else {
        boot_time = Information.uptime - cur_time;
    }
    if (gmtime_r(&boot_time, &format_time) == NULL) {   // UTCʱ��
        return VOS_ERR;
    }
    (void)strftime(timeBuf, 32, "%Y-%m-%d,%T,%Z", &format_time);
    return VOS_OK;
}

// ��ȡ�����ڴ��ʹ������
uint32_t sg_memvirt_total(void)
{
    FILE *p_file = NULL;
    uint32_t total = 0;
    char buf[DEV_INFO_MSG_BUFFER_LEN]      = { 0 };
    char temp_str[DEV_INFO_MSG_BUFFER_LEN] = { 0 };

    p_file = popen("free |grep Swap|awk '{print $2}'", "r");
    if (p_file == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_total: error to popen \n");
        return total;
    }
    while (fgets(buf, DEV_INFO_MSG_BUFFER_LEN, p_file) != NULL) {
        if (sprintf_s(temp_str, DEV_INFO_MSG_BUFFER_LEN, "%s", buf) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_total: temp_str get error\n");
        }
    }
    if (sscanf_s(temp_str, "%d", &total) < 0) { // ���ַ���תΪ����
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_total: temp_str change error\n");
    }
    (void)pclose(p_file);
    return total;
}
// ��ȡ�����ڴ�ĵ�ǰʹ����
uint8_t sg_memvirt_used(void)
{
    FILE *p_file = NULL;
    float usagerate = 0.0;
    uint8_t ret_value = 0;
    uint32_t used = 0;
    uint32_t total = 0;
    char buf[DEV_INFO_MSG_BUFFER_LEN]      = { 0 };
    char temp_str[DEV_INFO_MSG_BUFFER_LEN] = { 0 };

    p_file = popen("free |grep Swap|awk '{print $3}'", "r");  // ��ȡ�����ڴ��ʹ����
    if (p_file == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_used: error to popen \n");
        return ret_value;
    }
    while (fgets(buf, DEV_INFO_MSG_BUFFER_LEN, p_file) != NULL) {
        if (sprintf_s(temp_str, DEV_INFO_MSG_BUFFER_LEN, "%s", buf) < 0) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_used: temp_str get error\n");
        }
    }
    if (sscanf_s(temp_str, "%d", &used) < 0) { // ���ַ���תΪ����
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_used: temp_str change error\n");
    }
    (void)pclose(p_file);
    total = sg_memvirt_total();
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_used: used = %d\n", used);
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_memvirt_used: sg_memvirt_total = %d\n", total);

    if (total > 0) {
        usagerate = (float) used / total;       // ��ȡ�ٷ���
        ret_value = (uint8_t)(usagerate * 100);
    }

    return ret_value;
}

/* *****************************************************************
 * ��ȡ���豸�е�alertֵ
 * ����:threshold
 * ����:select_flag
 * select_flagȡ: CPU_USAGE
 *   MEM_USAGE
 *   STORAGE_USAGE
 **************************************************************** */
int sg_get_devusage_threshold(int *threshold, uint8_t select_flag)
{
    int ret = VOS_OK;
    uint32_t infoNum = 0;
    storageusage_s *storage_value      = NULL;
    cpuusage_s cpu_value               = { 0 };
    memoryusage_s mem_value            = { 0 };
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };

    ret = sysman_rpc_transport_open();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "rpc open error!\n");
        return VOS_ERR;
    }

    if (select_flag == CPU_USAGE) {
        ret = cpuusage_status_call_get_threshold(&cpu_value, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    } else if (select_flag == MEM_USAGE) {
        ret = memoryusage_status_call_get_threshold(&mem_value, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    } else if (select_flag == STORAGE_USAGE) {
        storage_value = (storageusage_s*)VOS_Malloc(MID_SGDEV, sizeof(storageusage_s) * STORAGE_PARTITION_MAX_NUM);
        if (storage_value == NULL) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "failed to malloc storage_value.\n");
            sysman_rpc_transport_close();
            return VOS_ERR;
        }
        (void)memset_s(storage_value, sizeof(storageusage_s) * STORAGE_PARTITION_MAX_NUM, 0,
            sizeof(storageusage_s) * STORAGE_PARTITION_MAX_NUM);
        ret = storageusage_status_call_get_threshold(&infoNum, storage_value, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    }

    sysman_rpc_transport_close();
    if (select_flag == CPU_USAGE) {
        *threshold = cpu_value.alert;
    } else if (select_flag == MEM_USAGE) {
        *threshold = mem_value.alert;
    } else if (select_flag == STORAGE_USAGE) {
        if (storage_value != NULL) {
            *threshold = storage_value[0].alert;
            (void)VOS_Free(storage_value);
            storage_value = NULL;
        }
    }

    return ret;
}


// ���´�����ʱ��
int sg_creat_timer(rep_period_s *paraobj)
{
    int nRet = VOS_OK;
    // ע�ᶨʱ��
    nRet = sg_timer_heart_create(paraobj->heartPeriod);
    if (nRet != VOS_OK) {
        return nRet;
    }

    nRet = sg_timer_dev_create(paraobj->devPeriod);
    if (nRet != VOS_OK) {
        return nRet;
    }

    nRet = sg_timer_container_create(paraobj->conPeriod);
    if (nRet != VOS_OK) {
        return nRet;
    }

    nRet = sg_timer_app_create(paraobj->appPeriod);
    if (nRet != VOS_OK) {
        return nRet;
    }

    return nRet;
}
// ʱ��������
void sg_set_period(rep_period_s *paraobj)
{
    sg_write_period_file(paraobj);              // �����ļ��洢
    if (sg_creat_timer(paraobj) != VOS_OK) {    // ���´�����ʱ��
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "creat timer error!\n");
    }

    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "********Creat timer success !**************\n");
}

// �����ڲ����ļ�
int sg_get_period_file(sg_period_info_s *get_devperiod)
{
    int ret = VOS_OK;
    json_t *json_data = NULL;
    json_error_t error;
    uint32_t tmp_app_period = 0;
    uint32_t tmp_container_period = 0;
    uint32_t tmp_dev_period = 0;
    uint32_t tmp_dev_heartbeat_period = 0;
    json_data = json_load_file(PERIOD_PARAMS_FILEPATH, 0, &error);
    if (json_data == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "file(%s) error\n", PERIOD_PARAMS_FILEPATH);
        return VOS_ERR;
    }

    if (json_into_uint32_t(&tmp_app_period, json_data, "app_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    get_devperiod->app_period = tmp_app_period;
    if (json_into_uint32_t(&tmp_container_period, json_data, "container_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    get_devperiod->container_period = tmp_container_period;
    if (json_into_uint32_t(&tmp_dev_period, json_data, "dev_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    get_devperiod->dev_period = tmp_dev_period;
    if (json_into_uint32_t(&tmp_dev_heartbeat_period, json_data, "dev_heartbeat_period") != VOS_OK) {
        ret = VOS_ERR;
    }

    get_devperiod->dev_heartbeat_period = tmp_dev_heartbeat_period;
    json_decref(json_data);
    return ret;
}

// ��ȡ�¶ȼ����ֵ�ķ���
int sg_get_monitor_temperature_threshold(temp_info_s *temp_info_out)
{
    int ret = VOS_OK;
    uint32_t infoNum = 0;
    uint32_t num = 0;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };
    temperature_threshold_status_s *temp_threshold_get = NULL;
    temp_threshold_get = (temperature_threshold_status_s*)VOS_Malloc(MID_SGDEV,
        sizeof(temperature_threshold_status_s) * MONITOR_TEMP_NUM);    // ��ȡ�ߵ�����ֵ
    if (temp_threshold_get == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "failed to malloc temp_threshold_get.\n");
        return VOS_ERR;
    }
    (void)memset_s(temp_threshold_get, MONITOR_TEMP_NUM * sizeof(temperature_threshold_status_s), 0, MONITOR_TEMP_NUM *
        sizeof(temperature_threshold_status_s));

    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman rpc open error!\n");
        (void)VOS_Free(temp_threshold_get);
        return VOS_ERR;
    }
    ret = temperature_status_call_get_monitor_threshold(&infoNum, temp_threshold_get, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    sysman_rpc_transport_close();
    for (num = 0; num < infoNum; num++) {   // ������Ҫ����"Main_board"�ԱȻ�ȡ
        if (0 == strncmp(temp_threshold_get[num].moduleName, TEMPERATURE_MODULE_NAME_MAINBOARD,
            strlen(TEMPERATURE_MODULE_NAME_MAINBOARD))) {
            temp_info_out->temLow = temp_threshold_get[num].temLow;
            temp_info_out->temHigh = temp_threshold_get[num].temHigh;

            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "get_temLow = %d\n", temp_threshold_get[num].temLow);
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "get_temHigh = %d\n", temp_threshold_get[num].temHigh);
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "get_temVal = %d\n", temp_threshold_get[num].temVal);
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "temp_info_out->temLow = %d\n", temp_info_out->temLow);
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "temp_info_out->temHigh = %d\n", temp_info_out->temHigh);
            break;
        }
    }
    (void)VOS_Free(temp_threshold_get);
    return ret;
}

int sg_get_device_temperature_threshold(dev_sta_reply_s *dev_sta_reply)
{
    int ret = VOS_OK;
    uint32_t num = 0;
    uint32_t infoNum = 0;
    char errmsg[SYSMAN_RPC_ERRMSG_MAX] = { 0 };
    temperature_s *tempoutput_value    = NULL;

    tempoutput_value = (temperature_s*)VOS_Malloc(MID_SGDEV, sizeof(temperature_s) * MONITOR_TEMP_NUM);
    if (tempoutput_value == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "failed to malloc tempoutput_value.\n");
        return VOS_ERR;
    }
    (void)memset_s(tempoutput_value, MONITOR_TEMP_NUM * sizeof(temperature_s), 0, sizeof(temperature_s) *
        MONITOR_TEMP_NUM);
    if (sysman_rpc_transport_open() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sysman_rpc_transport_open error!\n");
        ret = VOS_ERR;
    }
    ret = temperature_status_call_get_device_temperature(&infoNum, tempoutput_value, errmsg, SYSMAN_RPC_ERRMSG_MAX);
    sysman_rpc_transport_close();
    if (ret != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "temperature_status_call_get_device_temperature error! \n");
        ret = VOS_ERR;
    }
    for (num = 0; num < infoNum; num++) {
        if (0 == strncmp(tempoutput_value[num].name, TEMPERATURE_MODULE_NAME_MAINBOARD,
            strlen(TEMPERATURE_MODULE_NAME_MAINBOARD))) {
            dev_sta_reply->tempValue = tempoutput_value[num].temperature;
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "tempoutput_value[%d].temperature = %d \n",
                num, tempoutput_value[num].temperature);
            break;
        }
    }
    (void)VOS_Free(tempoutput_value);
    return ret;
}

// ��ȡʱ����Ϣ ��XXXX-XX-XX XX:XX:XXʱ���ʽ����Ϊint��
int sg_get_time(char *dateTime, sys_time_s *sys_time)
{
    int ret = VOS_OK;
    int pos = 0;
    char Time_str[16] = { 0 };
    pos = sg_find(dateTime, (int)strlen(dateTime), "-", 1, 0);
    if (pos > 0) {
        if (sg_str_mid(dateTime, (int)strlen(dateTime), pos - 4, Time_str, 4)) {     // ��
            sys_time->tm_year = atoi(Time_str);
        } else {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid_get_year_error!\n");
            ret = VOS_ERR;
        }
        if (sg_str_mid(dateTime, (int)strlen(dateTime), pos + 1, Time_str, 2)) {     // ��
            sys_time->tm_mon = atoi(Time_str);
        } else {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid_get_mon_error!\n");
            ret = VOS_ERR;
        }
        if (sg_str_mid(dateTime, (int)strlen(dateTime), pos + 4, Time_str, 2)) {     // ��
            sys_time->tm_mday = atoi(Time_str);
        } else {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid_get_day_error!\n");
            ret = VOS_ERR;
        }
        if (sg_str_mid(dateTime, (int)strlen(dateTime), pos + 7, Time_str, 2)) {     // ʱ
            sys_time->tm_hour = atoi(Time_str);
        } else {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid_get_hour_error!\n");
            ret = VOS_ERR;
        }
        if (sg_str_mid(dateTime, (int)strlen(dateTime), pos + 10, Time_str, 2)) {    // ��
            sys_time->tm_min = atoi(Time_str);
        } else {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid_get_min_error!\n");
            ret = VOS_ERR;
        }
        if (sg_str_mid(dateTime, (int)strlen(dateTime), pos + 13, Time_str, 2)) {    // ��
            sys_time->tm_sec = atoi(Time_str);
            SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sys_time->tm_sec = %d\n", sys_time->tm_sec);
        } else {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_str_mid_get_sec_error!\n");
            ret = VOS_ERR;
        }
    } else {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "common_get pos error!\n");
        ret = VOS_ERR;
    }
    return ret;
}

int sg_get_dev_edge_reboot(void)
{
    return edge_reboot_flag;
}

void sg_set_edge_reboot(int flag)
{
    edge_reboot_flag = flag;
    SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "Set edge_reboot_flag = %d\n", edge_reboot_flag);
}
