#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "vos_typdef.h"
#include "vos_errno.h"
#include "vrp_mem.h"
#include "vrp_event.h"
#include "vrp_task.h"
#include "sysman_rpc_api.h"
#include "securec.h"
#include "sgdev_debug.h"
#include "sgdev_param.h"
#include "sgdev_queue.h"
#include "thread_dev_insert.h"
#include "task_link.h"
#include "upmqtt_json.h"
#include "upmqtt_pub.h"

uint16_t g_port = SG_MQTT_PORT;
mqtt_connect_data_s g_mqtt_connect_flag = { 0 };

char g_ip[DATA_BUF_F32_SIZE] = { 0 };
char g_ver[SG_VER_SIZE] = { 0 };
char g_devid[DATA_BUF_F32_SIZE] = { 0 };
char g_clientid[DATA_BUF_F32_SIZE] = { 0 };
char g_user[DATA_BUF_F32_SIZE] = { 0 };
char g_password[DATA_BUF_F32_SIZE] = { 0 };

char g_top_data_sub_dev_com[DATA_BUF_F256_SIZE] = { 0 };
char g_top_data_sub_dev_res[DATA_BUF_F256_SIZE] = { 0 };
char g_top_data_sub_ctai_com[DATA_BUF_F256_SIZE] = { 0 };
char g_top_data_sub_app_com[DATA_BUF_F256_SIZE] = { 0 };

char g_device_reply_pub[DATA_BUF_F256_SIZE] = { 0 };
char g_device_request_pub[DATA_BUF_F256_SIZE] = { 0 };
char g_device_data_pub[DATA_BUF_F256_SIZE] = { 0 };
char g_container_reply_pub[DATA_BUF_F256_SIZE] = { 0 };
char g_container_data_pub[DATA_BUF_F256_SIZE] = { 0 };
char g_app_reply_pub[DATA_BUF_F256_SIZE] = { 0 };
char g_app_data_pub[DATA_BUF_F256_SIZE] = { 0 };

MQTTClient g_client = NULL;

MQTTClient_connectOptions g_conn_opts = MQTTClient_connectOptions_initializer;
volatile MQTTClient_deliveryToken g_deliveredtoken;


int sg_mqtt_main_task(void)
{
    if (sg_mqtt_init() != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_init failed");
        return VOS_ERR;
    }
    for (;;) {
        if (sg_get_mqtt_connect_flag() != DEVICE_ONLINE) {
            if (sg_agent_mqtt_connect() != VOS_OK) {
                continue;
            }
            if (sg_create_sub_topic() != VOS_OK) {
                SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "mqtt connect subscribe failed.\n");
                return VOS_ERR;
            }
        }
        if (sg_get_dev_edge_reboot() == REBOOT_EDGE_SET) {
            break;
        }
        VOS_T_Delay(MS_MQTT_THREAD_CONNECT_WAIT);  //��ʱ30��
    }
    return VOS_OK;
}

void sg_delivered(void *context, MQTTClient_deliveryToken dt)
{
    VOS_UNUSED_VAR(context);
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "Message with token value %d delivery confirmed\n", dt);
    g_deliveredtoken = dt;
}

void sg_connLost(void *context, char *cause)
{
    VOS_UNUSED_VAR(context);
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_connLost(cause = %s).\n", cause);
    g_mqtt_connect_flag.mqtt_connect_flag = DEVICE_OFFLINE;
    sg_set_mqtt_connect_flag(DEVICE_OFFLINE);
}

int sg_mqtt_msg_arrvd_cb(char *topic, char *payloadptr, size_t msg_len)
{
    int size = 0;
    mqtt_data_info_s *item = NULL;
    if (topic == NULL) {
        return VOS_ERR;
    }

    item = (mqtt_data_info_s*)VOS_Malloc(MID_SGDEV, sizeof(mqtt_data_info_s));
    if (item == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt arrvd malloc item failed.\n");
        return VOS_ERR;
    }

    (void)memset_s(item, sizeof(mqtt_data_info_s), 0, sizeof(mqtt_data_info_s));
    if (memcpy_s(item->msg_send, MSG_ARRVD_MAX_LEN, payloadptr, msg_len) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_msg_arrvd: sdata failed!\n");
    }

    size = sprintf_s(item->pub_topic, DATA_BUF_F256_SIZE, "%s", topic);
    if (size < 0) {
        (void)VOS_Free(item);
        return VOS_ERR;
    }

    sg_push_unpack_item(item);          // ����
    return VOS_OK;
}

int sg_mqtt_msg_arrvd(void *context, char *topic, int topic_len, MQTTClient_message *msg)
{
    VOS_UNUSED_VAR(context);
    VOS_UNUSED_VAR(topic_len);
    char *content_str = NULL;
    errno_t err = EOK;

    if (msg == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt msg is null.\n");
        MQTTClient_free(topic);
        return 1;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "\n ******** Message arrived ************\n");
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "\n topic: %s \n", topic);
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "\n msg->payload == %s \n", msg->payload);

    if (msg->payloadlen > 0) {
        content_str = malloc((size_t)(msg->payloadlen + 1));
        if (content_str) {
            err = memcpy_s(content_str, (size_t)(msg->payloadlen + 1), msg->payload, (size_t)(msg->payloadlen));
            if (err != EOK) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "msg arrived failled for secure fun called, ret = %d\n", err);
                free(content_str);
                return 1;
            }
            content_str[msg->payloadlen] = 0;
            if (sg_mqtt_msg_arrvd_cb(topic, content_str, (size_t)msg->payloadlen)) {
                SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_msg_arrvd_cb: item failed!\n");
            }

            (void)memset_s(content_str, (size_t)(msg->payloadlen + 1), 0, (size_t)(msg->payloadlen + 1));
            (void)memset_s(msg->payload, (size_t)(msg->payloadlen), 0, (size_t)(msg->payloadlen));
            free(content_str);
            content_str = NULL;
        } else {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt msg malloc failed.\n");
        }
    }

    MQTTClient_freeMessage(&msg);
    MQTTClient_free(topic);
    return 1;
}

void sg_set_mqtt_connect_flag(int flag)
{
    g_mqtt_connect_flag.mqtt_connect_flag = flag;
    if (g_mqtt_connect_flag.mqtt_connect_flag == DEVICE_OFFLINE) {
        sg_set_dev_ins_flag(DEVICE_OFFLINE);
    }
}

int sg_get_mqtt_connect_flag(void)
{
    if (g_mqtt_connect_flag.mqtt_connect_flag == DEVICE_ONLINE) {
        if (!MQTTClient_isConnected(g_client)) {
            g_mqtt_connect_flag.mqtt_connect_flag = DEVICE_OFFLINE;
        }
    }

    return g_mqtt_connect_flag.mqtt_connect_flag;
}

int sg_agent_mqtt_init(char *server_uri, char* client_id)
{
    int mqtt_ret;
    int ret = VOS_OK;
    sg_set_mqtt_connect_flag(DEVICE_OFFLINE);

    if (server_uri == NULL || client_id == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "MQTT Init param failed.\n");
        return VOS_ERR;
    }

    g_conn_opts.keepAliveInterval = SG_KEEP_ALIVE_INTERVAL;
    g_conn_opts.cleansession = 1;
    if (strlen(g_user) != 0 && strlen(g_password) != 0) {
        g_conn_opts.username = g_user;
        g_conn_opts.password = g_password;
    }

    mqtt_ret = MQTTClient_create(&g_client, server_uri, client_id, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    if (mqtt_ret != MQTTCLIENT_SUCCESS) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "MQTTClient_create failed(server_uri = %s,clientid = %s,ret = %d).\n",
            server_uri, client_id, mqtt_ret);
        return VOS_ERR;
    }

    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "MQTTClient_create success(server_uri = %s,clientid = %s).\n",
        server_uri, client_id);
    mqtt_ret = MQTTClient_setCallbacks(g_client, NULL, sg_connLost, sg_mqtt_msg_arrvd, sg_delivered);
    if (mqtt_ret != MQTTCLIENT_SUCCESS) {
        sg_agent_mqtt_destroy();
        return VOS_ERR;
    }

    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "sg_agent_mqtt_init success(server_uri = %s,clientid = %s).\n",
        server_uri, client_id);
    return ret;
}

/* MQTTClient_connect ����ֵ 0�ɹ�
    1�ܾ����ӣ�Э��汾��֧��
    2��ʶ�����ܾ�
    3������������
    4�û����������
    5δ��Ȩ */
int sg_agent_mqtt_connect(void)
{
    int mqtt_ret = VOS_OK;
    int ret = VOS_OK;

    sg_set_mqtt_connect_flag(DEVICE_OFFLINE);
    if (g_client == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt client id handle invalid).\n");
        return VOS_ERR;
    }

    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "mqtt connecting ....\n");
    mqtt_ret = MQTTClient_connect(g_client, &g_conn_opts);
    if (mqtt_ret != MQTTCLIENT_SUCCESS) {
        SGDEV_WARN(SYSLOG_LOG, SGDEV_MODULE, "mqtt connect failed(ret = %d)).\n", mqtt_ret);
        sg_set_mqtt_connect_flag(DEVICE_OFFLINE);
        return VOS_ERR;
    }

    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "mqtt connect  success.\n");
    g_mqtt_connect_flag.mqtt_connect_flag = DEVICE_ONLINE;
    return ret;
}

void sg_agent_mqtt_disconnect(void)
{
    int mqtt_ret;

    if (g_client != NULL) {
        mqtt_ret = MQTTClient_disconnect(g_client, 10000);
        sg_set_mqtt_connect_flag(DEVICE_OFFLINE);
        if (mqtt_ret != MQTTCLIENT_SUCCESS) {
            SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt disconnect error).\n");
        }
    }
}

void sg_agent_mqtt_destroy(void)
{
    if (g_client != NULL) {
        MQTTClient_destroy(&g_client);
        SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "mqtt destroy.\n");
        g_client = NULL;
    }
}

int sg_mqtt_msg_publish(char* msg_send, char* pub_topic)
{
    int mqtt_ret = 0;
    int rc = VOS_OK;
    int msglen = 0;
    MQTTClient_deliveryToken token;
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    if (msg_send == NULL || pub_topic == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt publish param msg_send or pubtopicinvalid.\n");
        return VOS_ERR;
    }

    if (g_client == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt client id handle invalid).\n");
        return VOS_ERR;
    }

    msglen = (int)strlen(msg_send) + 1;
    pubmsg.payload = msg_send;
    pubmsg.payloadlen = msglen;
    pubmsg.qos = QOS;
    pubmsg.retained = 0;

    mqtt_ret = MQTTClient_publishMessage(g_client, pub_topic, &pubmsg, &token);
    if (mqtt_ret != MQTTCLIENT_SUCCESS) {
        SGDEV_WARN(SYSLOG_LOG, SGDEV_MODULE, "mqtt publish failed(ret = %d,pub_topic = %s,msg = %s ,len = %d)).\n",
            mqtt_ret, pub_topic, (char *)pubmsg.payload, pubmsg.payloadlen);
        return VOS_ERR;
    }

    mqtt_ret = MQTTClient_waitForCompletion(g_client, token, TIMEOUT);
    if (mqtt_ret != MQTTCLIENT_SUCCESS) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "MQTTClient_waitForCompletion ret = %d).\n", mqtt_ret);
        rc = VOS_ERR;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "Message with delivery token %d delivered.\n", token);
    return rc;
}

int sg_mqtt_msg_subscribe(char* topic, int qos)
{
    int mqtt_ret;
    int ret = VOS_OK;
    if (topic == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt subscribe topic invalid.\n");
        return VOS_ERR;
    }

    if (g_client == NULL) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "mqtt subscribe client id handle invalid).\n");
        return VOS_ERR;
    }

    mqtt_ret = MQTTClient_subscribe(g_client, topic, qos);
    if (mqtt_ret != MQTTCLIENT_SUCCESS) {
        SGDEV_WARN(SYSLOG_LOG, SGDEV_MODULE, "mqtt subscribe failed(ret = %d,pub_topic = %s)).\n", mqtt_ret, topic);
        return VOS_ERR;
    }

    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "mqtt subscribe succeed(pub_topic = %s)).\n", topic);
    return ret;
}

int sg_mqtt_init(void)
{
    int ret = VOS_OK;
    sg_set_mqtt_connect_flag(DEVICE_OFFLINE);
    char server_uri[DATA_BUF_F256_SIZE] = { 0 };

    sg_dev_param_info_s param;
    (void)memset_s(&param, sizeof(sg_dev_param_info_s), 0, sizeof(sg_dev_param_info_s));
    sg_get_param(&param);
    g_port = param.port;
    if (memcpy_s(g_ip, DATA_BUF_F32_SIZE, param.ip, strlen(param.ip)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_init: g_ip failed!\n");
    }
    if (memcpy_s(g_clientid, DATA_BUF_F32_SIZE, param.clientid, strlen(param.clientid)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_init: g_clientid failed!\n");
    }
    if (memcpy_s(g_user, DATA_BUF_F32_SIZE, param.user, strlen(param.user)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_init: g_user failed!\n");
    }
    if (memcpy_s(g_password, DATA_BUF_F32_SIZE, param.password, strlen(param.password)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_mqtt_init: g_password failed!\n");
    }
    if (sprintf_s(server_uri, DATA_BUF_F256_SIZE, "tcp://%s:%u", g_ip, g_port) < 0) {
        ret = VOS_ERR;
    }
    SGDEV_INFO(SYSLOG_LOG, SGDEV_MODULE, "mqtt connect url: %s\n", server_uri);

    if (sg_agent_mqtt_init(server_uri, g_clientid) != VOS_OK) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_agent_mqtt_init failed.\n");
        ret = VOS_ERR;
    }

    if (sg_agent_mqtt_connect() == VOS_OK) {    // ��ʼ���ɹ�����һ������
        if (sg_create_sub_topic() == VOS_OK) {
            sg_set_mqtt_connect_flag(DEVICE_ONLINE);
        }
    }
    return ret;
}

void sg_mqtt_exit(void)
{
    g_mqtt_connect_flag.mqtt_connect_flag = DEVICE_OFFLINE;
    sg_set_mqtt_connect_flag(DEVICE_OFFLINE);
    sg_destroy_sub_topic();
    sg_agent_mqtt_disconnect();
    sg_agent_mqtt_destroy();
}

int sg_init_msg_subscribe_topic(void)
{
    int ret = VOS_OK;
    if (sprintf_s(g_top_data_sub_dev_com, DATA_BUF_F256_SIZE, "/%s/%s/device/command", g_ver, g_devid) < 0) {
        ret = VOS_ERR;     // ����ƽ̨���ն˷����豸����������豸�����������豸��
    }

    if (sg_mqtt_msg_subscribe(g_top_data_sub_dev_com, QOS) != VOS_OK) {
        ret = VOS_ERR;
    }

    if (sprintf_s(g_top_data_sub_dev_res, DATA_BUF_F256_SIZE, "/%s/%s/device/response", g_ver, g_devid) < 0) {
        ret = VOS_ERR;    // ���ڶ��ն˷��͵��豸������ص���������� Ӧ��
    }

    if (sg_mqtt_msg_subscribe(g_top_data_sub_dev_res, QOS) != VOS_OK) {
        ret = VOS_ERR;
    }

    if (sprintf_s(g_top_data_sub_ctai_com, DATA_BUF_F256_SIZE, "/%s/%s/container/command", g_ver, g_devid) < 0) {
        ret = VOS_ERR;  // ����ƽ̨���ն˷��͵������������������������װ��������ֹͣ��
    }

    if (sg_mqtt_msg_subscribe(g_top_data_sub_ctai_com, QOS) != VOS_OK) {
        ret = VOS_ERR;
    }

    if (sprintf_s(g_top_data_sub_app_com, DATA_BUF_F256_SIZE, "/%s/%s/app/command", g_ver, g_devid) < 0) {
        ret = VOS_ERR;        // ����ƽ̨���ն˷���Ӧ�ÿ������������Ӧ�ð�װ��������ֹͣ��
    }

    if (sg_mqtt_msg_subscribe(g_top_data_sub_app_com, QOS) != VOS_OK) {
        ret = VOS_ERR;
    }
    return ret;
}

int sg_create_sub_topic(void)
{
    int ret = VOS_OK;
    sg_dev_param_info_s param;
    (void)memset_s(&param, sizeof(sg_dev_param_info_s), 0, sizeof(sg_dev_param_info_s));
    sg_get_param(&param);
    if (memcpy_s(g_ver, SG_VER_SIZE, param.mqtttopicversion, strlen(param.mqtttopicversion)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_create_sub_topic: g_ver failed!\n");
    }

    if (memcpy_s(g_devid, DATA_BUF_F32_SIZE, param.devid, strlen(param.devid)) != 0) {
        SGDEV_ERROR(SYSLOG_LOG, SGDEV_MODULE, "sg_create_sub_topic: g_devid failed!\n");
    }

    if (sprintf_s(g_device_reply_pub, DATA_BUF_F256_SIZE, "/%s/%s/device/reply", g_ver, g_devid) < 0) {
        ret = VOS_ERR;            // ���ڶ�ƽ̨���͵��豸���������Ӧ��
    }

    if (sprintf_s(g_device_request_pub, DATA_BUF_F256_SIZE, "/%s/%s/device/request", g_ver, g_devid) < 0) {
        ret = VOS_ERR;        // �����ն���ƽ̨�����豸������ص�������� ���������ӵ�
    }

    if (sprintf_s(g_device_data_pub, DATA_BUF_F256_SIZE, "/%s/%s/device/data", g_ver, g_devid) < 0) {
        ret = VOS_ERR;             // �����ն���ƽ̨�����ϱ��豸��ص�״̬���¼� ��
    }

    if (sprintf_s(g_container_reply_pub, DATA_BUF_F256_SIZE, "/%s/%s/container/reply", g_ver, g_devid) < 0) {
        ret = VOS_ERR;     // ���ڶ�ƽ̨�������������������Ӧ��
    }

    if (sprintf_s(g_container_data_pub, DATA_BUF_F256_SIZE, "/%s/%s/container/data", g_ver, g_devid) < 0) {
        ret = VOS_ERR;       // �����ն���ƽ̨�����ϱ�������ص�״̬���¼� ��
    }

    if (sprintf_s(g_app_reply_pub, DATA_BUF_F256_SIZE, "/%s/%s/app/reply", g_ver, g_devid) < 0) {
        ret = VOS_ERR;                 // ���ڶ�ƽ̨���͵�Ӧ�ÿ������������Ӧ��
    }

    if (sprintf_s(g_app_data_pub, DATA_BUF_F256_SIZE, "/%s/%s/app/data", g_ver, g_devid) < 0) {
        ret = VOS_ERR;                   // ���ڶ�ƽ̨���͵�Ӧ��״̬
    }

    if (sg_init_msg_subscribe_topic() != VOS_OK) {
        ret = VOS_ERR;
    }
    return ret;
}

void sg_destroy_sub_topic(void)
{
    (void)MQTTClient_unsubscribe(g_client, g_top_data_sub_dev_com);
    (void)MQTTClient_unsubscribe(g_client, g_top_data_sub_dev_res);
    (void)MQTTClient_unsubscribe(g_client, g_top_data_sub_ctai_com);
    (void)MQTTClient_unsubscribe(g_client, g_top_data_sub_app_com);
}

char *get_topic_sub_dev_com(void)
{
    return g_top_data_sub_dev_com;
}

char *get_topic_sub_dev_res(void)
{
    return g_top_data_sub_dev_res;
}

char *get_topic_sub_ctai_com(void)
{
    return g_top_data_sub_ctai_com;
}

char *get_topic_sub_app_com(void)
{
    return g_top_data_sub_app_com;
}

char *get_topic_device_data_pub(void)
{
    return g_device_data_pub;
}

char *get_topic_device_reply_pub(void)
{
    return g_device_reply_pub;
}

char *get_topic_device_request_pub(void)
{
    return g_device_request_pub;
}

char *get_topic_container_reply_pub(void)
{
    return g_container_reply_pub;
}

char *get_topic_container_data_pub(void)
{
    return g_container_data_pub;
}

char *get_topic_app_reply_pub(void)
{
    return g_app_reply_pub;
}

char *get_topic_app_data_pub(void)
{
    return g_app_data_pub;
}

